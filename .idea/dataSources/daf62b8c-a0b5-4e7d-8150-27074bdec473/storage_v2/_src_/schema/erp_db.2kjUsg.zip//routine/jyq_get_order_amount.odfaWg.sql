create function jyq_get_order_amount(p_so_id varchar(50))
  returns double(13, 4)
  BEGIN
   declare l_order_amount  DOUBLE(13, 4);
   declare continue HANDLER  for not found set l_order_amount=0;
   select sum(market_price*ord_qty) into l_order_amount from oms_so_dtl
     where so_id=p_so_id;
  return l_order_amount;
  end;

