create procedure rp_day_receive()
  comment '日报表-前置仓收货汇总'
  begin
/* 执行删除操作 */
delete from rp_report_day_receivesum where createtime>=CURDATE();
/* 执行插入操作 */
insert into rp_report_day_receivesum
(
  rpid,
  reporttime,
  createtime,   
  whse_code,
  whse_name, 
  db_in_order_skucount,
  db_in_rcv_skucount,
  db_in_order_qty,
  db_in_rcv_qty,
  db_in_order_amount,
  db_in_rcv_amount,
  db_in_store_rcv_qty,
  so_rtn_qty)
SELECT 
			 CONCAT("RECEIVE",substring(DATE_FORMAT(DATE_SUB(curdate(),INTERVAL 1 DAY),'%Y%m%d'),3)),
			 DATE_SUB(curdate(),INTERVAL 1 DAY),
			 now(),
			 hdr.whse_code "仓库代码",
			 hdr.whse_name "仓库名称",
				ifnull(a.db_in_order_skucount,0) "调拨单商品品项",
				ifnull(b.db_in_rcv_skucount,0) "实际收货商品品项",
				ifnull(a.db_in_order_qty,0) "调拨单商品数量",
				ifnull(a.db_in_rcv_qty,0) "实际收货商品数量",
				ifnull(a.db_in_order_amount,0) "调拨单商品金额",
				ifnull(a.db_in_rcv_amount,0) "实际收货商品金额",
				ifnull(c.db_in_store_rcv_qty,0) "门店调拨入库商品数量",
				ifnull(d.so_rtn_qty,0) "销售退货商品数量（C端）"
				from
				wms_whse_master hdr left join
				  (SELECT
				  poh.to_whse whse_code,
				  count(DISTINCT asnl.sku_code) db_in_order_skucount,
				  sum(asnl.ship_unit_qty) db_in_order_qty,
				  sum(asnl.rcv_unit_qty) db_in_rcv_qty,
				  sum(asnl.ship_unit_qty*jyq_get_db_line_price(poh.po_id,sku.external_sku_id)) db_in_order_amount,
				  sum(asnl.rcv_unit_qty*jyq_get_db_line_price(poh.po_id,sku.external_sku_id)) db_in_rcv_amount
				FROM purch_po_hdr poh, wms_asn_hdr asnh, wms_asn_dtl asnl,purch_client_sku_master sku
				WHERE asnh.po_id = poh.po_id
				      AND asnh.asn_id = asnl.asn_id
				      AND asnl.status < 99
				      AND asnh.asn_type = '30'
				      AND asnh.status IN (40, 90)
				      AND asnh.asn_type = 30
				      and asnl.sku_code=sku.sku_code
				      AND (poh.whse_code = '380' AND poh.to_whse LIKE 'BJA%')
				      AND datediff(asnh.close_time, curdate()) = -1
				GROUP BY  poh.to_whse) a on (hdr.whse_code=a.whse_code) left join
				  (SELECT
				  poh.to_whse whse_code,
				  count(DISTINCT asnl.sku_code) db_in_rcv_skucount
				FROM purch_po_hdr poh, wms_asn_hdr asnh, wms_asn_dtl asnl
				WHERE asnh.po_id = poh.po_id
				      AND asnh.asn_id = asnl.asn_id
				      AND asnl.status < 99
				      AND asnh.asn_type = '30'
				      AND asnh.status IN (40, 90)
				      AND asnh.asn_type = 30
				      AND (poh.whse_code = '380' AND poh.to_whse LIKE 'BJA%')
				      AND datediff(asnh.close_time, curdate()) = -1
				      AND asnl.rcv_unit_qty > 0
				GROUP BY poh.to_whse) b on (hdr.whse_code=b.whse_code) LEFT JOIN
				  (SELECT
				  poh.to_whse whse_code,
				  sum(asnl.rcv_unit_qty) db_in_store_rcv_qty
				FROM purch_po_hdr poh, wms_asn_hdr asnh, wms_asn_dtl asnl,purch_client_sku_master sku
				WHERE asnh.po_id = poh.po_id
				      AND asnh.asn_id = asnl.asn_id
				      AND asnl.status < 99
				      AND asnh.asn_type = '30'
				      AND asnh.status IN (40, 90)
				      AND asnh.asn_type = 30
				      and asnl.sku_code=sku.sku_code
				      AND datediff(asnh.close_time, curdate()) = -1
				      AND poh.to_whse LIKE 'BJA%' and poh.whse_code REGEXP '^[0-9]{6}$'
				GROUP BY  poh.to_whse) c on (hdr.whse_code=c.whse_code) left join
				  (SELECT
				  soh.whse_code,
				  sum(sol.pick_qty) so_rtn_qty
				FROM wms_db.oms_so_hdr soh,
				  wms_db.oms_so_dtl sol
				WHERE soh.so_id = sol.so_id
				      AND sol.status < 99
				      AND soh.status IN (80)
				      AND soh.so_type = 40
				      AND datediff(soh.close_time, curdate()) = -1
				GROUP BY soh.whse_code) d on (hdr.whse_code=d.whse_code)
				where hdr.whse_code like 'BJA%'
				order by hdr.whse_code;

end;

