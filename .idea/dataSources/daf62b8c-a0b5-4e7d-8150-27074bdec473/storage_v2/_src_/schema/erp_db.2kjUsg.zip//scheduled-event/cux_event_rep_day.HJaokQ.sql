create definer = wmsadmin@`%` event cux_event_rep_day
  on schedule
    every '1' DAY
      starts '2018-05-12 02:00:00'
  on completion preserve
  enable
  comment '日报表定时生成任务'
do
  call rp_day_all();

