create trigger after_update_do
  after UPDATE
  on wms_do_hdr
  for each row
  BEGIN
    
    DECLARE externalTransactionId VARCHAR(1000);
    SET externalTransactionId = old.external_transactionId;
    IF externalTransactionId IS NULL OR externalTransactionId = ''
    THEN
      SET externalTransactionId = old.do_nbr;
    END IF;

    
    IF old.do_type = 10 AND ((old.status NOT IN (98, 99) AND new.status IN (98, 99)) OR
                             (old.do_cancel_flag = 0 AND new.do_cancel_flag = 1))
    THEN
      DELETE FROM wms_do_external_transactionId
      WHERE channel_client_id = old.channel_client_Id AND external_transactionId = externalTransactionId;
    END IF;
    
    IF old.do_type = 10 AND
       ((old.status IN (98, 99) AND new.status NOT IN (98, 99)) OR (old.do_cancel_flag = 1 AND new.do_cancel_flag = 0))
    THEN
      INSERT INTO wms_do_external_transactionId(channel_client_id,external_transactionId,creation_date)
        VALUE (old.channel_client_Id, externalTransactionId,now());
    END IF;
    


    
    IF NEW.do_type = 10
    THEN
      IF (OLD.status <> 0 AND NEW.status = 0) OR (OLD.pre_proc_flag = 0 AND NEW.pre_proc_flag = 1)
      THEN
        INSERT INTO identical_items_stats (channel_client_Id, whse_id, sku1, sku2, cnt, last_modified)
        VALUES (NEW.channel_client_id, NEW.whse_id, NEW.sku_hash1, NEW.sku_hash2, 1, now())
        ON DUPLICATE KEY UPDATE cnt = cnt + 1, last_modified = now();
      ELSEIF OLD.status = 0 AND NEW.status <> 0
        THEN
          UPDATE identical_items_stats
          SET cnt         = cnt - 1,
            last_modified = NOW()
          WHERE channel_client_id = NEW.channel_client_id
                AND whse_id = NEW.whse_id
                AND sku1 = NEW.sku_hash1
                AND sku2 = NEW.sku_hash2
                AND cnt > 0;
      END IF;
    END IF;
  END;

