create view purch_v_auth_sku_master as
  select
    `sku`.`mem_id`            AS `mem_id`,
    `sku`.`mem_code`          AS `mem_code`,
    `sku`.`sku_id`            AS `sku_id`,
    `sku`.`sku_code`          AS `sku_code`,
    `sku`.`sku_type`          AS `sku_type`,
    `sku`.`mfg_sku_code`      AS `mfg_sku_code`,
    `sku`.`sku_name`          AS `sku_name`,
    `sku`.`brand`             AS `brand`,
    `sku`.`BRAND_ID`          AS `brand_id`,
    `sku`.`catalog_1`         AS `catalog_1`,
    `sku`.`catalog_2`         AS `catalog_2`,
    `sku`.`catalog_3`         AS `catalog_3`,
    `sku`.`catalog_4`         AS `catalog_4`,
    `sku`.`catalog_5`         AS `catalog_5`,
    `sku`.`size`              AS `size`,
    `sku`.`color`             AS `color`,
    `sku`.`capacity`          AS `capacity`,
    `sku`.`network_type`      AS `network_type`,
    `sku`.`service_provider`  AS `service_provider`,
    `sku`.`specification`     AS `specification`,
    `sku`.`product_series`    AS `product_series`,
    `sku`.`product_line`      AS `product_line`,
    `sku`.`version`           AS `VERSION`,
    `sku`.`status`            AS `STATUS`,
    `sku`.`creator`           AS `creator`,
    `sku`.`creation_date`     AS `creation_date`,
    `sku`.`modified_by`       AS `modified_by`,
    `sku`.`last_modify_date`  AS `last_modify_date`,
    `cb`.`channel_client_id`  AS `auth_channel_client_id`,
    `cb`.`channel_clinet_nbr` AS `auth_channel_client_nbr`
  from (((`erp_db`.`sys_dict` `d`
    join `erp_db`.`purch_client_brand_master` `cb`
      on (((`d`.`dict_id` = `cb`.`channel_client_id`) and (`cb`.`status` = 10)))) join `erp_db`.`purch_sku_master` `sku`
      on (((`sku`.`BRAND_ID` = `cb`.`brand_id`) and (`sku`.`status` = 10)))) left join
    `erp_db`.`purch_client_sku_master` `csku`
      on (((`sku`.`sku_id` = `csku`.`sku_id`) and (`cb`.`channel_clinet_nbr` = `csku`.`channel_client_nbr`) and
           (`csku`.`status` <= 10))))
  where ((`d`.`dict_type` = 'channelclient') and (isnull(`csku`.`channel_client_id`) or (`csku`.`status` = 90)));

