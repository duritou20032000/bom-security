create function jyq_get_db_line_price(p_po_id varchar(50), p_erp_code varchar(50))
  returns double(13, 4)
  BEGIN
   declare l_order_po_price  DOUBLE(13, 4);
   declare continue HANDLER  for not found set l_order_po_price=0;
   select max(pol.purchase_price)  into l_order_po_price from purch_order_hdr poh,purch_order_dtl pol
     where poh.external_id=p_po_id
     and poh.stockin_hdr_id=pol.stockin_hdr_id
     and pol.item_code=p_erp_code;
  return l_order_po_price;
  end;

