create view wms_v_locn_ailse as
  select distinct
    `erp_db`.`wms_locn_hdr`.`zone`                          AS `zone`,
    `erp_db`.`wms_locn_hdr`.`prefix`                        AS `prefix`,
    `erp_db`.`wms_locn_hdr`.`ailse`                         AS `ailse`,
    `erp_db`.`wms_locn_hdr`.`locn_type`                     AS `locn_type`,
    `erp_db`.`wms_locn_hdr`.`mem_id`                        AS `mem_id`,
    `erp_db`.`wms_locn_hdr`.`mem_code`                      AS `mem_code`,
    `erp_db`.`wms_locn_hdr`.`whse_id`                       AS `whse_id`,
    `erp_db`.`wms_locn_hdr`.`whse_code`                     AS `whse_code`,
    0                                                       AS `STATUS`,
    'system'                                                AS `creator`,
    'system'                                                AS `modified_by`,
    str_to_date('2000-01-01 00:00:00', '%Y-%m-%d %H:%i:%s') AS `creation_date`,
    str_to_date('2000-01-01 00:00:00', '%Y-%m-%d %H:%i:%s') AS `last_modify_date`
  from `erp_db`.`wms_locn_hdr`
  where (`erp_db`.`wms_locn_hdr`.`status` < 99);

