create procedure rp_day_soeff()
  comment '日报表-订单效率明细
'
  begin
/* 执行删除操作 */
delete from rp_report_day_soeff where createtime>=CURDATE();
/* 执行插入操作 */
insert into rp_report_day_soeff
(
  rpid,
  reporttime,
  createtime, 
  whse_code,
  whse_name,
  store_nbr,
  store_name,
  do_nbr,
  so_nbr,
  external_transactionid,
	so_type, 
	so_status,	
	shipto_name,
	shipto_mobile,
	shipto_addr,
	pay_type,	
	sum_money,
	send_unit_qty,
	trade_create_time,
	creation_date,
	wave_end_time,
	pick_end_time,
	pack_time,
	close_time,
	store_received_time,
	received_time)
SELECT 
			 CONCAT("SOEFF",substring(DATE_FORMAT(DATE_SUB(curdate(),INTERVAL 1 DAY),'%Y%m%d'),3)),
			 DATE_SUB(curdate(),INTERVAL 1 DAY),
			 now(),
			 a.whse_code "仓库代码",
       m.whse_name "仓库名称",
       a.store_nbr "门店代码",
       st.store_name "门店名称",
       dohdr.do_nbr "DO单号",
       a.so_nbr "WMS订单号",
       a.external_transactionId "中台订单号",
       a.so_type "订单类型",
       a.status  "订单状态",
       a.shipto_name "收件人姓名",
       a.shipto_mobile "收件人电话",
       concat(a.shipto_city,a.shipto_zone,a.shipto_addr)  "收件人地址",
       a.pay_type  "付款方式",
       jyq_get_order_amount(a.so_id) "订单金额",
       a.send_unit_qty "订单包含商品数量",
       a.trade_create_time "客户下单时间",
       a.creation_date "订单导入时间",
       wavehdr.wave_end_time "波次完成时间",
       dohdr.pick_end_time "拣货完成时间",
       dohdr.pack_Time "复核完成时间",
       dohdr.close_time "出库时间",
       null "门店签收时间",
       a.received_time "客户签收时间"
  FROM wms_db.oms_so_hdr       a,
       wms_carton_hdr cartonhdr,
       wms_do_hdr  dohdr,
       wms_wave_hdr wavehdr,
       wms_whse_master m,
       wms_store_info st
 WHERE a.so_id=cartonhdr.so_id
   and dohdr.do_id=cartonhdr.do_id
   and dohdr.wave_id=wavehdr.wave_id
   and a.store_nbr=st.store_code
   and a.whse_code=m.whse_code
   AND a.status in (80,84,85)
   and a.so_type=10
   and datediff(a.close_time,curdate())=-1;
   
end;

