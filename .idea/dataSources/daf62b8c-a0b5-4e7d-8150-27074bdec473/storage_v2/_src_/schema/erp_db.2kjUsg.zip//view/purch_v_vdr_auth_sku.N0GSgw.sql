create view purch_v_vdr_auth_sku as
  select
    `csku`.`mem_id`             AS `mem_id`,
    `csku`.`mem_code`           AS `mem_code`,
    `csku`.`client_sku_id`      AS `client_sku_id`,
    `csku`.`sku_id`             AS `sku_id`,
    `csku`.`sku_code`           AS `sku_code`,
    `csku`.`sku_type`           AS `sku_type`,
    `csku`.`mfg_sku_code`       AS `mfg_sku_code`,
    `csku`.`sku_name`           AS `sku_name`,
    `csku`.`brand`              AS `brand`,
    `csku`.`brand_id`           AS `brand_id`,
    `csku`.`catalog_1`          AS `catalog_1`,
    `csku`.`catalog_2`          AS `catalog_2`,
    `csku`.`catalog_3`          AS `catalog_3`,
    `csku`.`catalog_4`          AS `catalog_4`,
    `csku`.`catalog_5`          AS `catalog_5`,
    `csku`.`size`               AS `size`,
    `csku`.`color`              AS `color`,
    `csku`.`capacity`           AS `capacity`,
    `csku`.`network_type`       AS `network_type`,
    `csku`.`service_provider`   AS `service_provider`,
    `csku`.`specification`      AS `specification`,
    `csku`.`product_series`     AS `product_series`,
    `csku`.`version`            AS `VERSION`,
    `csku`.`status`             AS `STATUS`,
    `csku`.`creator`            AS `creator`,
    `csku`.`creation_date`      AS `creation_date`,
    `csku`.`modified_by`        AS `modified_by`,
    `csku`.`last_modify_date`   AS `last_modify_date`,
    `csku`.`channel_client_id`  AS `channel_client_id`,
    `csku`.`channel_client_nbr` AS `channel_client_nbr`,
    `vdr`.`vdr_id`              AS `vdr_id`,
    `vdr`.`vdr_code`            AS `vdr_code`,
    `vdr`.`vdr_name`            AS `vdr_name`,
    `svdr`.`vdr_id`             AS `auth_vdr_id`,
    `svdr`.`vdr_code`           AS `auth_vdr_code`
  from ((`erp_db`.`purch_vendor_master` `vdr`
    join `erp_db`.`purch_client_sku_master` `csku`
      on (((`vdr`.`channel_client_Id` = `csku`.`channel_client_id`) and (`vdr`.`status` = 20) and
           (`csku`.`status` <= 10)))) left join `erp_db`.`purch_sku_vdr_attr` `svdr`
      on (((`svdr`.`sku_code` = `csku`.`sku_code`) and (`svdr`.`vdr_id` = `vdr`.`vdr_id`) and (`svdr`.`status` < 99))))
  where isnull(`svdr`.`vdr_id`);

