create procedure update_dashboard()
  BEGIN
  DECLARE l_channel_client_id       VARCHAR(50);
  DECLARE l_channel_client_nbr      VARCHAR(30);
  DECLARE l_whse_code               VARCHAR(30);
  DECLARE l_start_date              DATETIME;
  DECLARE l_end_date                DATETIME;
  DECLARE l_total_qty               INT;
  DECLARE l_new_qty                 INT;
  DECLARE l_new_item_qty            INT;
  DECLARE l_do_new_qty_nextday      INT;
  DECLARE l_do_new_item_qty_nextday INT;
  DECLARE l_wave_qty                INT;
  DECLARE l_pick_qty                INT;
  DECLARE l_pickcomp_qty            INT;
  DECLARE l_sort_qty                INT;
  DECLARE l_sortcomp_qty            INT;
  DECLARE l_pack_qty                INT;
  DECLARE l_packcomp_qty            INT;
  DECLARE l_weighcomp_qty           INT;
  DECLARE l_weighing_qty            INT;
  DECLARE l_load_qty                INT;
  DECLARE l_loadcomp_qty            INT;
  DECLARE l_closed_qty              INT;
  DECLARE l_cancel_qty              INT;
  DECLARE l_reback_no_qty           INT;
  DECLARE l_reback_fail_qty         INT;
  DECLARE l_reback_succ_qty         INT;
  DECLARE l_done                    INT;
  DECLARE l_operation_time          INT;
  DECLARE l_expire_time             TIMESTAMP;
  DECLARE l_expire_qty              INT;
  DECLARE l_before_wave_quick_qty           INT;
  DECLARE l_before_wave_throwaway_qty       INT;
  DECLARE l_after_wave_quick_qty            INT;
  DECLARE l_after_wave_throwaway_qty        INT;

  
  DECLARE c_do CURSOR FOR
    SELECT
      d.channel_client_id,
      d.channel_clinet_nbr,
      d.whse_code,
      SUM(IF((d.status >= 0 AND d.status <= 70), 1, 0)) AS "total_qty",
      SUM(IF(d.status = 0, 1, 0))                       AS "new_qty",
      SUM(IF(d.status = 0, d.ord_unit_qty, 0))          AS "new_item_qty",
      SUM(IF(d.status = 10 OR d.status = 20, 1, 0))     AS "wave_qty",
      SUM(IF(d.status = 25, 1, 0))                      AS "pick_qty",
      SUM(IF(d.status = 30, 1, 0))                      AS "pickcomp_qty",
      SUM(IF(d.status = 35, 1, 0))                      AS "sort_qty",
      SUM(IF(d.status = 40, 1, 0))                      AS "sortcomp_qty",
      SUM(IF(d.status = 55, 1, 0))                      AS "pack_qty",
      SUM(IF(d.status = 60, 1, 0))                      AS "packcomp_qty",
      SUM(IF(d.status = 62, 1, 0))                      AS "weighcomp_qty",
      SUM(IF(d.status = 61, 1, 0))                      AS "weighing_qty",
      SUM(IF(d.status = 98, 1, 0))                      AS "cancel_qty"
    FROM wms_do_hdr d
    WHERE d.status <= 98
          AND d.creation_date >= l_start_date
          AND d.creation_date < l_end_date
          AND d.close_time > '9998-01-01'
    GROUP BY d.channel_client_id, d.channel_clinet_nbr, d.whse_code;

  
  DECLARE c_closed_do CURSOR FOR
    SELECT
      channel_client_id,
      channel_clinet_nbr,
      whse_code,
      count(*)
    FROM wms_do_hdr
    WHERE status = 90 AND close_time >= curdate()
    GROUP BY channel_client_id, channel_clinet_nbr, whse_code;

  
  DECLARE c_wms_whse CURSOR FOR
    SELECT
      whse_code,
      IF(average_operation_time IS NULL, 240, average_operation_time * 60) operation_time
    FROM wms_whse_master
    WHERE status < 99;

  
  DECLARE c_expire_ccid CURSOR FOR
    SELECT
      channel_client_id,
      whse_code,
      COUNT(1) total
    FROM wms_do_hdr
    WHERE whse_code = l_whse_code
          AND STATUS < 90
          AND do_type = 10
          AND do_cancel_flag = 0
          AND lock_flag = 0
          AND shipping_expire_end_time < l_expire_time
          AND close_time >= '9998-01-01'
    GROUP BY channel_client_id, whse_code;

  
  DECLARE c_carton_load CURSOR FOR
    SELECT
      channel_client_id,
      channel_clinet_nbr,
      whse_code,
      SUM(IF(status = 80, 1, 0)) AS "load_qty",
      SUM(IF(status >= 90, 1, 0)) AS "loadcomp_qty"
    FROM wms_carton_hdr
    WHERE
      status IN (80,90,92,94,95)
      AND creation_date > curdate()
    GROUP BY channel_client_id, whse_code;
  
  
  DECLARE c_quick_throwaway_1 CURSOR FOR
    SELECT
      whse.whse_code,
      stats.channel_client_id,
      SUM(IF(stats.cnt >= 10, stats.cnt, 0)) AS quick_qty,
      SUM(IF(stats.cnt < 10, stats.cnt, 0))  AS throwaway_qty
    FROM identical_items_stats stats LEFT JOIN wms_whse_master whse ON stats.whse_id = whse.whse_id AND whse.status < 99
    WHERE
      stats.last_modified > date_add(curdate(), INTERVAL -2 WEEK) 
    GROUP BY whse.whse_code, stats.channel_client_Id;
  
  
  DECLARE c_quick_throwaway_2 CURSOR FOR
    SELECT
      whse_code,
      channel_client_Id,
      SUM(IF(pick_mode = 70 OR quick_pick_mode = 10, 1, 0))                                                     AS quick_qty,
      SUM(IF(pick_mode != 70 ,1,0)) AS throwaway_qty
    FROM wms_do_hdr
    WHERE close_time > '9998-01-01'
          AND do_type =10 
          AND (status > 0 AND status <= 60)
    GROUP BY whse_code, channel_client_Id;

  
  DECLARE c_do_nextday CURSOR FOR
    SELECT
      channel_client_id,
      channel_clinet_nbr,
      whse_code,
      count(*),
      sum(ord_unit_qty)
    FROM wms_do_hdr
    WHERE status = 0
          AND creation_date >= l_end_date
          AND close_time > '9998-01-01'
    GROUP BY channel_client_id, channel_clinet_nbr, whse_code;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET l_done = 1;
  SET l_start_date = curdate() - INTERVAL 5 HOUR - INTERVAL 30 MINUTE;
  SET l_end_date = l_start_date + INTERVAL 1 DAY;
  START TRANSACTION;
  DELETE FROM wms_dashboard;
  DELETE FROM wms_dashboard_past;

  
  INSERT INTO wms_dashboard (channel_client_id, channel_client_nbr, whse_code, total_qty, so_new_qty, so_new_item_qty, lack_qty, last_modify_date)
    SELECT
      channel_client_id,
      channel_clinet_nbr,
      whse_code,
      COUNT(*),
      SUM(IF(status = 0 OR status = 10, 1, 0)),
      SUM(IF(status = 0 OR status = 10, ord_unit_qty, 0)),
      SUM(IF(status = 14, 1, 0)),
      now()
    FROM oms_so_hdr
    WHERE so_type IN (10, 15, 50, 90)
          AND status IN (0, 10, 14)
          AND whse_code IS NOT NULL
          AND close_time > '9998-01-01'
    GROUP BY channel_clinet_nbr, whse_code;

  
  SET l_done = 0;
  OPEN c_do;
  dashboard: LOOP
    FETCH c_do
    INTO l_channel_client_id, l_channel_client_nbr, l_whse_code, l_total_qty,
      l_new_qty, l_new_item_qty, l_wave_qty, l_pick_qty, l_pickcomp_qty, l_sort_qty,
      l_sortcomp_qty, l_pack_qty, l_packcomp_qty, l_weighcomp_qty, l_weighing_qty, l_cancel_qty;
    IF l_done
    THEN
      LEAVE dashboard;
    END IF;
    INSERT INTO wms_dashboard (channel_client_id, channel_client_nbr, whse_code, total_qty, new_qty, do_new_item_qty, wave_qty, pick_qty, pickcomp_qty,
                               sort_qty, sortcomp_qty, pack_qty, packcomp_qty, weighcomp_qty, weighing_qty, cancel_qty, last_modify_date)
    VALUES (l_channel_client_id, l_channel_client_nbr, l_whse_code, l_total_qty, l_new_qty, l_new_item_qty, l_wave_qty, l_pick_qty, l_pickcomp_qty,
                              l_sort_qty, l_sortcomp_qty, l_pack_qty, l_packcomp_qty, l_weighcomp_qty, l_weighing_qty, l_cancel_qty, now())
    ON DUPLICATE KEY UPDATE
      total_qty    = total_qty + l_total_qty, new_qty = l_new_qty, do_new_item_qty = l_new_item_qty,
      wave_qty     = l_wave_qty, pick_qty = l_pick_qty, pickcomp_qty = l_pickcomp_qty,
      sort_qty     = l_sort_qty, sortcomp_qty = l_sortcomp_qty, pack_qty = l_pack_qty,
      packcomp_qty = l_packcomp_qty, weighcomp_qty = l_weighcomp_qty, weighing_qty = l_weighing_qty,
      cancel_qty   = l_cancel_qty, last_modify_date = now();
  END LOOP dashboard;
  CLOSE c_do;

  
  SET l_done = 0;
  OPEN c_closed_do;
  closed_loop: LOOP
    FETCH c_closed_do
    INTO l_channel_client_id, l_channel_client_nbr, l_whse_code, l_closed_qty;
    IF l_done
    THEN
      LEAVE closed_loop;
    END IF;
    INSERT INTO wms_dashboard (channel_client_id, channel_client_nbr, whse_code, total_qty, closed_qty, last_modify_date)
    VALUES (l_channel_client_id, l_channel_client_nbr, l_whse_code, l_closed_qty, l_closed_qty, now())
    ON DUPLICATE KEY UPDATE total_qty = total_qty + l_closed_qty, closed_qty = l_closed_qty, last_modify_date = now();
  END LOOP closed_loop;
  CLOSE c_closed_do;

  
  SET l_done = 0;
  OPEN c_wms_whse;
  c_wms_whse_loop: LOOP
    SET l_done = 0;
    FETCH c_wms_whse
    INTO l_whse_code, l_operation_time;
    IF l_done
    THEN
      LEAVE c_wms_whse_loop;
    END IF;
    SET l_expire_time = date_add(now(), INTERVAL l_operation_time MINUTE);
    OPEN c_expire_ccid;
    expire_ccid_loop: LOOP
      FETCH c_expire_ccid
      INTO l_channel_client_id, l_whse_code, l_expire_qty;
      IF l_done
      THEN
        LEAVE expire_ccid_loop;
      END IF;
      UPDATE wms_dashboard
      SET shipping_expire_qty = l_expire_qty
      WHERE
        channel_client_id = l_channel_client_id
        AND whse_code = l_whse_code;
    END LOOP expire_ccid_loop;
    CLOSE c_expire_ccid;
  END LOOP c_wms_whse_loop;
  CLOSE c_wms_whse;

  
  SET l_done = 0;
  OPEN c_carton_load;
  c_carton_load_loop: LOOP
    FETCH c_carton_load
    INTO l_channel_client_id, l_channel_client_nbr, l_whse_code, l_load_qty,l_loadcomp_qty;
    IF l_done
    THEN
      LEAVE c_carton_load_loop;
    END IF;
    INSERT INTO wms_dashboard (channel_client_id, channel_client_nbr, whse_code, total_qty, load_qty, loadcomp_qty, last_modify_date)
    VALUES (l_channel_client_id, l_channel_client_nbr, l_whse_code, l_closed_qty, l_load_qty,l_loadcomp_qty, now())
    ON DUPLICATE KEY UPDATE total_qty = total_qty, load_qty = l_load_qty, loadcomp_qty = l_loadcomp_qty, last_modify_date = now();
  END LOOP c_carton_load_loop;
  CLOSE c_carton_load;
  
  
  SET l_done = 0;
  OPEN c_quick_throwaway_1;
  c_quick_throwaway_1_loop: LOOP
    FETCH c_quick_throwaway_1
    INTO l_whse_code,l_channel_client_id,l_before_wave_quick_qty,l_before_wave_throwaway_qty;
    IF l_done
    THEN
      LEAVE c_quick_throwaway_1_loop;
    END IF;
      UPDATE wms_dashboard
      SET  before_wave_quick_qty = l_before_wave_quick_qty,before_wave_throwaway_qty = l_before_wave_throwaway_qty
      WHERE
        channel_client_id = l_channel_client_id
        AND whse_code = l_whse_code;
  END LOOP c_quick_throwaway_1_loop;
  CLOSE c_quick_throwaway_1;
  
  
  SET l_done = 0;
  OPEN c_quick_throwaway_2;
  c_quick_throwaway_2_loop: LOOP
    FETCH c_quick_throwaway_2
    INTO l_whse_code,l_channel_client_id, l_after_wave_quick_qty,l_after_wave_throwaway_qty;
    IF l_done
    THEN
      LEAVE c_quick_throwaway_2_loop;
    END IF;
      UPDATE wms_dashboard
      SET after_wave_quick_qty = l_after_wave_quick_qty,after_wave_throwaway_qty = l_after_wave_throwaway_qty
      WHERE
        channel_client_id = l_channel_client_id
        AND whse_code = l_whse_code;
  END LOOP c_quick_throwaway_2_loop;
  CLOSE c_quick_throwaway_2;

  
  INSERT INTO wms_dashboard_past
  (channel_client_id, channel_client_nbr, whse_code, total_qty, new_qty, do_new_item_qty, wave_qty, pick_qty,
   pickcomp_qty, sort_qty, sortcomp_qty, pack_qty, packcomp_qty, weighcomp_qty, weighing_qty,last_modify_date)
    SELECT
      d.channel_client_id,
      d.channel_clinet_nbr,
      d.whse_code,
      SUM(IF((d.status >= 0 AND d.status <= 70), 1, 0)) AS "total_qty",
      SUM(IF(d.status = 0, 1, 0))                       AS "new_qty",
      SUM(IF(d.status = 0, d.ord_unit_qty, 0))          AS "new_item_qty",
      SUM(IF(d.status = 10 OR d.status = 20, 1, 0))     AS "wave_qty",
      SUM(IF(d.status = 25, 1, 0))                      AS "pick_qty",
      SUM(IF(d.status = 30, 1, 0))                      AS "pickcomp_qty",
      SUM(IF(d.status = 35, 1, 0))                      AS "sort_qty",
      SUM(IF(d.status = 40, 1, 0))                      AS "sortcomp_qty",
      SUM(IF(d.status = 55, 1, 0))                      AS "pack_qty",
      SUM(IF(d.status = 60, 1, 0))                      AS "packcomp_qty",
      SUM(IF(d.status = 62, 1, 0))                      AS "weighcomp_qty",
      SUM(IF(d.status = 61, 1, 0))                      AS "weighing_qty",
      now()
    FROM wms_do_hdr d
    WHERE d.status <= 70
          AND d.creation_date < l_start_date
          AND d.close_time > '9998-01-01'
    GROUP BY d.channel_clinet_nbr, d.whse_code;
  COMMIT;

  
  IF (now() > l_end_date)
  THEN
    SET l_done = 0;
    OPEN c_do_nextday;
    nextday_loop: LOOP
      FETCH c_do_nextday
      INTO l_channel_client_id, l_channel_client_nbr, l_whse_code, l_do_new_qty_nextday,
        l_do_new_item_qty_nextday;
      IF l_done
      THEN
        LEAVE nextday_loop;
      END IF;
      INSERT INTO wms_dashboard (channel_client_id, channel_client_nbr, whse_code, do_new_qty_nextday, do_new_item_qty_nextday, last_modify_date)
      VALUES (l_channel_client_id, l_channel_client_nbr, l_whse_code, l_do_new_qty_nextday, l_do_new_item_qty_nextday, now())
      ON DUPLICATE KEY UPDATE do_new_qty_nextday = l_do_new_qty_nextday, do_new_item_qty_nextday = l_do_new_item_qty_nextday, last_modify_date = now();
    END LOOP nextday_loop;
    CLOSE c_do_nextday;
  END IF;
END;

