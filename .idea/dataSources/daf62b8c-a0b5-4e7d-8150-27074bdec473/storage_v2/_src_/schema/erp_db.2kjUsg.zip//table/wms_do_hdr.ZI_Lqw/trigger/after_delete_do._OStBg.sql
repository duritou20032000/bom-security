create trigger after_delete_do
  after DELETE
  on wms_do_hdr
  for each row
  BEGIN
    DECLARE externalTransactionId VARCHAR(100);
    IF old.do_type = 10
    THEN
      SET externalTransactionId = old.external_transactionId;
      IF externalTransactionId IS NULL OR externalTransactionId = ''
      THEN
        SET externalTransactionId = old.do_nbr;
      END IF;
      DELETE FROM wms_do_external_transactionId
      WHERE channel_client_id = old.channel_client_Id AND external_transactionId = externalTransactionId;
    END IF;
  END;

