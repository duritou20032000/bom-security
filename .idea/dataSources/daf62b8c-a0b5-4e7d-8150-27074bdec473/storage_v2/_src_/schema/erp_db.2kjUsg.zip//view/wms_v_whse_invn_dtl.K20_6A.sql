create view wms_v_whse_invn_dtl as
  select
    `a`.`mem_id`                                             AS `mem_id`,
    `a`.`mem_code`                                           AS `mem_code`,
    `a`.`whse_id`                                            AS `whse_id`,
    `a`.`whse_code`                                          AS `whse_code`,
    `a`.`channel_client_id`                                  AS `channel_client_id`,
    `a`.`channel_client_nbr`                                 AS `channel_clinet_nbr`,
    `a`.`sku_id`                                             AS `sku_id`,
    `a`.`sku_code`                                           AS `sku_code`,
    `a`.`vdr_code`                                           AS `vdr_code`,
    `sku`.`sku_name`                                         AS `sku_name`,
    `sku`.`mfg_sku_code`                                     AS `mfg_sku_code`,
    `a`.`xpire_date`                                         AS `xpire_date`,
    if((`a`.`batch_nbr` = ''), NULL, `a`.`batch_nbr`)        AS `batch_nbr`,
    if((`a`.`serial_nbr` = ''), NULL, `a`.`serial_nbr`)      AS `serial_nbr`,
    `a`.`status`                                             AS `status`,
    `a`.`creator`                                            AS `creator`,
    `a`.`creation_date`                                      AS `creation_date`,
    `a`.`last_modify_date`                                   AS `last_modify_date`,
    `a`.`modified_by`                                        AS `modified_by`,
    sum(`a`.`actl_qty`)                                      AS `actl_qty`,
    sum(`a`.`alloc_qty`)                                     AS `alloc_qty`,
    sum(`a`.`repl_qty`)                                      AS `repl_qty`,
    ifnull(`b`.`order_alloc_qty`, 0)                         AS `order_alloc_qty`,
    (sum(`a`.`actl_qty`) - ifnull(`b`.`order_alloc_qty`, 0)) AS `available_qty`
  from ((`erp_db`.`wms_pick_locn_dtl` `a` left join `erp_db`.`purch_client_sku_master` `sku`
      on (((`a`.`sku_id` = `sku`.`sku_id`) and (`a`.`channel_client_id` = `sku`.`channel_client_id`) and
           (`sku`.`status` < 98)))) left join `erp_db`.`wms_v_do_alloc_sku` `b` on ((
    (`a`.`whse_id` = `b`.`whse_id`) and (`a`.`channel_client_id` = `b`.`channel_client_id`) and
    (`a`.`sku_id` = `b`.`sku_id`) and (ifnull(`a`.`batch_nbr`, '') = ifnull(`b`.`batch_nbr`, '')))))
  where ((`a`.`status` < 99) and (`a`.`locn_type` in (30, 31, 40, 70)))
  group by `a`.`whse_id`, `a`.`sku_id`, `a`.`batch_nbr`, `a`.`serial_nbr`, `a`.`xpire_date`, `a`.`channel_client_id`;

