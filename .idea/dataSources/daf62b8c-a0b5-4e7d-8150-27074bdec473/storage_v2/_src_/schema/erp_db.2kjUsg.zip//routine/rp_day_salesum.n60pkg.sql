create procedure rp_day_salesum()
  comment '日报表-销售汇总(-c端)'
  begin
/* 执行删除操作 */
delete from rp_report_day_salesum where createtime>=CURDATE();
/* 执行插入操作 */
insert into rp_report_day_salesum
(
  rpid,
  reporttime,
  createtime,   
  whse_code,
  whse_name,   
  so_order_count,
  so_sale_count,
  so_sale_qty,
  so_sale_amount,
  so_nosale_count,
  so_effcy,
  so_norcv_count,
  cust_price)
SELECT 
			 CONCAT("SALE",substring(DATE_FORMAT(DATE_SUB(curdate(),INTERVAL 1 DAY),'%Y%m%d'),3)),
			 DATE_SUB(curdate(),INTERVAL 1 DAY),
			 now(),
			 hdr.whse_code "仓库代码",
			  hdr.whse_name "仓库名称",
			  ifnull(a.so_order_count,0) "导入订单单量",
			  ifnull(b.so_sale_count,0) "出库订单单量",
			  ifnull(b.so_sale_qty,0) "出库订单商品数量",
			  ifnull(b.so_sale_amount,0) "出库订单金额",
			  ifnull(f.so_nosale_count,0) "未出库订单单量",
			  ifnull(c.so_effcy,0) "配送时效：小时（均值）",
			  ifnull(d.so_norcv_count,0) "未签收订单单量",
			  ifnull(e.cust_price,0) "客单价"
			from wms_whse_master hdr LEFT JOIN
			  (SELECT
			  oh.whse_code,
			  count(oh.so_nbr) so_order_count
			FROM oms_so_hdr oh
			WHERE datediff(oh.creation_date, curdate()) = -1 AND oh.status < 98 AND oh.so_type = 10
			GROUP BY oh.whse_code) a on (hdr.whse_code=a.whse_code) left JOIN
			  (SELECT
			  oh.whse_code,
			  count(DISTINCT oh.so_nbr)           so_sale_count,
			  sum(ol.pick_qty)                   so_sale_qty,
			  sum(ol.market_price * ol.pick_qty) so_sale_amount
			FROM oms_so_hdr oh,
			  oms_so_dtl ol
			WHERE oh.so_id = ol.so_id
			      AND datediff(oh.close_time, curdate()) = -1 AND oh.status IN (80, 84, 85) AND oh.so_type = 10
			GROUP BY oh.whse_code) b on (hdr.whse_code=b.whse_code) left join
			  (SELECT
			  oh.whse_code,
			  sec_to_time(sum(timestampdiff(SECOND,oh.close_time,oh.received_time))/count(oh.so_nbr)) so_effcy
			FROM oms_so_hdr oh
			WHERE datediff(oh.close_time, curdate()) = -1 AND oh.status IN (85) AND oh.so_type = 10
			GROUP BY oh.whse_code) c on (hdr.whse_code=c.whse_code) left join
			  (SELECT
			  oh.whse_code,
			  count(oh.so_nbr) so_norcv_count
			FROM oms_so_hdr oh
			WHERE datediff(oh.close_time, curdate()) = -1 AND oh.status IN (80,84) AND oh.so_type = 10
			GROUP BY oh.whse_code) d on (hdr.whse_code=d.whse_code) left JOIN
			  (SELECT
			  oh.whse_code,
			  round(sum(ol.market_price * ol.pick_qty)/count(DISTINCT oh.so_nbr) ,2)  cust_price
			FROM oms_so_hdr oh,
			  oms_so_dtl ol
			WHERE oh.so_id = ol.so_id
			      AND datediff(oh.close_time, curdate()) = -1 AND oh.status<98 AND oh.so_type = 10
			GROUP BY oh.whse_code) e on (hdr.whse_code=e.whse_code) left join
			  (SELECT
			  oh.whse_code,
			  count(oh.so_nbr) so_nosale_count
			FROM oms_so_hdr oh
			WHERE datediff(oh.creation_date, curdate()) = -1 AND oh.status not IN (80, 84, 85,98) AND oh.so_type = 10
			GROUP BY oh.whse_code) f on (hdr.whse_code=f.whse_code)
			where hdr.whse_code like 'BJA%'
			order by hdr.whse_code;   
end;

