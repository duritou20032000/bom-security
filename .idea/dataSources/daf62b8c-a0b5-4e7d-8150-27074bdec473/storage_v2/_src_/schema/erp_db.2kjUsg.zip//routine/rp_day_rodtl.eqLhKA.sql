create procedure rp_day_rodtl()
  comment '日报表-前置仓调拨单明细'
  begin
/* 执行删除操作 */
delete from rp_report_day_rodtl where createtime>=CURDATE();
/* 执行插入操作 */
insert into rp_report_day_rodtl
( rpid,
  reporttime,
  createtime,    
	asn_type,
	external_transactionid,
	po_nbr,
	asn_nbr,
	closetime,
	to_whse,
	to_whsename,
	whse_code,
	whse_name,
	outofwhsedate,
	external_sku_id,
	sku_code,
	sku_name,
	barcode,
	rcv_unit_qty,
	prod_date,
	shelf_live,
	xpire_date,
	hdr_status
	)
SELECT 
			 CONCAT("RODTL",substring(DATE_FORMAT(DATE_SUB(curdate(),INTERVAL 1 DAY),'%Y%m%d'),3)),
			 DATE_SUB(curdate(),INTERVAL 1 DAY),
			 now(),
       hdr.asn_type  "调拨单类型",
       pohdr.external_transaction_id "外部单号",
       hdr.po_nbr "调拨单号",
       hdr.asn_nbr "ASN/DO单号",
       hdr.close_time "入库完成时间",
       pohdr.to_whse "调入仓代码",
       CASE
         WHEN pohdr.to_whse = '380' THEN
          '北京1号（日立）城市仓库'
         WHEN pohdr.to_whse REGEXP '^[0-9]{6}$' THEN
          concat((SELECT store_name
                   FROM wms_store_info
                  WHERE store_code = pohdr.to_whse),
                 "(",
                 pohdr.to_whse,
                 ")")
         ELSE
          concat((SELECT whse_name
                   FROM wms_whse_master
                  WHERE whse_code = pohdr.to_whse),
                 "(",
                 pohdr.to_whse,
                 ")")
       END AS "调入仓库名称",
       pohdr.whse_code "调出仓代码",
       CASE
         WHEN pohdr.whse_code = '380' THEN
          '北京1号（日立）城市仓库'
         WHEN pohdr.whse_code REGEXP '^[0-9]{6}$' THEN
          concat((SELECT store_name
                   FROM wms_store_info
                  WHERE store_code = pohdr.whse_code),
                 "(",
                 pohdr.whse_code,
                 ")")
         ELSE
          concat((SELECT whse_name
                   FROM wms_whse_master
                  WHERE whse_code = pohdr.whse_code),
                 "(",
                 pohdr.whse_code,
                 ")")
       END AS "调出仓库名称",
       NULL "出库时间",
       sku.external_sku_id "进销存编码",
       sku.sku_code "商品编码",
       sku.sku_name "商品名称",
       CASE
         WHEN bar.barcode1 <> '' THEN
          bar.barcode1
         WHEN bar.barcode2 <> '' THEN
          bar.barcode2
         WHEN bar.barcode3 <> '' THEN
          bar.barcode3
         WHEN bar.barcode4 <> '' THEN
          bar.barcode4
         ELSE
          bar.barcode
       END "商品条码",
       dtl.rcv_unit_qty "实收/实发数量",
       date_sub(jyq_get_xpiredate(dtl.asn_dtl_id),
                INTERVAL sku.shelf_live DAY) "生产日期",
       sku.shelf_live "有效期",
       jyq_get_xpiredate(dtl.asn_dtl_id) "过期日期",
       hdr.status "ASN/DO单状态"
  FROM wms_asn_hdr              hdr,
       wms_asn_dtl              dtl,
       purch_client_sku_master  sku,
       purch_client_sku_barcode bar,
       purch_po_hdr             pohdr
 WHERE hdr.asn_id = dtl.asn_id
   AND dtl.sku_id = sku.sku_id
   AND sku.sku_id = bar.client_sku_id
   AND hdr.po_id = pohdr.po_id
   AND dtl.status < 99
   AND sku.status = 10
   AND hdr.status IN (40,
                      90)
   AND hdr.asn_type = 30
   AND NOT (pohdr.whse_code = 380 AND pohdr.to_whse REGEXP '^[0-9]{6}$')
   AND NOT (pohdr.to_whse = 380 AND pohdr.whse_code REGEXP '^[0-9]{6}$')
   AND datediff(hdr.close_time,
                curdate()) = -1
 UNION ALL
SELECT   
 			CONCAT("RODTL",substring(DATE_FORMAT(DATE_SUB(curdate(),INTERVAL 1 DAY),'%Y%m%d'),3)),
			 DATE_SUB(curdate(),INTERVAL 1 DAY),
			 now(),
			 do_type  "调拨单类型",
       a.external_transactionId "外部单号",
       a.so_nbr "调拨单号",
       a.do_nbr "ASN/DO单号",
       null "入库完成时间",
       a.shipto_code "调入仓编码",
       CASE
         WHEN a.shipto_code = '380' THEN
          '北京1号（日立）城市仓库'
         WHEN a.shipto_code REGEXP '^[0-9]{6}$' THEN
          concat((SELECT store_name
                   FROM wms_store_info
                  WHERE store_code = a.shipto_code),
                 "(",
                 a.shipto_code,
                 ")")
         ELSE
          concat((SELECT whse_name
                   FROM wms_whse_master
                  WHERE whse_code = a.shipto_code),
                 "(",
                 a.shipto_code,
                 ")")
       END AS "调入仓库名称",
       a.whse_code "调出仓编码",
       CASE
         WHEN a.whse_code = '380' THEN
          '北京1号（日立）城市仓库'
         WHEN a.whse_code REGEXP '^[0-9]{6}$' THEN
          concat((SELECT store_name
                   FROM wms_store_info
                  WHERE store_code = a.whse_code),
                 "(",
                 a.whse_code,
                 ")")
         ELSE
          concat((SELECT whse_name
                   FROM wms_whse_master
                  WHERE whse_code = a.whse_code),
                 "(",
                 a.whse_code,
                 ")")
       END AS "调出仓库名称",
       a.close_time "出库时间",
       c.external_sku_id "进销存编码",
       c.sku_code "商品编码",
       c.sku_name "商品名称",
      case when d.barcode1<>'' then d.barcode1
       when d.barcode2<>'' then d.barcode2
       when d.barcode3<>'' then d.barcode3
       when d.barcode4<>'' then d.barcode4
       else d.barcode
       end "商品条码",
       cartondtl.unit_qty "实收/实发数量",
              date_sub(cartondtl.xpire_date,
                INTERVAL c.shelf_live DAY) "生产日期",
          c.shelf_live "有效期",
       cartondtl.xpire_date "过期日期",
              case
       when a.status=0 then '新建'
       when a.status=10 then '波次进行中'
       when a.status=20 then '波次完成'
       when a.status=25 then '拣货中'
       when a.status=30 then '拣货完成'
       when a.status=35 then '分拣进行中'
       when a.status=40 then '分拣完成'
       when a.status=55 then '包装中'
       when a.status=60 then '包装完成'
       when a.status=61 then '称重中'
       when a.status=62 then '称重完成'
       when a.status=64 then '提交报关'
       when a.status=65 then '报关失败'
       when a.status=66 then '报关成功'
       when a.status=69 then '装车中'
       when a.status=70 then '装车完成'
       when a.status=80 then '预出库'
       when a.status=90 then '已发货'
       when a.status=95 then '结算完成'
       when a.status=98 then '已取消'
       when a.status=-1 then '未知状态'
       else  a.status end "ASN/DO单状态"
  FROM wms_do_hdr               a,
       wms_carton_hdr           cartonhdr,
       wms_carton_dtl            cartondtl,
       purch_client_sku_master  c,
       purch_client_sku_barcode d,
       purch_po_hdr poh
 WHERE a.do_id = cartonhdr.do_id
  and poh.po_id=cartonhdr.so_id
  and cartondtl.ctn_id=cartonhdr.ctn_id
   AND cartondtl.sku_code = c.sku_code
   AND c.sku_id = d.client_sku_id
   AND a.do_type = '30'
   AND a.status = '90'
   AND cartondtl.status < 99
   and datediff(a.close_time,curdate())=-1;
end;

