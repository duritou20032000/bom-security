create procedure rp_day_sodtl()
  comment '日报表-订单商品明细报表'
  begin
/* 执行删除操作 */
delete from rp_report_day_sodtl where createtime>=CURDATE();
/* 执行插入操作 */
insert into rp_report_day_sodtl
(
  rpid,
  reporttime,
  createtime, 
  close_time,
  whse_code,
  whse_name,
  store_nbr,
  store_name,
  do_nbr,
  so_nbr,
  external_transactionid,
  so_type, 
  so_status,
  external_sku_id,
  sku_code,
  sku_name,
  barcode,
  cost_price,
  unit_qty,
  sum_money,
  prod_date,
  shelf_live,
  xpire_date
)
SELECT 
			 CONCAT("SODTL",substring(DATE_FORMAT(DATE_SUB(curdate(),INTERVAL 1 DAY),'%Y%m%d'),3)),
			 DATE_SUB(curdate(),INTERVAL 1 DAY),
			 now(),
			 a.close_time "出库时间",
       a.whse_code "仓库代码",
        m.whse_name "仓库名称",
        a.store_nbr "门店代码",
        st.store_name "门店名称",
        dohdr.do_nbr "DO单号",
        a.so_nbr "WMS订单号",
        a.external_transactionId "中台订单号",
        a.so_type "订单类型",
        a.status  "订单状态",
       sku.external_sku_id "进销存编码",
       sku.sku_code "商品编码",
       sku.sku_name "商品名称",
       case when bar.barcode1<>'' then bar.barcode1
       when bar.barcode2<>'' then bar.barcode2
       when bar.barcode3<>'' then bar.barcode3
       when bar.barcode4<>'' then bar.barcode4
       else bar.barcode
       end "商品条码",
       sku.cost_price "成本价",
       cartondtl.unit_qty "数量",
       jyq_get_order_line_price(cartonhdr.so_id,cartondtl.sku_code)*cartondtl.unit_qty "金额",
              date_sub(cartondtl.xpire_date,
                INTERVAL sku.shelf_live DAY) "生产日期",
          sku.shelf_live "有效期",
       cartondtl.xpire_date "过期日期"
  FROM wms_db.oms_so_hdr       a,
       wms_carton_hdr cartonhdr,
       wms_carton_dtl cartondtl,
       wms_do_hdr  dohdr,
       wms_whse_master m,
       wms_store_info st,
       purch_client_sku_master sku,
       purch_client_sku_barcode bar
 WHERE a.so_id=cartonhdr.so_id
   and dohdr.do_id=cartonhdr.do_id
   and cartonhdr.ctn_id=cartondtl.ctn_id
   and a.store_nbr=st.store_code
   and a.whse_code=m.whse_code
   and cartondtl.sku_code=sku.sku_code
   and sku.sku_id=bar.client_sku_id
   AND a.status in (80,84,85)
   and a.so_type=10
   and datediff(a.close_time,curdate())=-1;  
end;

