create procedure rp_week_all()
  BEGIN

call rp_weeksuma();
call rp_weeksumb();

END;

