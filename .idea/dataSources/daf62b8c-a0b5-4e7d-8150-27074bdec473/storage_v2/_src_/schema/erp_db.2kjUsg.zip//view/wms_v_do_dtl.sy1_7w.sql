create view wms_v_do_dtl as
  select
    `dtl`.`sku_id`                   AS `sku_id`,
    `dtl`.`sku_code`                 AS `sku_code`,
    `dtl`.`pick_qty`                 AS `pick_qty`,
    `hdr`.`so_nbr`                   AS `so_nbr`,
    `hdr`.`do_nbr`                   AS `do_nbr`,
    cast(`hdr`.`close_time` as date) AS `close_date`,
    `vdr`.`vdr_id`                   AS `vdr_id`,
    `vdr`.`vdr_code`                 AS `vdr_code`,
    `hdr`.`channel_client_Id`        AS `channel_client_id`,
    `hdr`.`channel_clinet_nbr`       AS `channel_clinet_nbr`
  from (((`erp_db`.`wms_do_dtl` `dtl` left join `erp_db`.`wms_do_hdr` `hdr`
      on ((`dtl`.`do_nbr` = `hdr`.`do_nbr`))) left join `erp_db`.`purch_sku_master` `sku`
      on ((`dtl`.`sku_id` = `sku`.`sku_id`))) left join `erp_db`.`purch_sku_vdr_attr` `vdr`
      on ((`sku`.`item` = `vdr`.`ITEM_NBR`)))
  where ((`hdr`.`status` = 90) and (`hdr`.`do_type` = 10));

