create view wms_v_asn_dtl as
  select
    `sku`.`catalog_1`                                                           AS `catalog_1`,
    `sku`.`catalog_2`                                                           AS `catalog_2`,
    `sku`.`catalog_3`                                                           AS `catalog_3`,
    `sku`.`BRAND_ID`                                                            AS `brand_id`,
    `m`.`brand_name`                                                            AS `brand_name`,
    `vdr`.`vdr_id`                                                              AS `vdr_id`,
    `vdr`.`vdr_name`                                                            AS `vdr_name`,
    `sku`.`sku_id`                                                              AS `sku_id`,
    `sku`.`sku_code`                                                            AS `sku_code`,
    `sku`.`sku_name`                                                            AS `sku_name`,
    `sku`.`mfg_sku_code`                                                        AS `mfg_sku_code`,
    `sku`.`item`                                                                AS `item`,
    `invhist`.`actl_qty_delta`                                                  AS `actl_qty_delta`,
    `asndtl`.`cost`                                                             AS `cost`,
    `asndtl`.`cost_no_tax`                                                      AS `cost_no_tax`,
    (ifnull(`invhist`.`actl_qty_delta`, 0) * ifnull(`asndtl`.`cost`, 0))        AS `totalcost`,
    (ifnull(`invhist`.`actl_qty_delta`, 0) * ifnull(`asndtl`.`cost_no_tax`, 0)) AS `totalcostnotax`,
    `invhist`.`status`                                                          AS `status`,
    `invhist`.`event_type`                                                      AS `event_type`,
    `invhist`.`to_locn_type`                                                    AS `to_locn_type`,
    `lpnhdr`.`lpn_id`                                                           AS `lpn_id`,
    `lpnhdr`.`lpn_nbr`                                                          AS `lpn_nbr`,
    `asnhdr`.`asn_id`                                                           AS `asn_id`,
    `asnhdr`.`asn_nbr`                                                          AS `asn_nbr`,
    `asnhdr`.`asn_type`                                                         AS `asn_type`,
    `asnhdr`.`po_id`                                                            AS `po_id`,
    `asnhdr`.`po_nbr`                                                           AS `po_nbr`,
    `invhist`.`whse_id`                                                         AS `whse_id`,
    `invhist`.`whse_code`                                                       AS `whse_code`,
    `invhist`.`mem_id`                                                          AS `mem_id`,
    `invhist`.`mem_code`                                                        AS `mem_code`,
    `invhist`.`creation_date`                                                   AS `creation_date`,
    `invhist`.`last_modify_date`                                                AS `last_modify_date`,
    `invhist`.`creator`                                                         AS `creator`,
    `invhist`.`modified_by`                                                     AS `modified_by`
  from ((((((((`erp_db`.`wms_lpn_inv_hist` `invhist`
    join `erp_db`.`wms_lpn_hdr` `lpnhdr` on ((`invhist`.`lpn_id` = `lpnhdr`.`lpn_id`))) join
    `erp_db`.`wms_lpn_dtl` `lpndtl`
      on (((`invhist`.`lpn_id` = `lpndtl`.`lpn_id`) and (`invhist`.`sku_id` = `lpndtl`.`sku_id`)))) left join
    `erp_db`.`wms_asn_hdr` `asnhdr` on ((`asnhdr`.`asn_id` = `lpnhdr`.`asn_id`))) left join
    `erp_db`.`wms_asn_dtl` `asndtl`
      on (((`asnhdr`.`asn_id` = `asndtl`.`asn_id`) and (`invhist`.`sku_id` = `asndtl`.`sku_id`)))) join
    `erp_db`.`purch_sku_master` `sku` on ((`invhist`.`sku_id` = `sku`.`sku_id`))) left join
    `erp_db`.`purch_brand_master` `m` on ((`m`.`brand_id` = `sku`.`BRAND_ID`))) left join
    `erp_db`.`purch_sku_vdr_attr` `skuvdr` on ((`skuvdr`.`ITEM_NBR` = `sku`.`item`))) left join
    `erp_db`.`purch_vendor_master` `vdr` on ((`vdr`.`vdr_id` = `skuvdr`.`vdr_id`)))
  where (`asndtl`.`status` <> 99);

