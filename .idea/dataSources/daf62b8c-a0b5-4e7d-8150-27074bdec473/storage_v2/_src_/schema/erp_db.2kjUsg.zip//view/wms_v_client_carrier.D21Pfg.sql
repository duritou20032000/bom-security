create view wms_v_client_carrier as
  select distinct
    `a`.`carr_id`            AS `carr_id`,
    `b`.`carr_code`          AS `carr_code`,
    `b`.`carr_name`          AS `carr_name`,
    `b`.`carr_type`          AS `carr_type`,
    `a`.`channel_client_id`  AS `channel_client_id`,
    `a`.`channel_client_nbr` AS `channel_client_nbr`,
    `b`.`mem_id`             AS `mem_id`,
    `b`.`mem_code`           AS `mem_code`,
    `b`.`creation_date`      AS `creation_date`,
    `b`.`last_modify_date`   AS `last_modify_date`,
    `b`.`creator`            AS `creator`,
    `b`.`modified_by`        AS `modified_by`,
    `b`.`status`             AS `status`
  from (`erp_db`.`wms_carriage_template` `a`
    join `erp_db`.`wms_carrier_master` `b`)
  where ((`a`.`carr_id` = `b`.`carr_id`) and (`a`.`status` = '10'));

