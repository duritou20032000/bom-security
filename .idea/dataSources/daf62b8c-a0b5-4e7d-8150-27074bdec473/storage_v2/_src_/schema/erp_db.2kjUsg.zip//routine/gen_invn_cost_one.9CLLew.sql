create procedure gen_invn_cost_one(IN p_record_date date)
  BEGIN
  DECLARE l_sp_name                   VARCHAR(50) DEFAULT 'gen_invn_cost_one';
  DECLARE l_output                    VARCHAR(500);
  DECLARE l_sqlcode                   CHAR(5) DEFAULT '00000';
  DECLARE l_msg                       TEXT;
  DECLARE l_job_log_id                VARCHAR(50);
  DECLARE l_done                      INT DEFAULT 0;
  DECLARE l_row_count_ins             INT;
  DECLARE l_row_count_upd             INT;
  DECLARE l_count                     INT;
  DECLARE l_last_record_date          DATETIME;
  DECLARE l_next_date                 DATETIME;
  DECLARE l_latest_date               DATE;
  DECLARE l_asn_id                    VARCHAR(50);
  DECLARE l_asn_type                  INT;
  DECLARE l_mem_id                    VARCHAR(50);
  DECLARE l_mem_code                  VARCHAR(30);
  DECLARE l_whse_id                   VARCHAR(50);
  DECLARE l_whse_code                 VARCHAR(30);
  DECLARE l_cdc_whse_id               VARCHAR(50);
  DECLARE l_cdc_whse_code             VARCHAR(30);
  DECLARE l_sku_id                    VARCHAR(50);
  DECLARE l_sku_code                  VARCHAR(30);
  DECLARE l_sku_name                  VARCHAR(100);
  DECLARE l_channel_client_id         VARCHAR(50);
  DECLARE l_channel_client_nbr        VARCHAR(50);
  DECLARE l_actl_qty_delta            DOUBLE;
  DECLARE l_max_date                  DATETIME;
  DECLARE l_invn_cost_id              VARCHAR(50);
  DECLARE l_init_cost                 DOUBLE;
  DECLARE l_init_cost_no_tax          DOUBLE;
  DECLARE l_cost                      DOUBLE;
  DECLARE l_cost_no_tax               DOUBLE;
  DECLARE l_asn_cost                  DOUBLE;
  DECLARE l_asn_cost_no_tax           DOUBLE;
  DECLARE l_do_id                     VARCHAR(50);
  DECLARE l_do_type                   INT;
  DECLARE l_pick_qty                  DOUBLE;
  DECLARE l_dodtl_cost                DOUBLE;
  DECLARE l_dodtl_cost_no_tax         DOUBLE;
  DECLARE l_actl_qty                  DOUBLE;
  DECLARE l_pld_all_qty               DOUBLE;
  DECLARE l_lpn_all_qty               DOUBLE;
  DECLARE l_max_creation_date         DATETIME;
  DECLARE l_status                    INT;
  DECLARE l_tax_rate                  DOUBLE;
  DECLARE l_init_invn_qty             DOUBLE;
  DECLARE l_init_amount               DOUBLE;
  DECLARE l_end_invn_qty              DOUBLE;
  DECLARE l_rcv_in_qty                DOUBLE;
  DECLARE l_rcv_in_amount             DOUBLE;
  DECLARE l_allot_in_qty              DOUBLE;
  DECLARE l_allot_in_amount           DOUBLE;
  DECLARE l_allot_out_qty             DOUBLE;
  DECLARE l_allot_out_amount          DOUBLE;
  DECLARE l_rtv_out_qty               DOUBLE;
  DECLARE l_rtv_out_amount            DOUBLE;
  DECLARE l_adj_amount                DOUBLE;
  DECLARE l_error_flag                INT;
  DECLARE l_order_type                INT;
  DECLARE l_sku_type                  INT;
  DECLARE l_other_in_qty              DOUBLE;
  DECLARE l_other_in_amount           DOUBLE;
  DECLARE l_other_out_qty             DOUBLE;
  DECLARE l_other_out_amount          DOUBLE;

  DECLARE l_client_cost_cal_cfg       INT;

  DECLARE c_lpn_hist_rcve             CURSOR FOR
    SELECT d.asn_id, d.mem_id, d.mem_code, d.whse_id, d.whse_code,
      asn.channel_client_id, asn.channel_client_nbr, d.sku_id, d.sku_code,
      d.actl_qty_delta, asn.asn_type
    FROM wms_lpn_inv_hist d INNER JOIN wms_asn_hdr asn
      ON d.asn_id = asn.asn_id
    WHERE d.creation_date >= p_record_date AND d.creation_date < l_next_date
      AND d.event_type = 100 AND d.status < 99 AND asn.status < 99;
  DECLARE c_asn_dtl                   CURSOR FOR
    SELECT ifnull(cost, 0.0), ifnull(cost_no_tax, 0.0)
    FROM wms_asn_dtl
    WHERE asn_id = l_asn_id AND sku_code = l_sku_code AND whse_id = l_whse_id
      AND status < 99;
  DECLARE c_do_hdr                    CURSOR FOR
    SELECT do_id, do_type, channel_client_id, whse_id
    FROM wms_do_hdr
    WHERE status >= 90 AND status <= 95 AND close_time >= p_record_date
      AND close_time < l_next_date AND ifnull(test_flag,0) = 0;
  DECLARE c_do_dtl                    CURSOR FOR
    SELECT own_client_id, sku_code, pick_qty, cost, cost_no_tax
    FROM wms_do_dtl
    WHERE do_id = l_do_id AND status < 99;
  DECLARE c_lpn_snap                  CURSOR FOR
    SELECT d.mem_id, d.mem_code, d.whse_id, d.whse_code, h.channel_client_id,
      h.channel_client_nbr, d.sku_id, d.sku_code, d.sku_name, d.actl_qty
    FROM wms_lpn_dtl_snap d INNER JOIN wms_lpn_hdr h
      ON d.lpn_id = h.lpn_id
    WHERE d.snap_date = p_record_date AND d.orig_status >= 30 AND
      d.orig_status <= 40 AND d.actl_qty <> 0.0 AND d.status < 99
      AND h.status < 99;
  DECLARE c_pld_snap                  CURSOR FOR
    SELECT s.mem_id, s.mem_code, s.whse_id, s.whse_code, s.channel_client_id,
      s.channel_client_nbr, s.sku_id, s.sku_code, p.sku_name, s.actl_qty
    FROM wms_pick_locn_snap s INNER JOIN purch_client_sku_master p ON
      s.sku_code = p.sku_code AND s.channel_client_id = p.channel_client_id
    WHERE s.snap_date = p_record_date AND s.actl_qty <> 0.0
      AND s.status < 99 AND p.status < 90;
  DECLARE c_invn_cost_error           CURSOR FOR
    SELECT invn_cost_id, sku_code, whse_id, channel_client_id, end_invn_qty
    FROM wms_invn_cost
    WHERE record_date = p_record_date AND status IS NULL;
  DECLARE c_invn_cost                 CURSOR FOR
    SELECT channel_client_id, sku_code, cdc_whse_code, init_cost,  init_cost_no_tax,
      SUM(init_invn_qty) init_invn_qty,
      SUM(init_invn_qty*IFNULL(init_cost,0.0)) init_invn_amount,
      SUM(rcv_in_qty) rcv_in_qty, SUM(rcv_in_amount) rcv_in_amount,
      SUM(allot_in_qty) allot_in_qty, SUM(allot_in_amount) allot_in_amount,
      SUM(allot_out_qty) allot_out_qty, SUM(allot_out_amount) allot_out_amount,
      SUM(rtv_out_qty) rtv_out_qty, SUM(rtv_out_amount) rtv_out_amount,
      SUM(po_adj_amount) po_adj_amount, SUM(other_in_qty) other_in_qty,
      SUM(other_in_amount) other_in_amount, SUM(other_out_qty) other_out_qty,
      SUM(other_out_amount) other_out_amount
    FROM wms_invn_cost
    WHERE record_date = p_record_date
    GROUP BY channel_client_id, sku_code, cdc_whse_code;
  DECLARE c_cost_update_log           CURSOR FOR
    SELECT sku_code, channel_client_id, whse_code, update_cost, update_cost_no_tax
    FROM wms_invn_cost_update_log
    WHERE update_date = p_record_date AND status < 99
    ORDER BY creation_date;
  DECLARE c_virtual_db                CURSOR FOR
    SELECT h.mem_id, h.mem_code, h.channel_client_id, h.channel_client_nbr,
      d.sku_id, d.sku_code, d.rcv_unit_qty, w.whse_id, w.whse_code,
      d.cost, d.cost_no_tax
    FROM wms_asn_dtl d INNER JOIN wms_asn_hdr h ON d.asn_id = h.asn_id
      INNER JOIN wms_whse_master w ON h.whse_id = w.whse_id
    WHERE w.whse_type = 20 AND h.asn_type = 30 AND h.status = 90
      AND h.close_time >= p_record_date
      AND h.close_time < l_next_date;
  DECLARE c_po_adj                    CURSOR FOR
    SELECT h.channel_client_id, h.whse_id, d.sku_code, d.actl_amount
    FROM purch_po_hdr h INNER JOIN purch_po_dtl d ON h.po_id = d.po_id
    WHERE h.status >= 44 and h.status < 98 AND h.po_type = 45 AND d.status < 99
      AND h.audit_date >= p_record_date
      AND h.audit_date < l_next_date;
  DECLARE c_workorder                 CURSOR FOR
    SELECT h.channel_client_id, h.channel_client_nbr, h.whse_id, h.whse_code, d.sku_code, h.workorder_type,
      d.workorder_sku_type, d.material_qty*h.complete_qty, d.sku_cost
    FROM wms_workorder_hdr h INNER JOIN wms_workorder_dtl d ON h.workorder_id = d.workorder_id
    WHERE h.status >= 60 AND h.status < 98 AND d.status < 99 AND h.close_time >= p_record_date
      AND h.close_time < l_next_date;


  DECLARE CONTINUE HANDLER FOR NOT FOUND SET l_done = 1;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      GET DIAGNOSTICS CONDITION 1
        l_sqlcode = RETURNED_SQLSTATE, l_msg = MESSAGE_TEXT;
      SET l_output = CONCAT('SQL failed: error = ', l_sqlcode, ' message = ',
        l_msg);
      SELECT l_output AS "Error:";
      CALL log_output(l_sp_name, l_output);
    END;


  START TRANSACTION;
  SET l_job_log_id = CONCAT('JOBLOG-',uuid());
  INSERT INTO sys_job_log (job_log_id, job_processor_class, job_processor_name,
    job_start_time, job_note, mem_id, mem_code, creation_date, last_modify_date,
    creator, modified_by, status)
    SELECT l_job_log_id, l_sp_name,
    'Generate daily inventory cost',
    now(), p_record_date, 'main', 'main', now(), now(),
    'batchrunner', 'batchrunner', 0;
  COMMIT;

  START TRANSACTION;

  SET l_last_record_date = adddate(p_record_date, -1);
  SET l_next_date = adddate(p_record_date, 1);
  SET l_latest_date = adddate(curdate(), -1);



  INSERT INTO wms_invn_cost (invn_cost_id, mem_id, mem_code, whse_id, whse_code,
    cdc_whse_code, sku_id, sku_code, sku_name, batch_nbr, record_date, init_cost,
    init_cost_no_tax, init_invn_qty, channel_client_id, channel_clinet_nbr,
    end_invn_qty, rcv_in_qty, rcv_in_amount, rcv_in_amount_no_tax,
    rtn_in_qty, rtn_in_amount, rtn_in_amount_no_tax,
    allot_in_qty, allot_in_amount, allot_in_amount_no_tax,
    stock_take_in_qty, stock_take_in_amount, stock_take_in_amount_no_tax,
    in_trans_qty, in_trans_amount, in_trans_amount_no_tax,
    other_in_qty, other_in_amount, other_in_amount_no_tax,
    sale_out_qty, sale_out_amount, sale_out_amount_no_tax,
    rtv_out_qty, rtv_out_amount, rtv_out_amount_no_tax,
    allot_out_qty, allot_out_amount, allot_out_amount_no_tax,
    stock_take_out_qty, stock_take_out_amount, stock_take_out_amount_no_tax,
    damage_out_qty, damage_out_amount, damage_out_amount_no_tax,
    scrap_out_qty, scrap_out_amount, scrap_out_amount_no_tax,
    other_out_qty, other_out_amount, other_out_amount_no_tax,
    catalog_1, catalog_2, catalog_3, catalog_4, catalog_5,
    color, size, brand_id, cost, cost_no_tax, sku_type, item,
    mfg_sku_code, brand_name,
    creation_date, last_modify_date, creator, modified_by)
    SELECT CONCAT('invncost-', uuid()), c.mem_id, c.mem_code, c.whse_id, c.whse_code,
    c.cdc_whse_code, c.sku_id, c.sku_code, c.sku_name, c.batch_nbr, p_record_date, c.end_invn_cost,
    c.end_invn_cost_no_tax, c.end_invn_qty, c.channel_client_id, c.channel_clinet_nbr,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    c.catalog_1, c.catalog_2, c.catalog_3, c.catalog_4, c.catalog_5,
    c.color, c.size, c.brand_id, ifnull(sc.cost, p.cost),
    ifnull(sc.cost_no_tax, p.cost_no_tax), c.sku_type, c.item,
    c.mfg_sku_code, c.brand_name,
    now(), now(), 'batchrunner', 'batchrunner'
    FROM wms_invn_cost c inner join purch_client_sku_master p
      on c.channel_client_id = p.channel_client_id AND
      c.sku_code = p.sku_code and p.status < 90
      left join purch_sku_cost sc
      on c.channel_client_id = sc.channel_client_id AND
      c.sku_code = sc.sku_code AND c.cdc_whse_code = sc.cdc_whse_code
    WHERE c.record_date = l_last_record_date;

  SET l_output = CONCAT('Step 1 - From last invn cost record: ', row_count(),
    ' rows inserted');
  SELECT l_output AS "Status:";
  CALL log_output(l_sp_name, l_output);


  SET l_row_count_ins = 0;
  SET l_row_count_upd = 0;
  OPEN c_lpn_hist_rcve;
  lpn_hist_loop: LOOP
    SET l_done = 0;
    SET l_channel_client_id = NULL;
    FETCH c_lpn_hist_rcve INTO l_asn_id, l_mem_id, l_mem_code, l_whse_id,
      l_whse_code, l_channel_client_id, l_channel_client_nbr, l_sku_id,
      l_sku_code, l_actl_qty_delta, l_asn_type;
    IF (l_done = 1) THEN
      LEAVE lpn_hist_loop;
    END IF;
    IF (l_channel_client_id IS NULL) THEN

        SET l_output = CONCAT('Step 2 Error: ASN ', l_asn_id, 'SKU ', l_sku_code);
        SELECT l_output AS "Status:";
        CALL log_output(l_sp_name, l_output);
        ITERATE lpn_hist_loop;
    END IF;


    OPEN c_asn_dtl;
    FETCH c_asn_dtl INTO l_asn_cost, l_asn_cost_no_tax;
    CLOSE c_asn_dtl;

    SET l_invn_cost_id = NULL;
    SELECT invn_cost_id INTO l_invn_cost_id
      FROM wms_invn_cost
      WHERE record_date = p_record_date AND sku_code = l_sku_code
        AND whse_id = l_whse_id AND channel_client_id = l_channel_client_id;

    IF (l_invn_cost_id IS NULL) THEN
      SET l_cost = NULL;
      SET l_cost_no_tax = NULL;


      SET l_cdc_whse_id = NULL;
      SET l_cdc_whse_code = NULL;
      SELECT pwhse_id, pwhse_code INTO l_cdc_whse_id, l_cdc_whse_code
        FROM wms_client_whse
        WHERE channel_client_id = l_channel_client_id AND
          whse_id = l_whse_id;
      IF (l_cdc_whse_id IS NULL || l_cdc_whse_id = '') THEN
        SET l_cdc_whse_id = l_whse_id;
        SET l_cdc_whse_code = l_whse_code;
      END IF;
      SELECT cost, cost_no_tax INTO l_cost, l_cost_no_tax
        FROM purch_sku_cost
        WHERE sku_code = l_sku_code AND channel_client_id = l_channel_client_id
          AND cdc_whse_id = l_cdc_whse_id;
      IF (l_cost IS NULL || l_cost_no_tax IS NULL) THEN
        SELECT cost, cost_no_tax INTO l_cost, l_cost_no_tax
          FROM purch_client_sku_master
          WHERE sku_code = l_sku_code AND channel_client_id = l_channel_client_id
            AND status < 90;
      END IF;

      IF (l_cost IS NULL || l_cost_no_tax IS NULL) THEN

        SET l_max_date = NULL;
        SELECT max(record_date) INTO l_max_date
          FROM wms_invn_cost
          WHERE sku_code = l_sku_code AND whse_id = l_whse_id
            AND channel_client_id = l_channel_client_id;
        IF (l_max_date IS NOT NULL) THEN
          SELECT cost, cost_no_tax INTO l_cost, l_cost_no_tax
            FROM wms_invn_cost
            WHERE record_date = l_max_date AND sku_code = l_sku_code
              AND whse_id = l_whse_id
              AND channel_client_id = l_channel_client_id;
        END IF;
      END IF;

      IF (l_cost IS NULL || l_cost_no_tax IS NULL) THEN
        SET l_cost = l_asn_cost;
        SET l_cost_no_tax = l_asn_cost_no_tax;
      END IF;

      SET l_invn_cost_id = CONCAT('invncost-',uuid());

      INSERT INTO wms_invn_cost (invn_cost_id, mem_id, mem_code, whse_id,
        whse_code, cdc_whse_code, sku_id, sku_code, sku_name, record_date, init_cost,
        init_cost_no_tax, channel_client_id, channel_clinet_nbr, init_invn_qty,
        end_invn_qty, rcv_in_qty, rcv_in_amount, rcv_in_amount_no_tax,
        rtn_in_qty, rtn_in_amount, rtn_in_amount_no_tax,
        allot_in_qty, allot_in_amount, allot_in_amount_no_tax,
        stock_take_in_qty, stock_take_in_amount, stock_take_in_amount_no_tax,
        in_trans_qty, in_trans_amount, in_trans_amount_no_tax,
        other_in_qty, other_in_amount, other_in_amount_no_tax,
        sale_out_qty, sale_out_amount, sale_out_amount_no_tax,
        rtv_out_qty, rtv_out_amount, rtv_out_amount_no_tax,
        allot_out_qty, allot_out_amount, allot_out_amount_no_tax,
        stock_take_out_qty, stock_take_out_amount, stock_take_out_amount_no_tax,
        damage_out_qty, damage_out_amount, damage_out_amount_no_tax,
        scrap_out_qty, scrap_out_amount, scrap_out_amount_no_tax,
        other_out_qty, other_out_amount, other_out_amount_no_tax,
        catalog_1, catalog_2, catalog_3, catalog_4, catalog_5,
        color, size, brand_id, cost, cost_no_tax, sku_type, item,
        mfg_sku_code, brand_name,
        creation_date, last_modify_date, creator, modified_by)
        SELECT l_invn_cost_id, l_mem_id, l_mem_code, l_whse_id, l_whse_code,
        l_cdc_whse_code,
        l_sku_id, l_sku_code, pc.sku_name, p_record_date, l_cost,
        l_cost_no_tax, l_channel_client_id, l_channel_client_nbr, 0.0, 0.0,
        0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
        0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
        0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
        pc.catalog_1, pc.catalog_2, pc.catalog_3, pc.catalog_4, pc.catalog_5,
        pc.color, pc.size, pc.brand_id, ifnull(sc.cost, pc.cost),
        ifnull(sc.cost_no_tax, pc.cost_no_tax), pc.sku_type, pc.item,
        pc.mfg_sku_code, b.brand_name,
        now(), now(), 'batchrunner', 'batchrunner'
        FROM purch_client_sku_master pc
          LEFT JOIN purch_sku_cost sc ON pc.channel_client_id = sc.channel_client_id
            AND pc.sku_code = sc.sku_code AND sc.cdc_whse_id = l_cdc_whse_id
          LEFT JOIN purch_brand_master b ON pc.brand_id = b.brand_id
        WHERE pc.sku_code = l_sku_code AND pc.channel_client_id = l_channel_client_id
          AND pc.status < 90;
      SET l_row_count_ins = l_row_count_ins + 1;
    END IF;


    CASE l_asn_type
    WHEN 10 THEN
      UPDATE wms_invn_cost
        SET rcv_in_qty = rcv_in_qty + l_actl_qty_delta,
          rcv_in_amount = round(rcv_in_amount+l_asn_cost*l_actl_qty_delta,4),
          rcv_in_amount_no_tax = round(rcv_in_amount_no_tax +
            l_asn_cost_no_tax * l_actl_qty_delta,4)
        WHERE invn_cost_id = l_invn_cost_id;
      SET l_row_count_upd = l_row_count_upd + row_count();
    WHEN 50 THEN
      UPDATE wms_invn_cost
        SET rcv_in_qty = rcv_in_qty + l_actl_qty_delta,
          rcv_in_amount = round(rcv_in_amount+l_asn_cost*l_actl_qty_delta,4),
          rcv_in_amount_no_tax = round(rcv_in_amount_no_tax +
            l_asn_cost_no_tax * l_actl_qty_delta,4)
        WHERE invn_cost_id = l_invn_cost_id;
      SET l_row_count_upd = l_row_count_upd + row_count();
    WHEN 20 THEN
      UPDATE wms_invn_cost
        SET rtn_in_qty = rtn_in_qty + l_actl_qty_delta,
          rtn_in_amount = round(rtn_in_amount+init_cost*l_actl_qty_delta,4),
          rtn_in_amount_no_tax = round(rtn_in_amount_no_tax +
            init_cost_no_tax * l_actl_qty_delta,4)
        WHERE invn_cost_id = l_invn_cost_id;
      SET l_row_count_upd = l_row_count_upd + row_count();
    WHEN 30 THEN
      UPDATE wms_invn_cost
        SET allot_in_qty = allot_in_qty + l_actl_qty_delta,
          allot_in_amount = round(allot_in_amount+l_asn_cost*l_actl_qty_delta,4),
          allot_in_amount_no_tax = round(allot_in_amount_no_tax +
            l_asn_cost_no_tax * l_actl_qty_delta,4)
        WHERE invn_cost_id = l_invn_cost_id;
      SET l_row_count_upd = l_row_count_upd + row_count();
    WHEN 40 THEN
      UPDATE wms_invn_cost
        SET stock_take_in_qty = stock_take_in_qty + l_actl_qty_delta,
          stock_take_in_amount = round(stock_take_in_amount +
            init_cost * l_actl_qty_delta,4),
          stock_take_in_amount_no_tax = round(stock_take_in_amount_no_tax +
            init_cost_no_tax * l_actl_qty_delta,4)
        WHERE invn_cost_id = l_invn_cost_id;
      SET l_row_count_upd = l_row_count_upd + row_count();
    ELSE
      UPDATE wms_invn_cost
        SET other_in_qty = other_in_qty + l_actl_qty_delta,
          other_in_amount = round(other_in_amount+l_asn_cost*l_actl_qty_delta,4),
          other_in_amount_no_tax = round(other_in_amount_no_tax +
            l_asn_cost_no_tax * l_actl_qty_delta,4)
        WHERE invn_cost_id = l_invn_cost_id;
      SET l_row_count_upd = l_row_count_upd + row_count();
    END CASE;
  END LOOP lpn_hist_loop;
  CLOSE c_lpn_hist_rcve;

  SET l_output = CONCAT('Step 2 - From lpn hist: ', l_row_count_ins,
    ' rows inserted, ', l_row_count_upd, ' rows updated');
  SELECT l_output AS "Status:";
  CALL log_output(l_sp_name, l_output);


  SET l_row_count_ins = 0;
  SET l_row_count_upd = 0;
  OPEN c_virtual_db;
  virtual_db_loop: LOOP
    SET l_done = 0;
    SET l_channel_client_id = NULL;
    FETCH c_virtual_db INTO l_mem_id, l_mem_code, l_channel_client_id,
      l_channel_client_nbr, l_sku_id, l_sku_code, l_actl_qty_delta,
      l_whse_id, l_whse_code, l_cost, l_cost_no_tax;
    IF (l_done = 1) THEN
      LEAVE virtual_db_loop;
    END IF;

    SET l_invn_cost_id = NULL;
    SELECT invn_cost_id INTO l_invn_cost_id
      FROM wms_invn_cost
      WHERE record_date = p_record_date AND sku_code = l_sku_code
        AND whse_id = l_whse_id AND channel_client_id = l_channel_client_id;

    IF (l_invn_cost_id IS NULL) THEN
      SET l_invn_cost_id = CONCAT('invncost-',uuid());

      INSERT INTO wms_invn_cost (invn_cost_id, mem_id, mem_code, whse_id,
        whse_code, cdc_whse_code, sku_id, sku_code, sku_name, record_date, init_cost,
        init_cost_no_tax, channel_client_id, channel_clinet_nbr, init_invn_qty,
        end_invn_qty, rcv_in_qty, rcv_in_amount, rcv_in_amount_no_tax,
        rtn_in_qty, rtn_in_amount, rtn_in_amount_no_tax,
        allot_in_qty, allot_in_amount, allot_in_amount_no_tax,
        stock_take_in_qty, stock_take_in_amount, stock_take_in_amount_no_tax,
        in_trans_qty, in_trans_amount, in_trans_amount_no_tax,
        other_in_qty, other_in_amount, other_in_amount_no_tax,
        sale_out_qty, sale_out_amount, sale_out_amount_no_tax,
        rtv_out_qty, rtv_out_amount, rtv_out_amount_no_tax,
        allot_out_qty, allot_out_amount, allot_out_amount_no_tax,
        stock_take_out_qty, stock_take_out_amount, stock_take_out_amount_no_tax,
        damage_out_qty, damage_out_amount, damage_out_amount_no_tax,
        scrap_out_qty, scrap_out_amount, scrap_out_amount_no_tax,
        other_out_qty, other_out_amount, other_out_amount_no_tax,
        catalog_1, catalog_2, catalog_3, catalog_4, catalog_5,
        color, size, brand_id, cost, cost_no_tax, sku_type, item,
        mfg_sku_code, brand_name,
        creation_date, last_modify_date, creator, modified_by)
        SELECT l_invn_cost_id, l_mem_id, l_mem_code, l_whse_id, l_whse_code,
        IF(w.pwhse_code IS NULL OR w.pwhse_code = '', l_whse_code, w.pwhse_code),
        l_sku_id, l_sku_code, pc.sku_name, p_record_date, l_cost,
        l_cost_no_tax, l_channel_client_id, l_channel_client_nbr, 0.0, 0.0,
        0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
        0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
        0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
        pc.catalog_1, pc.catalog_2, pc.catalog_3, pc.catalog_4, pc.catalog_5,
        pc.color, pc.size, pc.brand_id, pc.cost, pc.cost_no_tax, pc.sku_type, pc.item,
        pc.mfg_sku_code, b.brand_name,
        now(), now(), 'batchrunner', 'batchrunner'
      FROM purch_client_sku_master pc INNER JOIN wms_client_whse w
        ON pc.channel_client_id = w.channel_client_id
          AND w.whse_id = l_whse_id
        LEFT JOIN purch_brand_master b ON pc.brand_id = b.brand_id
      WHERE pc.sku_code = l_sku_code AND pc.channel_client_id = l_channel_client_id
        AND pc.status < 90;
      SET l_row_count_ins = l_row_count_ins + 1;
    END IF;
    UPDATE wms_invn_cost
      SET allot_in_qty = allot_in_qty + l_actl_qty_delta,
          allot_in_amount = round(allot_in_amount+l_cost*l_actl_qty_delta,4),
          allot_in_amount_no_tax = round(allot_in_amount_no_tax +
          l_cost_no_tax * l_actl_qty_delta,4)
      WHERE invn_cost_id = l_invn_cost_id;
    SET l_row_count_upd = l_row_count_upd + row_count();
  END LOOP virtual_db_loop;
  CLOSE c_virtual_db;

  SET l_output = CONCAT('Step 2.1 - From asn dtl: ', l_row_count_ins,
    ' rows inserted, ', l_row_count_upd, ' rows updated');
  SELECT l_output AS "Status:";
  CALL log_output(l_sp_name, l_output);


  SET l_row_count_ins = 0;
  SET l_row_count_upd = 0;
  OPEN c_workorder;
  workorder_loop: LOOP
    SET l_done = 0;
    FETCH c_workorder INTO l_channel_client_id, l_channel_client_nbr, l_whse_id, l_whse_code, l_sku_code,
      l_order_type, l_sku_type, l_actl_qty, l_cost;
    IF (l_done = 1) THEN
      LEAVE workorder_loop;
    END IF;
    SELECT ifnull(tax_rate, 0.0) INTO l_tax_rate
    FROM purch_client_sku_master
    WHERE sku_code = l_sku_code AND channel_client_id = l_channel_client_id AND status < 90;
    SET l_cost_no_tax = round(l_cost/(1+(l_tax_rate/100)));
    SET l_invn_cost_id = NULL;
    SELECT invn_cost_id INTO l_invn_cost_id
    FROM wms_invn_cost
    WHERE record_date = p_record_date AND channel_client_id = l_channel_client_id
          AND whse_id = l_whse_id AND sku_code = l_sku_code;
    IF (l_invn_cost_id IS NULL) THEN

      SET l_cdc_whse_id = NULL;
      SET l_cdc_whse_code = NULL;
      SELECT pwhse_id, pwhse_code INTO l_cdc_whse_id, l_cdc_whse_code
      FROM wms_client_whse
      WHERE channel_client_id = l_channel_client_id AND
            whse_id = l_whse_id;
      IF (l_cdc_whse_id IS NULL || l_cdc_whse_id = '') THEN
        SET l_cdc_whse_id = l_whse_id;
        SET l_cdc_whse_code = l_whse_code;
      END IF;


      SET l_invn_cost_id = CONCAT('invncost-',uuid());
      INSERT INTO wms_invn_cost (invn_cost_id, mem_id, mem_code, whse_id,
                                 whse_code, cdc_whse_code, sku_id, sku_code, sku_name, record_date, init_cost,
                                 init_cost_no_tax, channel_client_id, channel_clinet_nbr,
                                 init_invn_qty, end_invn_qty, rcv_in_qty, rcv_in_amount,
                                 rcv_in_amount_no_tax, rtn_in_qty, rtn_in_amount, rtn_in_amount_no_tax,
                                 allot_in_qty, allot_in_amount, allot_in_amount_no_tax,
                                 stock_take_in_qty, stock_take_in_amount, stock_take_in_amount_no_tax,
                                 in_trans_qty, in_trans_amount, in_trans_amount_no_tax,
                                 other_in_qty, other_in_amount, other_in_amount_no_tax,
                                 sale_out_qty, sale_out_amount, sale_out_amount_no_tax,
                                 rtv_out_qty, rtv_out_amount, rtv_out_amount_no_tax,
                                 allot_out_qty, allot_out_amount, allot_out_amount_no_tax,
                                 stock_take_out_qty, stock_take_out_amount, stock_take_out_amount_no_tax,
                                 damage_out_qty, damage_out_amount, damage_out_amount_no_tax,
                                 scrap_out_qty, scrap_out_amount, scrap_out_amount_no_tax,
                                 other_out_qty, other_out_amount, other_out_amount_no_tax,
                                 catalog_1, catalog_2, catalog_3, catalog_4, catalog_5,
                                 color, size, brand_id, cost, cost_no_tax, sku_type, item,
                                 mfg_sku_code, brand_name,
                                 creation_date, last_modify_date, creator, modified_by)
        SELECT l_invn_cost_id, 'main', 'main', l_whse_id, l_whse_code,
          l_cdc_whse_code,
          pc.sku_id, pc.sku_code, pc.sku_name, p_record_date, l_cost,
          l_cost_no_tax, l_channel_client_id, l_channel_client_nbr,
          0.0, 0.0, 0.0, 0.0,
          0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
          0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
          0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
          pc.catalog_1, pc.catalog_2, pc.catalog_3, pc.catalog_4, pc.catalog_5,
          pc.color, pc.size, pc.brand_id, IFNULL(sc.cost, pc.cost),
          IFNULL(sc.cost_no_tax, pc.cost_no_tax), pc.sku_type, pc.item,
          pc.mfg_sku_code, b.brand_name,
          now(), now(), 'batchrunner', 'batchrunner'
        FROM purch_client_sku_master pc LEFT JOIN purch_sku_cost sc
            ON pc.channel_client_id = sc.channel_client_id AND
               pc.sku_code = sc.sku_code AND sc.cdc_whse_id = l_cdc_whse_id
          LEFT JOIN purch_brand_master b
            ON pc.brand_id = b.brand_id
        WHERE pc.sku_code = l_sku_code AND pc.channel_client_id = l_channel_client_id
              AND pc.status < 90;
      SET l_row_count_ins = l_row_count_ins + row_count();
    END IF;
    IF ((l_order_type = 10 AND l_sku_type = 10) OR
        (l_order_type = 20 AND l_sku_type = 20)) THEN
      UPDATE wms_invn_cost
      SET other_in_qty = other_in_qty + l_actl_qty, other_in_amount = round(other_in_amount+l_cost*l_actl_qty,4),
        other_in_amount_no_tax =  round(other_in_amount_no_tax+l_cost*l_actl_qty/(1+(l_tax_rate/100)),4)
      WHERE invn_cost_id = l_invn_cost_id;
      SET l_row_count_upd = l_row_count_upd + row_count();
    ELSE
      UPDATE wms_invn_cost
      SET other_out_qty = other_out_qty + l_actl_qty, other_out_amount = round(other_out_amount+l_cost*l_actl_qty,4),
        other_out_amount_no_tax = round(other_out_amount_no_tax+l_cost*l_actl_qty/(1+(l_tax_rate/100)),4)
      WHERE invn_cost_id = l_invn_cost_id;
      SET l_row_count_upd = l_row_count_upd + row_count();
    END IF;

  END LOOP workorder_loop;
  CLOSE c_workorder;

  SET l_output = CONCAT('Step 2.2 - Calculate Workorder: ', l_row_count_ins,
                        ' invn_cost rows inserted, ', l_row_count_upd, ' invn_cost rows updated');
  SELECT l_output AS "Status:";
  CALL log_output(l_sp_name, l_output);


  SET l_row_count_ins = 0;
  SET l_row_count_upd = 0;
  OPEN c_do_hdr;
  do_hdr_loop: LOOP
    SET l_done = 0;
    FETCH c_do_hdr INTO l_do_id, l_do_type, l_channel_client_id, l_whse_id;
    IF (l_done = 1) THEN
      LEAVE do_hdr_loop;
    END IF;

    OPEN c_do_dtl;
    do_dtl_loop: LOOP
      SET l_done = 0;
      FETCH c_do_dtl INTO l_channel_client_id, l_sku_code, l_pick_qty, l_dodtl_cost,
        l_dodtl_cost_no_tax;
      IF (l_done = 1) THEN
        LEAVE do_dtl_loop;
      END IF;
      SET l_invn_cost_id = NULL;
      SELECT invn_cost_id INTO l_invn_cost_id
        FROM wms_invn_cost
        WHERE sku_code = l_sku_code AND whse_id = l_whse_id
          AND channel_client_id = l_channel_client_id
          AND record_date = p_record_date;
      IF l_invn_cost_id IS NULL THEN

        IF (l_sku_code <> 'SKU0000011477') THEN
          SET l_output = CONCAT('Step 3 Error: Invalid sku_code in invn cost ',
            l_sku_code, ' do_id: ', l_do_id);
          SELECT l_output AS "Status:";
          CALL log_output(l_sp_name, l_output);
        END IF;
      ELSE
        CASE l_do_type
        WHEN 10 THEN
          UPDATE wms_invn_cost
            SET sale_out_qty = sale_out_qty + l_pick_qty,
              sale_out_amount = round(sale_out_amount + l_pick_qty * init_cost,4),
              sale_out_amount_no_tax = round(sale_out_amount_no_tax +
                l_pick_qty * init_cost_no_tax,4)
            WHERE invn_cost_id = l_invn_cost_id;
          SET l_row_count_upd = l_row_count_upd + row_count();
        WHEN 20 THEN
          UPDATE wms_invn_cost
            SET rtv_out_qty = rtv_out_qty + l_pick_qty,
              rtv_out_amount = round(rtv_out_amount + l_pick_qty * ifnull(l_dodtl_cost,init_cost),4),
              rtv_out_amount_no_tax = round(rtv_out_amount_no_tax +
                l_pick_qty * ifnull(l_dodtl_cost_no_tax,init_cost_no_tax),4)
            WHERE invn_cost_id = l_invn_cost_id;
          SET l_row_count_upd = l_row_count_upd + row_count();
        WHEN 30 THEN
          UPDATE wms_invn_cost
            SET allot_out_qty = allot_out_qty + l_pick_qty,
              allot_out_amount = round(allot_out_amount + l_pick_qty * ifnull(l_dodtl_cost,init_cost),4),
              allot_out_amount_no_tax = round(allot_out_amount_no_tax +
                l_pick_qty * ifnull(l_dodtl_cost_no_tax,init_cost_no_tax),4)
            WHERE invn_cost_id = l_invn_cost_id;
          SET l_row_count_upd = l_row_count_upd + row_count();
        WHEN 40 THEN
          UPDATE wms_invn_cost
            SET damage_out_qty = damage_out_qty + l_pick_qty,
              damage_out_amount = round(damage_out_amount + l_pick_qty * init_cost,4),
              damage_out_amount_no_tax = round(damage_out_amount_no_tax +
                l_pick_qty * init_cost_no_tax,4)
            WHERE invn_cost_id = l_invn_cost_id;
          SET l_row_count_upd = l_row_count_upd + row_count();
        WHEN 50 THEN
          UPDATE wms_invn_cost
            SET scrap_out_qty = scrap_out_qty + l_pick_qty,
              scrap_out_amount = round(scrap_out_amount + l_pick_qty * init_cost,4),
              scrap_out_amount_no_tax = round(scrap_out_amount_no_tax +
                l_pick_qty * init_cost_no_tax,4)
            WHERE invn_cost_id = l_invn_cost_id;
          SET l_row_count_upd = l_row_count_upd + row_count();
        WHEN 60 THEN
          UPDATE wms_invn_cost
            SET stock_take_out_qty = stock_take_out_qty + l_pick_qty,
              stock_take_out_amount = round(stock_take_out_amount +
                l_pick_qty * init_cost,4),
              stock_take_out_amount_no_tax = round(stock_take_out_amount_no_tax +
                l_pick_qty * init_cost_no_tax,4)
            WHERE invn_cost_id = l_invn_cost_id;
          SET l_row_count_upd = l_row_count_upd + row_count();
        ELSE
          UPDATE wms_invn_cost
            SET other_out_qty = other_out_qty + l_pick_qty,
              other_out_amount = round(other_out_amount + l_pick_qty * init_cost,4),
              other_out_amount_no_tax = round(other_out_amount_no_tax +
                l_pick_qty * init_cost_no_tax,4)
            WHERE invn_cost_id = l_invn_cost_id;
          SET l_row_count_upd = l_row_count_upd + row_count();
        END CASE;
      END IF;
    END LOOP do_dtl_loop;
    CLOSE c_do_dtl;
  END LOOP do_hdr_loop;
  CLOSE c_do_hdr;

  SET l_output = CONCAT('Step 3 - From dodtl: ', l_row_count_ins,
    ' rows inserted, ', l_row_count_upd, ' rows updated');
  SELECT l_output AS "Status:";
  CALL log_output(l_sp_name, l_output);


  OPEN c_po_adj;
  po_adj_loop: LOOP
    SET l_done = 0;
    FETCH c_po_adj INTO l_channel_client_id, l_whse_id, l_sku_code, l_adj_amount;
    IF (l_done = 1) THEN
      LEAVE po_adj_loop;
    END IF;
    SET l_invn_cost_id = NULL;
    SELECT invn_cost_id INTO l_invn_cost_id
    FROM wms_invn_cost
    WHERE record_date = p_record_date AND channel_client_id = l_channel_client_id
          AND whse_id = l_whse_id AND sku_code = l_sku_code;
    IF (l_invn_cost_id IS NULL) THEN
      SET l_output = CONCAT('PO Adjustment Error: Can not find cost entry: ',
                            l_channel_client_id, ':', l_whse_id, ':', l_sku_code, ':', l_adj_amount);
      SELECT l_output AS "Error:";
      CALL log_output(l_sp_name, l_output);
    ELSE
      UPDATE wms_invn_cost
      SET po_adj_amount = l_adj_amount
      WHERE invn_cost_id = l_invn_cost_id;
    END IF;
  END LOOP po_adj_loop;
  CLOSE c_po_adj;


  SET l_row_count_ins = 0;
  SET l_row_count_upd = 0;
  OPEN c_lpn_snap;
  lpn_snap_loop: LOOP
    SET l_done = 0;
    FETCH c_lpn_snap INTO l_mem_id, l_mem_code, l_whse_id, l_whse_code,
      l_channel_client_id, l_channel_client_nbr, l_sku_id, l_sku_code,
      l_sku_name, l_actl_qty;
    IF l_done = 1 THEN
      LEAVE lpn_snap_loop;
    END IF;
    IF l_actl_qty <> 0 THEN
      SET l_invn_cost_id = NULL;
      SELECT invn_cost_id INTO l_invn_cost_id
        FROM wms_invn_cost
        WHERE record_date = p_record_date AND sku_code = l_sku_code AND
          whse_id = l_whse_id AND channel_client_id = l_channel_client_id;
      IF l_invn_cost_id IS NULL THEN
        SET l_max_date = NULL;
        SELECT max(record_date) INTO l_max_date
          FROM wms_invn_cost
          WHERE sku_code = l_sku_code AND whse_id = l_whse_id AND
            channel_client_id = l_channel_client_id;
        IF l_max_date IS NULL THEN
          SET l_init_invn_qty = 0;
          SET l_cost = 0.0;
          SET l_cost_no_tax = 0.0;
        ELSE
          SELECT end_invn_qty, end_invn_cost, end_invn_cost_no_tax
            INTO l_init_invn_qty, l_cost, l_cost_no_tax
            FROM wms_invn_cost
            WHERE sku_code = l_sku_code AND whse_id = l_whse_id AND
              channel_client_id = l_channel_client_id AND
              record_date = l_max_date;
        END IF;


        SET l_cdc_whse_id = NULL;
        SET l_cdc_whse_code = NULL;
        SELECT pwhse_id, pwhse_code INTO l_cdc_whse_id, l_cdc_whse_code
          FROM wms_client_whse
          WHERE channel_client_id = l_channel_client_id AND
            whse_id = l_whse_id;
        IF (l_cdc_whse_id IS NULL || l_cdc_whse_id = '') THEN
          SET l_cdc_whse_id = l_whse_id;
          SET l_cdc_whse_code = l_whse_code;
        END IF;


        SET l_invn_cost_id = CONCAT('invncost-',uuid());
        INSERT INTO wms_invn_cost (invn_cost_id, mem_id, mem_code, whse_id,
          whse_code, cdc_whse_code, sku_id, sku_code, sku_name, record_date, init_cost,
          init_cost_no_tax, channel_client_id, channel_clinet_nbr,
          init_invn_qty, end_invn_qty, rcv_in_qty, rcv_in_amount,
          rcv_in_amount_no_tax, rtn_in_qty, rtn_in_amount, rtn_in_amount_no_tax,
          allot_in_qty, allot_in_amount, allot_in_amount_no_tax,
          stock_take_in_qty, stock_take_in_amount, stock_take_in_amount_no_tax,
          in_trans_qty, in_trans_amount, in_trans_amount_no_tax,
          other_in_qty, other_in_amount, other_in_amount_no_tax,
          sale_out_qty, sale_out_amount, sale_out_amount_no_tax,
          rtv_out_qty, rtv_out_amount, rtv_out_amount_no_tax,
          allot_out_qty, allot_out_amount, allot_out_amount_no_tax,
          stock_take_out_qty, stock_take_out_amount, stock_take_out_amount_no_tax,
          damage_out_qty, damage_out_amount, damage_out_amount_no_tax,
          scrap_out_qty, scrap_out_amount, scrap_out_amount_no_tax,
          other_out_qty, other_out_amount, other_out_amount_no_tax,
          catalog_1, catalog_2, catalog_3, catalog_4, catalog_5,
          color, size, brand_id, cost, cost_no_tax, sku_type, item,
          mfg_sku_code, brand_name,
          creation_date, last_modify_date, creator, modified_by)
          SELECT l_invn_cost_id, l_mem_id, l_mem_code, l_whse_id, l_whse_code,
          l_cdc_whse_code,
          l_sku_id, l_sku_code, pc.sku_name, p_record_date, l_cost,
          l_cost_no_tax, l_channel_client_id, l_channel_client_nbr,
          l_init_invn_qty, 0.0, 0.0, 0.0,
          0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
          0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
          0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
          pc.catalog_1, pc.catalog_2, pc.catalog_3, pc.catalog_4, pc.catalog_5,
          pc.color, pc.size, pc.brand_id, IFNULL(sc.cost, pc.cost),
          IFNULL(sc.cost_no_tax, pc.cost_no_tax), pc.sku_type, pc.item,
          pc.mfg_sku_code, b.brand_name,
          now(), now(), 'batchrunner', 'batchrunner'
        FROM purch_client_sku_master pc LEFT JOIN purch_sku_cost sc
          ON pc.channel_client_id = sc.channel_client_id AND
            pc.sku_code = sc.sku_code AND sc.cdc_whse_id = l_cdc_whse_id
          LEFT JOIN purch_brand_master b ON pc.brand_id = b.brand_id
        WHERE pc.sku_code = l_sku_code AND pc.channel_client_id = l_channel_client_id
          AND pc.status < 90;
        SET l_row_count_ins = l_row_count_ins + row_count();
      END IF;
      UPDATE wms_invn_cost
        SET end_invn_qty = end_invn_qty + l_actl_qty
        WHERE invn_cost_id = l_invn_cost_id;
      SET l_row_count_upd = l_row_count_upd + row_count();
    END IF;
  END LOOP lpn_snap_loop;
  CLOSE c_lpn_snap;

  SET l_output = CONCAT('Step 4.1 - From lpn snap: ', l_row_count_ins,
    ' rows inserted, ', l_row_count_upd, ' rows updated');
  SELECT l_output AS "Status:";
  CALL log_output(l_sp_name, l_output);

  SET l_row_count_ins = 0;
  SET l_row_count_upd = 0;
  OPEN c_pld_snap;
  pld_snap_loop: LOOP
    SET l_done = 0;
    FETCH c_pld_snap INTO l_mem_id, l_mem_code, l_whse_id, l_whse_code,
      l_channel_client_id, l_channel_client_nbr, l_sku_id, l_sku_code,
      l_sku_name, l_actl_qty;
    IF l_done = 1 THEN
      LEAVE pld_snap_loop;
    END IF;
    IF l_actl_qty <> 0 THEN
      SET l_invn_cost_id = NULL;
      SELECT invn_cost_id INTO l_invn_cost_id
        FROM wms_invn_cost
        WHERE record_date = p_record_date AND sku_code = l_sku_code AND
          whse_id = l_whse_id AND channel_client_id = l_channel_client_id;
      IF l_invn_cost_id IS NULL THEN
        SET l_max_date = NULL;
        SELECT max(record_date) INTO l_max_date
          FROM wms_invn_cost
          WHERE sku_code = l_sku_code AND whse_id = l_whse_id
            AND channel_client_id = l_channel_client_id;
        IF l_max_date IS NULL THEN
          SET l_init_invn_qty = 0;
          SET l_cost = 0.0;
          SET l_cost_no_tax = 0.0;
        ELSE
          SELECT end_invn_qty, end_invn_cost, end_invn_cost_no_tax
            INTO l_init_invn_qty, l_cost, l_cost_no_tax
            FROM wms_invn_cost
            WHERE sku_code = l_sku_code AND whse_id = l_whse_id
              AND channel_client_id = l_channel_client_id
              AND record_date = l_max_date;
        END IF;


        SET l_cdc_whse_id = NULL;
        SET l_cdc_whse_code = NULL;
        SELECT pwhse_id, pwhse_code INTO l_cdc_whse_id, l_cdc_whse_code
          FROM wms_client_whse
          WHERE channel_client_id = l_channel_client_id AND
            whse_id = l_whse_id;
        IF (l_cdc_whse_id IS NULL || l_cdc_whse_id = '') THEN
          SET l_cdc_whse_id = l_whse_id;
          SET l_cdc_whse_code = l_whse_code;
        END IF;


        SET l_invn_cost_id = CONCAT('invncost-',uuid());
        INSERT INTO wms_invn_cost (invn_cost_id, mem_id, mem_code, whse_id,
          whse_code, cdc_whse_code, sku_id, sku_code, sku_name, record_date, init_cost,
          init_cost_no_tax, channel_client_id, channel_clinet_nbr,
          init_invn_qty, end_invn_qty, rcv_in_qty, rcv_in_amount,
          rcv_in_amount_no_tax, rtn_in_qty, rtn_in_amount, rtn_in_amount_no_tax,
          allot_in_qty, allot_in_amount, allot_in_amount_no_tax,
          stock_take_in_qty, stock_take_in_amount, stock_take_in_amount_no_tax,
          in_trans_qty, in_trans_amount, in_trans_amount_no_tax,
          other_in_qty, other_in_amount, other_in_amount_no_tax,
          sale_out_qty, sale_out_amount, sale_out_amount_no_tax,
          rtv_out_qty, rtv_out_amount, rtv_out_amount_no_tax,
          allot_out_qty, allot_out_amount, allot_out_amount_no_tax,
          stock_take_out_qty, stock_take_out_amount, stock_take_out_amount_no_tax,
          damage_out_qty, damage_out_amount, damage_out_amount_no_tax,
          scrap_out_qty, scrap_out_amount, scrap_out_amount_no_tax,
          other_out_qty, other_out_amount, other_out_amount_no_tax,
          catalog_1, catalog_2, catalog_3, catalog_4, catalog_5,
          color, size, brand_id, cost, cost_no_tax, sku_type, item,
          mfg_sku_code, brand_name,
          creation_date, last_modify_date, creator, modified_by)
          SELECT l_invn_cost_id, l_mem_id, l_mem_code, l_whse_id, l_whse_code,
          l_cdc_whse_code,
          l_sku_id, l_sku_code, pc.sku_name, p_record_date, l_cost,
          l_cost_no_tax, l_channel_client_id, l_channel_client_nbr,
          l_init_invn_qty, 0.0, 0.0, 0.0,
          0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
          0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
          0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
          pc.catalog_1, pc.catalog_2, pc.catalog_3, pc.catalog_4, pc.catalog_5,
          pc.color, pc.size, pc.brand_id, IFNULL(sc.cost, pc.cost),
          IFNULL(sc.cost_no_tax, pc.cost_no_tax), pc.sku_type, pc.item,
          pc.mfg_sku_code, b.brand_name,
          now(), now(), 'batchrunner', 'batchrunner'
          FROM purch_client_sku_master pc LEFT JOIN purch_sku_cost sc
          ON pc.channel_client_id = sc.channel_client_id AND
            pc.sku_code = sc.sku_code AND sc.cdc_whse_id = l_cdc_whse_id
          LEFT JOIN purch_brand_master b
            ON pc.brand_id = b.brand_id
          WHERE pc.sku_code = l_sku_code AND pc.channel_client_id = l_channel_client_id
            AND pc.status < 90;
        SET l_row_count_ins = l_row_count_ins + row_count();
      END IF;
      UPDATE wms_invn_cost
        SET end_invn_qty = end_invn_qty + l_actl_qty
        WHERE invn_cost_id = l_invn_cost_id;
      SET l_row_count_upd = l_row_count_upd + row_count();
    END IF;
  END LOOP pld_snap_loop;
  CLOSE c_pld_snap;

  SET l_output = CONCAT('Step 4.2 - From pld snap: ', l_row_count_ins,
    ' rows inserted, ', l_row_count_upd, ' rows updated');
  SELECT l_output AS "Status:";
  CALL log_output(l_sp_name, l_output);


  UPDATE wms_invn_cost
    SET status = 0
    WHERE record_date = p_record_date AND
      end_invn_qty = init_invn_qty + rcv_in_qty + rtn_in_qty + stock_take_in_qty
      + allot_in_qty + other_in_qty + in_trans_qty - sale_out_qty - rtv_out_qty
      - stock_take_out_qty - damage_out_qty - scrap_out_qty - allot_out_qty
      - other_out_qty;

  OPEN c_invn_cost_error;
  SET l_done = 0;
  fix_end_invn_loop: LOOP
    FETCH c_invn_cost_error INTO l_invn_cost_id, l_sku_code, l_whse_id,
      l_channel_client_id, l_end_invn_qty;
    IF (l_done = 1) THEN
      LEAVE fix_end_invn_loop;
    END IF;

    UPDATE wms_invn_cost
      SET status = 10, end_invn_snap_qty = l_end_invn_qty,
          end_invn_qty = init_invn_qty + rcv_in_qty + rtn_in_qty
          + stock_take_in_qty + allot_in_qty + other_in_qty + in_trans_qty
          - sale_out_qty - rtv_out_qty - stock_take_out_qty - damage_out_qty
          - scrap_out_qty - allot_out_qty - other_out_qty
      WHERE invn_cost_id = l_invn_cost_id;
  END LOOP fix_end_invn_loop;
  CLOSE c_invn_cost_error;


  DELETE FROM wms_invn_cost
  WHERE init_invn_qty = 0 AND rcv_in_qty = 0 AND rtn_in_qty = 0
        AND stock_take_in_qty = 0 AND allot_in_qty = 0 AND other_in_qty = 0
        AND other_in_qty = 0 AND in_trans_qty = 0 AND sale_out_qty = 0
        AND rtv_out_qty = 0 AND stock_take_out_qty = 0 AND damage_out_qty = 0
        AND scrap_out_qty = 0 AND allot_out_qty = 0 AND other_out_qty = 0
        AND end_invn_qty = 0 AND po_adj_amount = 0 AND record_date = p_record_date;



  UPDATE wms_invn_cost
    SET end_invn_cost = init_cost, end_invn_cost_no_tax = init_cost_no_tax
    WHERE record_date = p_record_date;

  OPEN c_invn_cost;
  SET l_row_count_upd = 0;
  calc_cost_loop: LOOP
    SET l_done = 0;
    FETCH c_invn_cost INTO l_channel_client_id, l_sku_code, l_cdc_whse_code,
      l_init_cost, l_init_cost_no_tax,
      l_init_invn_qty, l_init_amount, l_rcv_in_qty, l_rcv_in_amount,
      l_allot_in_qty, l_allot_in_amount, l_allot_out_qty, l_allot_out_amount,
      l_rtv_out_qty, l_rtv_out_amount, l_adj_amount, l_other_in_qty, l_other_in_amount,
      l_other_out_qty, l_other_out_amount;
    IF (l_done = 1) THEN
      LEAVE calc_cost_loop;
    END IF;

    SELECT sku_cost_algorithm INTO l_client_cost_cal_cfg FROM sys_client_info_cfg WHERE channel_client_id=l_channel_client_id and status=10;

    SET l_error_flag = 0;
    IF (l_rcv_in_qty <> 0 OR l_allot_in_qty <> 0 OR l_allot_out_qty <> 0
      OR l_rtv_out_qty <> 0 OR l_other_in_qty <>0 OR l_other_out_qty <> 0 OR l_adj_amount <> 0) THEN
      SELECT ifnull(tax_rate, 0.0) INTO l_tax_rate
        FROM purch_client_sku_master
        WHERE sku_code = l_sku_code AND channel_client_id = l_channel_client_id AND status < 90;

      IF (l_client_cost_cal_cfg=0) THEN
        SET l_cost = l_init_cost;
        SET l_cost_no_tax = l_init_cost_no_tax;

      ELSEIF ((l_init_invn_qty + l_rcv_in_qty + l_allot_in_qty - l_allot_out_qty - l_rtv_out_qty +
          l_other_in_qty - l_other_out_qty) > 0) THEN
        SET l_cost = round((l_init_amount + l_rcv_in_amount + l_allot_in_amount
            - l_allot_out_amount - l_rtv_out_amount + l_other_in_amount - l_other_out_amount + l_adj_amount)
            / (l_init_invn_qty + l_rcv_in_qty + l_allot_in_qty
            - l_allot_out_qty - l_rtv_out_qty + l_other_in_qty - l_other_out_qty), 4);
        SET l_cost_no_tax = round(l_cost/(1+l_tax_rate/100),4);
        CALL update_purch_cost(p_record_date, l_channel_client_id, l_sku_code,
                               l_cdc_whse_code, l_cost, l_cost_no_tax);
      ELSE
        SET l_error_flag = 1;
        SET l_cost = l_init_cost;
        SET l_cost_no_tax = l_init_cost_no_tax;
      END IF;

      UPDATE wms_invn_cost
        SET end_invn_cost = l_cost, end_invn_cost_no_tax = l_cost_no_tax,
            stock_take_in_amount = stock_take_in_qty * l_cost,
            stock_take_in_amount_no_tax = stock_take_in_qty * l_cost_no_tax,
            rtn_in_amount = rtn_in_qty * l_cost,
            rtn_in_amount_no_tax = rtn_in_qty * l_cost_no_tax,
            sale_out_amount = sale_out_qty * l_cost,
            sale_out_amount_no_tax = sale_out_qty * l_cost_no_tax,
            stock_take_out_amount = stock_take_out_qty * l_cost,
            stock_take_out_amount_no_tax = stock_take_out_qty * l_cost_no_tax,
            damage_out_amount = damage_out_qty * l_cost,
            damage_out_amount_no_tax = damage_out_qty * l_cost_no_tax,
            scrap_out_amount = scrap_out_qty * l_cost,
            scrap_out_amount_no_tax = scrap_out_qty * l_cost_no_tax,
            status = if(l_error_flag=1,20,0)
        WHERE record_date = p_record_date AND channel_client_id = l_channel_client_id
          AND sku_code = l_sku_code AND cdc_whse_code = l_cdc_whse_code;
      SET l_row_count_upd = l_row_count_upd + row_count();
    END IF;


    SELECT count(*) INTO l_count
      FROM purch_sku_cost
      WHERE channel_client_id = l_channel_client_id AND sku_code = l_sku_code
        AND cdc_whse_code = l_cdc_whse_code;
    IF (l_count = 0) THEN
      CALL update_purch_cost(p_record_date, l_channel_client_id, l_sku_code,
           l_cdc_whse_code, l_init_cost, l_init_cost_no_tax);
    END IF;

  END LOOP calc_cost_loop;
  CLOSE c_invn_cost;


  UPDATE wms_invn_cost c INNER JOIN
    (SELECT channel_client_id, whse_id, sku_code, record_date,
    SUM(IF(locn_type = 10, actl_qty, 0)) AS "recv_qty",
    SUM(IF(locn_type = 20, actl_qty, 0)) AS "resv_qty",
    SUM(IF(locn_type = 25, actl_qty, 0)) AS "trans_qty",
    SUM(IF(locn_type = 30, actl_qty, 0)) AS "pick_qty",
    SUM(IF(locn_type = 31, actl_qty, 0)) AS "cross_qty",
    SUM(IF(locn_type = 35, actl_qty, 0)) AS "sort_qty",
    SUM(IF(locn_type = 40, actl_qty, 0)) AS "ship_qty",
    SUM(IF(locn_type = 45, actl_qty, 0)) AS "sample_qty",
    SUM(IF(locn_type = 48, actl_qty, 0)) AS "add_qty",
    SUM(IF(locn_type = 50, actl_qty, 0)) AS "damg_qty",
    SUM(IF(locn_type = 60, actl_qty, 0)) AS "wast_qty",
    SUM(IF(locn_type = 70, actl_qty, 0)) AS "retn_qty",
    SUM(IF(locn_type = 77, actl_qty, 0)) AS "loss_qty",
    SUM(IF(locn_type = 80, actl_qty, 0)) AS "dull_qty",
    SUM(IF(locn_type = 85, actl_qty, 0)) AS "intrans_qty"
    FROM wms_pick_locn_dtl_daily_snap
    WHERE record_date = p_record_date
    GROUP BY channel_client_id, whse_id, sku_code) v1
    ON c.channel_client_id = v1.channel_client_id
    AND c.whse_id = v1.whse_id
    AND c.sku_code = v1.sku_code
    AND c.record_date = v1.record_date
    SET c.recv_qty = v1.recv_qty, c.reserve_qty = v1.resv_qty,
      c.trans_qty = v1.trans_qty, c.pick_qty = v1.pick_qty,
      c.cross_qty = v1.cross_qty,
      c.ship_qty = v1.ship_qty, c.sample_qty = v1.sample_qty,
      c.add_qty = v1.add_qty, c.damg_qty = v1.damg_qty,
      c.wast_qty = v1.wast_qty, c.retn_qty = v1.retn_qty,
      c.loss_qty = v1.loss_qty, c.dull_qty = v1.dull_qty,
      c.intrans_qty = v1.intrans_qty
    WHERE c.record_date = p_record_date;


  OPEN c_cost_update_log;
  cost_update_log_loop: LOOP
    SET l_done = 0;
    FETCH c_cost_update_log INTO l_sku_code, l_channel_client_id, l_cdc_whse_code,
      l_cost, l_cost_no_tax;
    IF (l_done = 1) THEN
      LEAVE cost_update_log_loop;
    END IF;


      UPDATE wms_invn_cost
        SET end_invn_cost = l_cost, end_invn_cost_no_tax = l_cost_no_tax,
          stock_take_in_amount = stock_take_in_qty * l_cost,
          stock_take_in_amount_no_tax = stock_take_in_qty * l_cost_no_tax,
          rtn_in_amount = rtn_in_qty * l_cost,
          rtn_in_amount_no_tax = rtn_in_qty * l_cost_no_tax,
          other_in_amount = other_in_qty * l_cost,
          other_in_amount_no_tax = other_in_qty * l_cost_no_tax,
          sale_out_amount = sale_out_qty * l_cost,
          sale_out_amount_no_tax = sale_out_qty * l_cost_no_tax,
          stock_take_out_amount = stock_take_out_qty * l_cost,
          stock_take_out_amount_no_tax = stock_take_out_qty * l_cost_no_tax,
          damage_out_amount = damage_out_qty * l_cost,
          damage_out_amount_no_tax = damage_out_qty * l_cost_no_tax,
          scrap_out_amount = scrap_out_qty * l_cost,
          scrap_out_amount_no_tax = scrap_out_qty * l_cost_no_tax,
          other_out_amount = other_out_qty * l_cost,
          other_out_amount_no_tax = other_out_qty * l_cost_no_tax,
          status = 30
        WHERE record_date = p_record_date AND channel_client_id = l_channel_client_id
          AND sku_code = l_sku_code AND cdc_whse_code = l_cdc_whse_code;
    SET l_row_count_upd = l_row_count_upd + row_count();


    UPDATE purch_sku_cost
      SET cost = l_cost, cost_no_tax = l_cost_no_tax,
        last_modify_date = now(), modified_by = 'batchrunner'
      WHERE channel_client_id = l_channel_client_id AND status = 0
        AND sku_code = l_sku_code AND cdc_whse_code = l_cdc_whse_code;
    UPDATE purch_sku_cost_hist
      SET valid_end_date = adddate(p_record_date,-1), status = 0,
        last_modify_date = now(), modified_by = 'batchrunner'
      WHERE channel_client_id = l_channel_client_id AND status = 1
        AND sku_code = l_sku_code AND cdc_whse_code = l_cdc_whse_code;
    INSERT INTO purch_sku_cost_hist (sku_cost_id, mem_id, mem_code, channel_client_id, channel_client_nbr,
      cdc_whse_id, cdc_whse_code, sku_id, sku_code, sku_name, sku_type, cost, cost_no_tax, valid_start_date,
      valid_end_date, status, creation_date, last_modify_date, creator, modified_by)
      SELECT sku_cost_id, mem_id, mem_code, channel_client_id, channel_client_nbr,
        cdc_whse_id, cdc_whse_code, sku_id, sku_code, sku_name, sku_type, cost, cost_no_tax, p_record_date,
        '2099-12-31',1,now(),now(),'batchrunner','batchrunner'
      FROM purch_sku_cost
      WHERE channel_client_id = l_channel_client_id AND status = 0 AND sku_code = l_sku_code
        AND cdc_whse_code = l_cdc_whse_code;

  END LOOP cost_update_log_loop;
  CLOSE c_cost_update_log;

  SET l_output = CONCAT('Step 4.3 - Update cost: ', l_row_count_upd, ' invn_cost rows updated');
  SELECT l_output AS "Status:";
  CALL log_output(l_sp_name, l_output);

  CALL set_so_do_cost(p_record_date);
  SET l_output = CONCAT('Step 4.4 - Set SO/DO cost');
  SELECT l_output AS "Status:";
  CALL log_output(l_sp_name, l_output);


  UPDATE sys_job_log
  SET job_end_time = now(), last_modify_date = now(),
    modified_by = 'batchrunner', status = 1
  WHERE job_log_id = l_job_log_id;

  COMMIT;

  SELECT CONCAT(l_sp_name, ' SUCCESS') AS "Status:";
END;

