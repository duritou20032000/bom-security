create function getTrackRefreshTime(whseCode varchar(100), carrCode varchar(100))
  returns datetime
  BEGIN
		DECLARE tTime,aTime,sTime,cTime,eTime datetime;
		SELECT last_end_time INTO tTime from  tms_track_logistics as ttl  where ttl.whse_code = whseCode and ttl.carr_code = carrCode;
		SELECT last_complete_time INTO aTime FROM channel_schedule WHERE job_id='st002';
		SELECT last_complete_time INTO sTime FROM channel_schedule WHERE job_id='st004';
		SELECT last_complete_time INTO cTime FROM channel_schedule WHERE job_id='st005';
		SELECT last_complete_time INTO eTime FROM channel_schedule WHERE job_id='st006';
		IF carrCode = 'STO' THEN
			IF tTime<sTime OR tTime is NULL THEN
				RETURN sTime;
			ELSE
				RETURN tTime;
			END IF ;
		ELSEIF carrCode = 'POSTB' THEN
			IF tTime<cTime OR tTime is NULL THEN
				RETURN cTime;
			ELSE
				RETURN tTime;
			END IF ;
		ELSEIF carrCode = 'EMS' THEN
			IF tTime<eTime OR tTime is NULL THEN
				RETURN eTime;
			ELSE
				return tTime;
			END IF;
		ELSEIF carrCode IN ('ZTO','YUNDA','YTO','WTP','TTK','TBYUNDA','SF','JD','HTKY','HDT')THEN
			IF tTime<aTime OR tTime is NULL THEN
				RETURN aTime;
			ELSE
				RETURN tTime;
			END IF;
		ELSE
			RETURN NULL;
		END IF;
	END;

