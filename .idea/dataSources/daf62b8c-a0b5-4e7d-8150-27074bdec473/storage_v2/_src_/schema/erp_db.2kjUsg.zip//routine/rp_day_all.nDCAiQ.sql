create procedure rp_day_all()
  BEGIN

call rp_day_consign();
call rp_day_receive();
call rp_day_rodtl();
call rp_day_salesum();
call rp_day_sodtl();
call rp_day_soeff();

END;

