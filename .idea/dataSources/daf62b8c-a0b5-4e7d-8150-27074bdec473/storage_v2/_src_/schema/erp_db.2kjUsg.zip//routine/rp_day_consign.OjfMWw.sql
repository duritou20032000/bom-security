create procedure rp_day_consign()
  comment '前置仓发货汇总(-B端)'
  begin
/* 执行删除操作 */
delete from rp_report_day_consignsum where createtime>=CURDATE();
/* 执行插入操作 */
insert into rp_report_day_consignsum
(
  rpid,
  reporttime,
  createtime,  
  whse_code,
  whse_name,
  db_cout_cout,
  db_ord_qty,
  db_send_qty,
  db_ord_amount,
  db_send_amount,
  ratio,
  tp_ord_qty,
  tp_ord_amount
  )
SELECT 
			 CONCAT("CONSIGN",substring(DATE_FORMAT(DATE_SUB(curdate(),INTERVAL 1 DAY),'%Y%m%d'),3)),
			 DATE_SUB(curdate(),INTERVAL 1 DAY),
			 now(),
			 hdr.whse_code "仓库代码",
  hdr.whse_name "仓库名称",
  ifnull(a.db_out_count,0) "出库调拨单单量",
  ifnull(b.db_ord_qty,0) "调拨单商品数量",
  ifnull(b.db_send_qty,0) "实际发货商品数量",
  ifnull(c.db_ord_amount,0) "调拨单商品金额",
  ifnull(c.db_send_amount,0) "实际发货商品金额",
  ifnull(b.ratio,0) "门店要货满足率%",
  ifnull(d.tp_ord_qty,0) "调拨城市仓商品数量",
  ifnull(d.tp_ord_amount,0) "调拨城市仓商品金额"
from wms_whse_master hdr left JOIN
  (SELECT
  poh.whse_code,
  count(distinct poh.po_nbr) db_out_count
FROM purch_po_hdr poh,wms_do_hdr doh
WHERE doh.do_type IN (30)
      and poh.po_id=doh.so_id
      AND poh.whse_code LIKE 'BJA%' and poh.to_whse REGEXP '^[0-9]{6}$'
  and datediff(doh.close_time, curdate()) = -1
  and poh.status<98
group by poh.whse_code) a on (hdr.whse_code=a.whse_code) left join
  (SELECT
  poh.whse_code,
  sum(doh.ord_unit_qty)  db_ord_qty,
  sum(doh.send_unit_qty) db_send_qty,
  concat(round(sum(doh.send_unit_qty)/sum(doh.ord_unit_qty),0)*100 ,'%') ratio
FROM purch_po_hdr poh, wms_do_hdr doh
WHERE doh.do_type IN (30)
      AND poh.po_id = doh.so_id
      AND poh.whse_code LIKE 'BJA%' AND poh.to_whse REGEXP '^[0-9]{6}$'
      AND datediff(doh.close_time, curdate()) = -1
      AND poh.status < 98
GROUP BY poh.whse_code) b on (hdr.whse_code=b.whse_code) left join
  (SELECT
  poh.whse_code,
  sum(dol.ord_qty * jyq_get_db_line_price(poh.po_id, sku.external_sku_id))  db_ord_amount,
  sum(dol.pick_qty * jyq_get_db_line_price(poh.po_id, sku.external_sku_id)) db_send_amount
FROM purch_po_hdr poh, wms_do_hdr doh, wms_do_dtl dol, purch_client_sku_master sku
WHERE doh.do_type IN (30)
      AND poh.po_id = doh.so_id
      AND doh.do_id = dol.do_id
      AND dol.sku_code = sku.sku_code
      AND dol.status < 99
      AND poh.whse_code LIKE 'BJA%' AND poh.to_whse REGEXP '^[0-9]{6}$'
      AND datediff(doh.close_time, curdate()) = -1
      AND poh.status < 98
GROUP BY poh.whse_code) c on (hdr.whse_code=c.whse_code) left join
  (SELECT
  poh.whse_code,
  sum(dol.ord_qty )  tp_ord_qty,
  sum(dol.ord_qty * jyq_get_db_line_price(doh.so_id, sku.external_sku_id)) tp_ord_amount
FROM purch_po_hdr poh, wms_do_hdr doh, wms_do_dtl dol, purch_client_sku_master sku
WHERE doh.do_type IN (30)
      AND poh.po_id = doh.so_id
      AND doh.do_id = dol.do_id
      AND dol.sku_code = sku.sku_code
      AND dol.status < 99
      AND poh.whse_code LIKE 'BJA%' AND poh.to_whse='380'
      AND datediff(doh.close_time, curdate()) = -1
      AND poh.status < 98
GROUP BY poh.whse_code) d on (hdr.whse_code=d.whse_code)
where hdr.whse_code like 'BJA%'
order by hdr.whse_code;

   
end;

