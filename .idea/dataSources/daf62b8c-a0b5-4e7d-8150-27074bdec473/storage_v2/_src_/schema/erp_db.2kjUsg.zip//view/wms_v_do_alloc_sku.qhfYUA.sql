create view wms_v_do_alloc_sku as
  select
    `n`.`mem_id`                                      AS `mem_id`,
    `n`.`mem_code`                                    AS `mem_code`,
    `n`.`sku_id`                                      AS `sku_id`,
    `n`.`sku_code`                                    AS `sku_code`,
    `sku`.`sku_name`                                  AS `sku_name`,
    `sku`.`mfg_sku_code`                              AS `mfg_sku_code`,
    `sku`.`color`                                     AS `color`,
    `sku`.`size`                                      AS `size`,
    `sku`.`brand_id`                                  AS `brand_id`,
    `brand`.`brand_name`                              AS `brand_name`,
    `sku`.`safe_store_qty`                            AS `safe_store_qty`,
    `sku`.`creator`                                   AS `creator`,
    `sku`.`status`                                    AS `status`,
    `sku`.`creation_date`                             AS `creation_date`,
    `sku`.`last_modify_date`                          AS `last_modify_date`,
    `sku`.`modified_by`                               AS `modified_by`,
    `n`.`whse_id`                                     AS `whse_id`,
    `n`.`whse_code`                                   AS `whse_code`,
    if((`n`.`batch_nbr` = ''), NULL, `n`.`batch_nbr`) AS `batch_nbr`,
    sum(`n`.`pre_pick_qty`)                           AS `order_alloc_qty`,
    `m`.`channel_client_Id`                           AS `channel_client_id`,
    `m`.`channel_clinet_nbr`                          AS `channel_clinet_nbr`
  from (((`erp_db`.`wms_do_hdr` `m`
    join `erp_db`.`wms_do_dtl` `n`) left join `erp_db`.`purch_client_sku_master` `sku`
      on (((`n`.`sku_id` = `sku`.`sku_id`) and (`m`.`channel_client_Id` = `sku`.`channel_client_id`)))) left join
    `erp_db`.`purch_client_brand_master` `brand` on ((`brand`.`brand_id` = `sku`.`brand_id`)))
  where ((`m`.`do_id` = `n`.`do_id`) and (`m`.`status` >= 0) and (`m`.`status` < 90) and (`n`.`status` < 99) and
         (`m`.`do_type` in (10, 20, 30)))
  group by `n`.`whse_id`, `n`.`sku_id`, if((`n`.`batch_nbr` = ''), NULL, `n`.`batch_nbr`);

