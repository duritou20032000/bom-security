create procedure rp_day_predtl()
  comment '日报表-前置仓商品库存明细'
  begin
/* 执行删除操作 */
delete from rp_report_day_predtl where createtime>=CURDATE();
/* 执行插入操作 */
insert into rp_report_day_predtl
(  
  rpid,
  reporttime,
  createtime,  
  whse_code,
  whse_name,
  channel_client_nbr,
  locn_type,
  locn_code,
  sku_code,
  external_sku_id,
  barcode,
  sku_name,  
  batch_nbr,
  actl_qty, 
  alloc_qty,
  lock_qty,
  lock_dtl,
  shelf_live,
  prod_date,	
  xpire_date,
  is_xpire,
  offshelf_days,
  offshelf_date,
  is_offshelf,
  alarm_inventory, 
  pack_unit_qty,
  stemperature_zone,
  htemperature_zone,
  refo,
  mfg_sku_code,
  catalog_1,
  catalog_2,
  catalog_3,
  modified_by,
  last_modify_date  
  )
SELECT 
			 CONCAT("PREDTL",substring(DATE_FORMAT(curdate(),'%Y%m%d'),3)),
			 curdate(),
			 now(),
			 d.whse_code "仓库代码",
       m.whse_name "仓库名称",
       s.channel_client_nbr "入驻商家名称",
       h.locn_type "库位类型",
       d.locn_code "库位代码",
       s.sku_code "商品编码",
       s.external_sku_id "外部编码",
       #b.barcode "商品条码",
       case when b.barcode1<>'' then b.barcode1
       when b.barcode2<>'' then b.barcode2
       when b.barcode3<>'' then b.barcode3
       when b.barcode4<>'' then b.barcode4
       else b.barcode
       end "商品条码",
       s.sku_name "商品名称",
       d.batch_nbr "批次号",
       d.actl_qty "库存数量",
       d.alloc_qty "分配数量",
       d.lock_qty "锁定数量",
       NULL "锁定明细",
       s.shelf_live "有效期",
       date_sub(xpire_date,INTERVAL s.shelf_live DAY) "生产日期",
       d.xpire_date "过期日期",
       IF(datediff(now(), xpire_date) > 0, '是','否') "是否过期",
       s.offshelf_days "允出期",
       date_sub(xpire_date,INTERVAL s.offshelf_days+1 DAY) "允出日期",
       IF(datediff(now(),date_sub(xpire_date,INTERVAL s.offshelf_days+1 DAY)) > 0, '是','否') "是否临期",   
       NULL "预警库存",
       s.pack_unit_qty "商品箱规",
       s.temperature_zone  "商品温带",
       h.temperature_zone  "货位温带",
       NULL "关联单号",
       s.mfg_sku_code "厂家编码",
       s.catalog_1 "一级分类",
       s.catalog_2 "二级分类",
       s.catalog_3 "三级分类",
       d.modified_by "修改人",
       d.last_modify_date "修改日期"
  FROM wms_pick_locn_dtl      d,
       jyq_client_sku_master  s,
       jyq_client_sku_barcode b,
       wms_locn_hdr           h,
       wms_whse_master        m
 WHERE d.sku_id = s.sku_id
   AND d.sku_id = b.client_sku_id
   AND d.locn_id = h.locn_id
   AND d.whse_id = m.whse_id
   AND h.status <> 99
   AND d.status <> 99
   AND d.actl_qty <> 0
   AND d.whse_code NOT IN ('test')
 ORDER BY d.whse_code,
          d.sku_code;
   
end;

