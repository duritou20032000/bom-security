create trigger before_update_do
  before UPDATE
  on wms_do_hdr
  for each row
  BEGIN
  IF new.status != old.status
  THEN
    SET new.status_lastModify_time = now();
  END IF;
END;

