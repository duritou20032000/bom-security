create procedure sumSkuDaySaleAmount(IN p_sale_date date, IN p_start_sale_date date, IN p_num varchar(5))
  BEGIN
  DECLARE l_done INT DEFAULT 0;
  DECLARE v_sku_code VARCHAR(30);
  DECLARE v_whse_id VARCHAR(50);
  DECLARE v_channel_client_id VARCHAR(50);
  DECLARE v_distributor_id VARCHAR(50);
  DECLARE v_sale_amount DOUBLE DEFAULT 0.0;

  DECLARE c_skucode CURSOR FOR
  SELECT sku_code, channel_client_id, distributor_id, whse_id, SUM(sale_volume) AS sale_volume
        FROM sku_daily_sales_volume dtl
        WHERE sale_date>=p_start_sale_date AND sale_date<=p_sale_date AND status=10
        GROUP BY sku_code, channel_client_id, distributor_id, whse_id ;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET l_done = 1;

  OPEN c_skucode;

  cc_loop: LOOP

    SET l_done = 0;

    FETCH c_skucode INTO v_sku_code, v_channel_client_id, v_distributor_id, v_whse_id, v_sale_amount;

    IF l_done = 1 THEN
      LEAVE cc_loop;
    END IF;

    SELECT l_done, v_sku_code,v_channel_client_id, v_distributor_id, v_whse_id, v_sale_amount;

    CASE
      WHEN p_num='3D' THEN
        UPDATE sku_daily_sales_volume SET last_3_sales_volume = v_sale_amount,  last_modify_date=NOW()
        WHERE sku_code=v_sku_code AND channel_client_id=v_channel_client_id AND distributor_id=v_distributor_id AND whse_id=v_whse_id
          AND sale_date=p_sale_date AND status=10;

      WHEN p_num='7D' THEN
        UPDATE sku_daily_sales_volume SET last_7_sales_volume = v_sale_amount,  last_modify_date=NOW()
        WHERE sku_code=v_sku_code AND channel_client_id=v_channel_client_id AND distributor_id=v_distributor_id AND whse_id=v_whse_id
          AND sale_date=p_sale_date AND status=10;

      WHEN p_num='10D' THEN
        UPDATE sku_daily_sales_volume SET last_10_sales_volume = v_sale_amount,  last_modify_date=NOW()
        WHERE sku_code=v_sku_code AND channel_client_id=v_channel_client_id AND distributor_id=v_distributor_id AND whse_id=v_whse_id
          AND sale_date=p_sale_date AND status=10;

      WHEN p_num='14D' THEN
        UPDATE sku_daily_sales_volume SET last_14_sales_volume = v_sale_amount,  last_modify_date=NOW()
        WHERE sku_code=v_sku_code AND channel_client_id=v_channel_client_id AND distributor_id=v_distributor_id AND whse_id=v_whse_id
          AND sale_date=p_sale_date AND status=10;

      WHEN p_num='15D' THEN
        UPDATE sku_daily_sales_volume SET last_15_sales_volume = v_sale_amount,  last_modify_date=NOW()
        WHERE sku_code=v_sku_code AND channel_client_id=v_channel_client_id AND distributor_id=v_distributor_id AND whse_id=v_whse_id
          AND sale_date=p_sale_date AND status=10;

      WHEN p_num='30D' THEN
        UPDATE sku_daily_sales_volume SET last_30_sales_volume = v_sale_amount,  last_modify_date=NOW()
        WHERE sku_code=v_sku_code AND channel_client_id=v_channel_client_id AND distributor_id=v_distributor_id AND whse_id=v_whse_id
          AND sale_date=p_sale_date AND status=10;

      WHEN p_num='2M' THEN
        UPDATE sku_daily_sales_volume SET last_2m_sales_volume = v_sale_amount,  last_modify_date=NOW()
        WHERE sku_code=v_sku_code AND channel_client_id=v_channel_client_id AND distributor_id=v_distributor_id AND whse_id=v_whse_id
          AND sale_date=p_sale_date AND status=10;

      WHEN p_num='3M' THEN
        UPDATE sku_daily_sales_volume SET last_3m_sales_volume = v_sale_amount,  last_modify_date=NOW()
        WHERE sku_code=v_sku_code AND channel_client_id=v_channel_client_id AND distributor_id=v_distributor_id AND whse_id=v_whse_id
          AND sale_date=p_sale_date AND status=10;
      
        UPDATE purch_client_sku_master csku INNER JOIN sys_client_info_cfg cfg ON cfg.channel_client_id=csku.channel_client_id
        SET csku.safe_store_qty=csku.safe_store_qty+v_sale_amount, csku.last_modify_date = now(), csku.modified_by = 'event'
        WHERE cfg.cal_safe_store_flag=1 AND csku.sku_code=v_sku_code AND csku.channel_client_id = v_channel_client_id AND csku.status <90;

    END CASE;

  END LOOP cc_loop;

  SET l_done=0;

  CLOSE c_skucode;

  COMMIT;

END;

