create view bm_v_user_group as
  select
    `u`.`mem_id`              AS `mem_id`,
    `u`.`mem_code`            AS `mem_code`,
    `u`.`USER_ID`             AS `user_id`,
    `u`.`USER_NAME`           AS `user_name`,
    `u`.`PWD`                 AS `pwd`,
    `u`.`realname`            AS `realname`,
    `u`.`status`              AS `status`,
    `u`.`CREATION_DATE`       AS `creation_date`,
    `u`.`LAST_MODIFY_DATE`    AS `last_modify_date`,
    `u`.`creator`             AS `creator`,
    `u`.`modified_by`         AS `modified_by`,
    `sg`.`SUBJECT_GROUP_ID`   AS `subject_group_id`,
    `sg`.`SUBJECT_GROUP_NAME` AS `subject_group_name`
  from ((((`erp_db`.`bm_user` `u`
    join `erp_db`.`bm_user_subject` `us` on ((`u`.`USER_ID` = `us`.`USER_ID`))) join `erp_db`.`bm_subject` `s`
      on ((`s`.`SUBJECT_ID` = `us`.`SUBJECT_ID`))) join `erp_db`.`bm_subject_group_connector` `sgc`
      on ((`sgc`.`SUBJECT_ID` = `s`.`SUBJECT_ID`))) join `erp_db`.`bm_subject_group` `sg`
      on ((`sg`.`SUBJECT_GROUP_ID` = `sgc`.`SUBJECT_GROUP_ID`)))
  where ((`u`.`status` <> 99) and (`sg`.`status` <> 99));

