create view oms_v_so_dtl as
  select
    `sku`.`catalog_1`                                                                      AS `catalog_1`,
    `sku`.`catalog_2`                                                                      AS `catalog_2`,
    `sku`.`catalog_3`                                                                      AS `catalog_3`,
    `sku`.`brand_id`                                                                       AS `brand_id`,
    `m`.`brand_name`                                                                       AS `brand_name`,
    `vdr`.`vdr_id`                                                                         AS `vdr_id`,
    `vdr`.`vdr_name`                                                                       AS `vdr_name`,
    `sku`.`sku_code`                                                                       AS `sku_code`,
    `sku`.`sku_name`                                                                       AS `sku_name`,
    `sku`.`item`                                                                           AS `item`,
    `sku`.`mfg_sku_code`                                                                   AS `mfg_sku_code`,
    `dt`.`so_dtl_id`                                                                       AS `so_dtl_id`,
    `dt`.`sku_id`                                                                          AS `sku_id`,
    ifnull(`dt`.`market_price`, 0)                                                         AS `market_price`,
    `dt`.`ord_qty`                                                                         AS `ord_qty`,
    `dt`.`pick_qty`                                                                        AS `pick_qty`,
    (`dt`.`cost` * ifnull(`dt`.`pick_qty`, 0))                                             AS `cost`,
    (`dt`.`cost_no_tax` * ifnull(`dt`.`pick_qty`, 0))                                      AS `cost_no_tax`,
    ifnull(`dt`.`paid_fee`, 0)                                                             AS `paid_fee`,
    ((ifnull(`dt`.`shared_order_discount_fee`, 0) * `dt`.`ord_qty`) / `d`.`send_unit_qty`) AS `discount_fee`,
    `dt`.`external_transaction_id`                                                         AS `external_id`,
    `d`.`so_id`                                                                            AS `so_id`,
    `d`.`so_nbr`                                                                           AS `so_nbr`,
    `d`.`sale_channel_id`                                                                  AS `sale_channel_Id`,
    `d`.`channel_name`                                                                     AS `channel_name`,
    `d`.`status`                                                                           AS `status`,
    `d`.`point`                                                                            AS `point`,
    `d`.`close_time`                                                                       AS `close_time`,
    `d`.`external_transactionId`                                                           AS `external_transactionId`,
    `d`.`shipping_fee`                                                                     AS `shipping_fee`,
    `d`.`shipto_name`                                                                      AS `shipto_name`,
    `d`.`shipto_addr`                                                                      AS `shipto_addr`,
    `d`.`so_type`                                                                          AS `so_type`,
    `d`.`pay_type`                                                                         AS `pay_type`,
    `d`.`trade_create_time`                                                                AS `trade_create_time`,
    `d`.`trade_verify_time`                                                                AS `trade_verify_time`,
    `d`.`pay_time`                                                                         AS `pay_time`,
    `d`.`combine_so_id`                                                                    AS `Combine_So_Id`,
    `d`.`mem_id`                                                                           AS `mem_id`,
    `d`.`mem_code`                                                                         AS `mem_code`,
    `d`.`whse_id`                                                                          AS `whse_id`,
    `d`.`whse_code`                                                                        AS `whse_code`,
    `d`.`creation_date`                                                                    AS `creation_date`,
    `d`.`last_modify_date`                                                                 AS `last_modify_date`,
    `d`.`creator`                                                                          AS `creator`,
    `d`.`modified_by`                                                                      AS `modified_by`,
    `sku`.`consign_flag`                                                                   AS `consign_flag`,
    `dt`.`settle_stat`                                                                     AS `settle_stat`,
    `dt`.`gifts_flag`                                                                      AS `gifts_flag`,
    `d`.`remark`                                                                           AS `remark`,
    `d`.`rtn_so_nbr`                                                                       AS `rtn_so_nbr`,
    `d`.`channel_client_Id`                                                                AS `channel_client_Id`,
    `d`.`channel_clinet_nbr`                                                               AS `channel_clinet_nbr`,
    `d`.`inner_memo`                                                                       AS `inner_memo`,
    `d`.`invoice_flag`                                                                     AS `invoice_flag`,
    `d`.`invoice_money`                                                                    AS `invoice_money`,
    `d`.`track_nbr`                                                                        AS `TRACK_NBR`,
    `c`.`carr_id`                                                                          AS `carr_id`,
    `c`.`carr_code`                                                                        AS `carr_code`,
    `c`.`carr_name`                                                                        AS `carr_name`,
    `d`.`carr_cost`                                                                        AS `carr_cost`,
    `dt`.`batch_nbr`                                                                       AS `batch_nbr`
  from ((((((`erp_db`.`oms_so_hdr` `d`
    join `erp_db`.`oms_so_dtl` `dt` on ((`d`.`so_id` = `dt`.`so_id`))) join `erp_db`.`purch_client_sku_master` `sku`
      on (((`dt`.`sku_code` = `sku`.`sku_code`) and (`d`.`channel_client_Id` = `sku`.`channel_client_id`)))) left join
    `erp_db`.`purch_client_brand_master` `m`
      on (((`m`.`brand_id` = `sku`.`brand_id`) and (`m`.`channel_client_id` = `sku`.`channel_client_id`)))) left join
    `erp_db`.`purch_sku_vdr_attr` `skuvdr`
      on (((`skuvdr`.`ITEM_NBR` = `sku`.`item`) and (`skuvdr`.`vdr_sku_level` = 1) and
           (`skuvdr`.`status` <> 99)))) left join `erp_db`.`purch_vendor_master` `vdr`
      on ((`vdr`.`vdr_id` = `skuvdr`.`vdr_id`))) left join `erp_db`.`wms_carrier_master` `c`
      on ((`c`.`carr_id` = `d`.`carr_id`)))
  where ((`dt`.`status` <> 99) and (`d`.`combine_so_id` = '-1') and
         (not (`d`.`so_id` in (select `erp_db`.`oms_so_sku_dtl`.`so_id`
                               from `erp_db`.`oms_so_sku_dtl`))));

