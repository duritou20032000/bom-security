create procedure calSkuSaleAmount(IN p_sale_date date)
  BEGIN
  DECLARE l_done INT DEFAULT 0;
  DECLARE v_sku_id VARCHAR(50);
  DECLARE v_sku_code VARCHAR(30);
  DECLARE v_sku_name VARCHAR(100);
  DECLARE v_whse_id VARCHAR(50);
  DECLARE v_whse_code VARCHAR(30);
  DECLARE v_channel_client_id VARCHAR(50);
  DECLARE v_channel_client_nbr VARCHAR(30);
  DECLARE v_distributor_id VARCHAR(50);
  DECLARE v_distributor_client_id VARCHAR(50);
  DECLARE v_distributor_client_nbr VARCHAR(30);

  DECLARE v_so_count INTEGER DEFAULT 0;
  DECLARE v_sale_amount DOUBLE DEFAULT 0.0;
  DECLARE v_3_sale_amount DOUBLE DEFAULT 0.0;
  DECLARE v_7_sale_amount DOUBLE DEFAULT 0.0;
  DECLARE v_10_sale_amount DOUBLE DEFAULT 0.0;
  DECLARE v_14_sale_amount DOUBLE DEFAULT 0.0;
  DECLARE v_15_sale_amount DOUBLE DEFAULT 0.0;
  DECLARE v_30_sale_amount DOUBLE DEFAULT 0.0;
  DECLARE v_2m_sale_amount DOUBLE DEFAULT 0.0;
  DECLARE v_3m_sale_amount DOUBLE DEFAULT 0.0;
  DECLARE v_safe_store_qty DOUBLE DEFAULT 2.0;

  DECLARE v_3m_days INTEGER DEFAULT 0.0;

  DECLARE c_skucode CURSOR FOR
    SELECT DISTINCT dtl.sku_code AS sku_code, dtl.own_client_id AS channel_client_id, dtl.distributor_id AS distributor_id, hdr.whse_id AS whse_id
    FROM wms_do_dtl dtl
    INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
    INNER JOIN sys_mirror_talk_channel channel ON (channel.channel_id=hdr.sale_channel_id AND channel.status=10)
    WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.close_time>=DATE_ADD(p_sale_date, INTERVAL -3 MONTH);

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET l_done = 1;

  WHILE(p_sale_date < CURDATE()) DO

    UPDATE sku_daily_sales_volume SET STATUS=99 WHERE sale_date = p_sale_date;
    UPDATE purch_client_sku_master SET safe_store_qty=0;

    OPEN c_skucode;

    cc_loop: LOOP

      SET l_done = 0;

      FETCH c_skucode INTO v_sku_code, v_channel_client_id, v_distributor_id, v_whse_id;

      IF l_done = 1 THEN
        LEAVE cc_loop;
      END IF;

      SELECT l_done, v_sku_code,v_channel_client_id, v_distributor_id, v_whse_id;

      SET v_so_count=0;
      SET v_sale_amount=0.0;
      SET v_3_sale_amount=0.0;
      SET v_7_sale_amount=0.0;
      SET v_10_sale_amount=0.0;
      SET v_14_sale_amount=0.0;
      SET v_15_sale_amount=0.0;
      SET v_30_sale_amount=0.0;
      SET v_2m_sale_amount=0.0;
      SET v_3m_sale_amount=0.0;
      SET v_distributor_client_id='';
      SET v_distributor_client_nbr='';

      IF(v_distributor_id<>'') THEN
        SELECT t0.so_count, t0.sale_amount INTO v_so_count, v_sale_amount
        FROM (SELECT COUNT(distinct hdr.so_id) AS so_count, SUM(pick_qty) AS sale_amount
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id AND dtl.distributor_id=v_distributor_id
          AND hdr.close_time>=p_sale_date AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t0 ;

        SELECT t1.sale_amount_3d INTO v_3_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_3d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id AND dtl.distributor_id=v_distributor_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -3 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t1;

        SELECT t2.sale_amount_7d INTO v_7_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_7d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id AND dtl.distributor_id=v_distributor_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -7 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t2 ;

        SELECT t3.sale_amount_10d INTO v_10_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_10d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id AND dtl.distributor_id=v_distributor_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -10 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t3 ;

        SELECT t4.sale_amount_14d INTO v_14_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_14d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id AND dtl.distributor_id=v_distributor_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -14 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t4 ;

        SELECT t5.sale_amount_15d INTO v_15_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_15d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id AND dtl.distributor_id=v_distributor_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -15 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t5 ;

        SELECT t6.sale_amount_30d INTO v_30_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_30d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id AND dtl.distributor_id=v_distributor_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -30 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t6 ;

        SELECT t7.sale_amount_2m INTO v_2m_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_2m
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id AND dtl.distributor_id=v_distributor_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -2 MONTH)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t7 ;

        SELECT t8.sale_amount_3m INTO v_3m_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_3m
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id AND dtl.distributor_id=v_distributor_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -3 MONTH)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t8 ;

      ELSE

        SET v_distributor_id='';

        SELECT t0.so_count, t0.sale_amount INTO v_so_count, v_sale_amount
        FROM (SELECT COUNT(distinct hdr.so_id) AS so_count, SUM(pick_qty) AS sale_amount
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id
          AND hdr.close_time>=p_sale_date AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t0 ;

        SELECT t1.sale_amount_3d INTO v_3_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_3d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -3 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t1;

        SELECT t2.sale_amount_7d INTO v_7_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_7d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -7 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t2 ;

        SELECT t3.sale_amount_10d INTO v_10_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_10d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -10 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t3 ;

        SELECT t4.sale_amount_14d INTO v_14_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_14d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -14 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t4 ;

        SELECT t5.sale_amount_15d INTO v_15_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_15d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -15 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t5 ;

        SELECT t6.sale_amount_30d INTO v_30_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_30d
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -30 DAY)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t6 ;

        SELECT t7.sale_amount_2m INTO v_2m_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_2m
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -2 MONTH)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t7 ;

        SELECT t8.sale_amount_3m INTO v_3m_sale_amount
        FROM (SELECT SUM(pick_qty) AS sale_amount_3m
          FROM wms_do_dtl dtl
            INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
          WHERE hdr.do_type=10 AND hdr.status IN (90,95) AND hdr.whse_id=v_whse_id
          AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id
          AND hdr.close_time>=DATE(DATE_ADD(p_sale_date, INTERVAL -3 MONTH)) AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
          GROUP BY dtl.sku_code) t8 ;

      END IF ;

      SELECT sku_id, sku_name, channel_client_nbr INTO v_sku_id, v_sku_name, v_channel_client_nbr
      FROM purch_client_sku_master WHERE sku_code=v_sku_code AND channel_client_id=v_channel_client_id AND STATUS<90;

      SELECT whse_code INTO v_whse_code FROM wms_whse_master WHERE whse_id=v_whse_id;

      IF(v_distributor_id<>'') THEN
	      SELECT distributor_client_id, distributor_client_nbr INTO v_distributor_client_id, v_distributor_client_nbr
	      FROM purch_distributor_master WHERE distributor_id=v_distributor_id AND STATUS=20;
      END IF;

      SELECT v_so_count,v_sale_amount,v_3_sale_amount,v_7_sale_amount,v_10_sale_amount,v_14_sale_amount,v_15_sale_amount,v_30_sale_amount,v_2m_sale_amount,v_3m_sale_amount;

      INSERT INTO sku_daily_sales_volume(sku_daily_sale_id,mem_id,mem_code,STATUS,creation_date,last_modify_date,creator,modified_by,sku_id,sku_code,sku_name,sale_date,
        so_count,sale_volume,last_3_sales_volume,last_7_sales_volume,last_10_sales_volume,last_14_sales_volume,last_15_sales_volume,last_30_sales_volume,last_2m_sales_volume,last_3m_sales_volume,
        whse_id, whse_code, channel_client_id,channel_client_nbr,distributor_id,distributor_client_id,distributor_client_nbr)
      VALUES(CONCAT('SKUDA-',UUID()) ,'main', 'main', 10, NOW(), NOW(), 'SYSTEM', 'SYSTEM',v_sku_id,v_sku_code,v_sku_name,p_sale_date,v_so_count,
        v_sale_amount,v_3_sale_amount,v_7_sale_amount,v_10_sale_amount,v_14_sale_amount,v_15_sale_amount,v_30_sale_amount,v_2m_sale_amount,v_3m_sale_amount,
        v_whse_id, v_whse_code, v_channel_client_id, v_channel_client_nbr,v_distributor_id,v_distributor_client_id,v_distributor_client_nbr);

      UPDATE purch_client_sku_master SET safe_store_qty=safe_store_qty+v_3m_sale_amount, last_modify_date = now(), modified_by = 'event'
        WHERE sku_id = v_sku_id and channel_client_id = v_channel_client_id AND status <90;

    END LOOP cc_loop;

    SET l_done=0;

    CLOSE c_skucode;


    SET v_3m_days = DATEDIFF(p_sale_date, DATE_ADD(p_sale_date, INTERVAL -3 MONTH));
    IF (v_3m_days<=0) THEN
       SET v_3m_days=90;
    END IF;

    UPDATE purch_client_sku_master SET safe_store_qty=CEIL(safe_store_qty/v_3m_days*7*3), last_modify_date = now(), modified_by = 'event' WHERE status<90;

    SET p_sale_date = DATE_ADD(p_sale_date, INTERVAL 1 DAY);

  END WHILE;

  COMMIT;

END;

