create view wms_v_distributor_pick_locn_dtl as
  select
    `distsku`.`distributor_id`   AS `distributor_id`,
    `distsku`.`distributor_code` AS `distributor_code`,
    `distsku`.`distributor_name` AS `distributor_name`,
    `pd`.`pick_locn_dtl_id`      AS `pick_locn_dtl_id`,
    `pd`.`mem_id`                AS `mem_id`,
    `pd`.`mem_code`              AS `mem_code`,
    `pd`.`whse_id`               AS `whse_id`,
    `pd`.`whse_code`             AS `whse_code`,
    `pd`.`locn_id`               AS `locn_id`,
    `pd`.`locn_code`             AS `locn_code`,
    `pd`.`locn_type`             AS `locn_type`,
    `pd`.`max_qty`               AS `max_qty`,
    `pd`.`min_qty`               AS `min_qty`,
    `pd`.`actl_qty`              AS `actl_qty`,
    `pd`.`alloc_qty`             AS `alloc_qty`,
    `pd`.`lock_qty`              AS `lock_qty`,
    `pd`.`lq_code`               AS `lq_code`,
    `pd`.`repl_qty`              AS `repl_qty`,
    `pd`.`sku_id`                AS `sku_id`,
    `pd`.`sku_code`              AS `sku_code`,
    `pd`.`vdr_code`              AS `vdr_code`,
    `pd`.`batch_nbr`             AS `batch_nbr`,
    `pd`.`serial_nbr`            AS `serial_nbr`,
    `pd`.`xpire_date`            AS `xpire_date`,
    `pd`.`reference_id`          AS `reference_id`,
    `pd`.`channel_client_id`     AS `channel_client_id`,
    `pd`.`channel_client_nbr`    AS `channel_clinet_nbr`,
    `pd`.`creation_date`         AS `creation_date`,
    `pd`.`last_modify_date`      AS `last_modify_date`,
    `pd`.`status`                AS `status`,
    `pd`.`creator`               AS `creator`,
    `pd`.`modified_by`           AS `modified_by`,
    `locn`.`locn_name`           AS `locn_name`,
    `locn`.`locn_brcd`           AS `locn_brcd`,
    `sku`.`sku_name`             AS `sku_name`,
    `sku`.`mfg_sku_code`         AS `mfg_sku_code`,
    `sku`.`color`                AS `color`,
    `sku`.`size`                 AS `size`,
    `sku`.`sku_abbr`             AS `sku_abbr`,
    `sku`.`catalog_1`            AS `catalog_1`,
    `sku`.`catalog_2`            AS `catalog_2`,
    `sku`.`catalog_3`            AS `catalog_3`,
    `bar`.`BARCODE`              AS `barcode`,
    `bar`.`BARCODE1`             AS `barcode1`,
    `bar`.`BARCODE2`             AS `barcode2`,
    `bar`.`BARCODE3`             AS `barcode3`,
    `bar`.`BARCODE4`             AS `barcode4`
  from ((((`erp_db`.`purch_distributor_sku_master` `distsku`
    join `erp_db`.`wms_pick_locn_dtl` `pd` on ((
      (`pd`.`sku_id` = `distsku`.`sku_id`) and (`pd`.`channel_client_id` = `distsku`.`channel_client_id`) and
      (`pd`.`status` = 0) and (`distsku`.`status` = 10)))) left join `erp_db`.`purch_client_sku_master` `sku`
      on (((`distsku`.`sku_id` = `sku`.`sku_id`) and
           (`distsku`.`channel_client_id` = `sku`.`channel_client_id`)))) left join `erp_db`.`purch_sku_barcode` `bar`
      on (((`bar`.`SKU_ID` = `sku`.`sku_id`) and (`bar`.`status` < 99)))) left join `erp_db`.`wms_locn_hdr` `locn`
      on (((`locn`.`locn_id` = `pd`.`locn_id`) and (`locn`.`whse_id` = `pd`.`whse_id`))));

