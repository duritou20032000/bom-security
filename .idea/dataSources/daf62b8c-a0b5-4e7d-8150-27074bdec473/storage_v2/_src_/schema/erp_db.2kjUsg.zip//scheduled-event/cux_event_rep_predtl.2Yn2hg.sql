create definer = wmsadmin@`%` event cux_event_rep_predtl
  on schedule
    every '1' DAY
      starts '2018-05-24 08:50:00'
  on completion preserve
  enable
do
  call rp_day_predtl();

