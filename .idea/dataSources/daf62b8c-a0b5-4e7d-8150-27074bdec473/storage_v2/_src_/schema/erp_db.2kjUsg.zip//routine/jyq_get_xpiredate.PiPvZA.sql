create function jyq_get_xpiredate(p_asn_dtl_id varchar(50))
  returns date
  BEGIN
   declare l_xpiredate date;
   declare continue HANDLER  for not found set l_xpiredate=null;
   select min(xpire_date) into l_xpiredate from wms_lpn_dtl
     where asn_dtl_id=p_asn_dtl_id;
  return l_xpiredate;
  end;

