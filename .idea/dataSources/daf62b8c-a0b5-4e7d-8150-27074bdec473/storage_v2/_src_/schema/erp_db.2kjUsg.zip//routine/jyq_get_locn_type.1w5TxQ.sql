create function jyq_get_locn_type(p_pick_locn_dtl_id varchar(50))
  returns int
  BEGIN
   declare l_locn_type int;
   declare continue HANDLER  for not found set l_locn_type=-1;
   select locn_type  into l_locn_type from wms_pick_locn_dtl
     where pick_locn_dtl_id=p_pick_locn_dtl_id;
  return l_locn_type;
  end;

