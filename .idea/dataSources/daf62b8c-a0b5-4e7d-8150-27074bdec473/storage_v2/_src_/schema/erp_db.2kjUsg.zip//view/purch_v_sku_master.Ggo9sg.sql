create view purch_v_sku_master as
  select
    `sku`.`sku_id`           AS `sku_id`,
    `sku`.`catalog_1`        AS `catalog_1`,
    `sku`.`catalog_2`        AS `catalog_2`,
    `sku`.`catalog_3`        AS `catalog_3`,
    `sku`.`color`            AS `color`,
    `sku`.`size`             AS `size`,
    `sku`.`BRAND_ID`         AS `brand_id`,
    `m`.`brand_name`         AS `brand_name`,
    `vdr`.`vdr_id`           AS `vdr_id`,
    `vdr`.`vdr_name`         AS `vdr_name`,
    `sku`.`sku_code`         AS `sku_code`,
    `sku`.`sku_name`         AS `sku_name`,
    `sku`.`item`             AS `item`,
    `sku`.`mfg_sku_code`     AS `mfg_sku_code`,
    `skuvdr`.`vdr_price`     AS `vdr_price`,
    `sku`.`cost`             AS `cost`,
    `sku`.`cost_no_tax`      AS `cost_no_tax`,
    `sku`.`status`           AS `status`,
    `sku`.`sku_type`         AS `sku_type`,
    `sku`.`mem_id`           AS `mem_id`,
    `sku`.`mem_code`         AS `mem_code`,
    `sku`.`creator`          AS `creator`,
    `sku`.`creation_date`    AS `creation_date`,
    `sku`.`last_modify_date` AS `last_modify_date`,
    `sku`.`modified_by`      AS `modified_by`
  from (((`erp_db`.`purch_sku_master` `sku` left join `erp_db`.`purch_brand_master` `m`
      on ((`m`.`brand_id` = `sku`.`BRAND_ID`))) left join `erp_db`.`purch_sku_vdr_attr` `skuvdr`
      on (((`skuvdr`.`ITEM_NBR` = `sku`.`item`) and (`skuvdr`.`vdr_sku_level` = 1) and
           (`skuvdr`.`status` <> 99)))) left join `erp_db`.`purch_vendor_master` `vdr`
      on ((`vdr`.`vdr_id` = `skuvdr`.`vdr_id`)))
  where (`sku`.`status` <> 99);

