create definer = wmsadmin@`%` event cux_event_rep_week
  on schedule
    every '1' WEEK
      starts '2018-05-24 09:00:00'
  on completion preserve
  enable
do
  call rp_week_all();

