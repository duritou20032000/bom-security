create function jyq_get_order_line_price(p_so_id varchar(50), p_sku_code varchar(50))
  returns double(13, 4)
  BEGIN
   declare l_order_line_price  DOUBLE(13, 4);
   declare continue HANDLER  for not found set l_order_line_price=0;
   select max(market_price)  into l_order_line_price from oms_so_dtl
     where so_id=p_so_id
     and sku_code=p_sku_code;
  return l_order_line_price;
  end;

