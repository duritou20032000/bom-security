create view wms_v_vdr_rtv_dtl as
  select
    `vsku`.`vdr_id`           AS `vdr_id`,
    `vdr`.`vdr_code`          AS `vdr_code`,
    `vdr`.`vdr_name`          AS `vdr_name`,
    `pd`.`mem_id`             AS `mem_id`,
    `pd`.`mem_code`           AS `mem_code`,
    `pd`.`whse_id`            AS `whse_id`,
    `pd`.`whse_code`          AS `whse_code`,
    `pd`.`locn_id`            AS `locn_id`,
    `pd`.`locn_code`          AS `locn_code`,
    `pd`.`locn_type`          AS `locn_type`,
    `locn`.`locn_name`        AS `locn_name`,
    `locn`.`locn_brcd`        AS `locn_brcd`,
    `pd`.`max_qty`            AS `max_qty`,
    `pd`.`min_qty`            AS `min_qty`,
    `pd`.`actl_qty`           AS `actl_qty`,
    `pd`.`alloc_qty`          AS `alloc_qty`,
    `pd`.`repl_qty`           AS `repl_qty`,
    `pd`.`sku_id`             AS `sku_id`,
    `pd`.`sku_code`           AS `sku_code`,
    `sku`.`item`              AS `item`,
    `sku`.`sku_name`          AS `sku_name`,
    `sku`.`mfg_sku_code`      AS `mfg_sku_code`,
    `sku`.`sku_abbr`          AS `sku_abbr`,
    `sku`.`client_sku_id`     AS `client_sku_id`,
    `sku`.`catalog_1`         AS `catalog_1`,
    `sku`.`catalog_2`         AS `catalog_2`,
    `sku`.`catalog_3`         AS `catalog_3`,
    `sku`.`color`             AS `color`,
    `sku`.`size`              AS `size`,
    `sku`.`creation_date`     AS `sku_creation_date`,
    `sku`.`safe_store_qty`    AS `safe_store_qty`,
    `pd`.`batch_nbr`          AS `batch_nbr`,
    `pd`.`xpire_date`         AS `xpire_date`,
    `pd`.`serial_nbr`         AS `serial_nbr`,
    `pd`.`channel_client_id`  AS `channel_client_id`,
    `pd`.`channel_client_nbr` AS `channel_client_nbr`,
    `bar`.`BARCODE`           AS `barcode`,
    `bar`.`BARCODE1`          AS `barcode1`,
    `bar`.`BARCODE2`          AS `barcode2`,
    `bar`.`BARCODE3`          AS `barcode3`,
    `bar`.`BARCODE4`          AS `barcode4`,
    `pd`.`creation_date`      AS `creation_date`,
    `pd`.`last_modify_date`   AS `last_modify_date`,
    `pd`.`status`             AS `status`,
    `pd`.`creator`            AS `creator`,
    `pd`.`modified_by`        AS `modified_by`
  from (((((`erp_db`.`purch_sku_vdr_attr` `vsku` left join `erp_db`.`purch_vendor_master` `vdr`
      on ((`vsku`.`vdr_id` = `vdr`.`vdr_id`))) left join `erp_db`.`purch_sku_barcode` `bar`
      on (((`bar`.`SKU_ID` = `vsku`.`sku_id`) and (`bar`.`status` < 99)))) left join
    `erp_db`.`purch_client_sku_master` `sku`
      on (((`vsku`.`sku_id` = `sku`.`sku_id`) and (`vdr`.`channel_client_Id` = `sku`.`channel_client_id`) and
           (`sku`.`status` < 90)))) join `erp_db`.`wms_pick_locn_dtl` `pd`
      on (((`pd`.`sku_id` = `sku`.`sku_id`) and (`pd`.`channel_client_id` = `vdr`.`channel_client_Id`)))) join
    `erp_db`.`wms_locn_hdr` `locn` on (((`locn`.`locn_id` = `pd`.`locn_id`) and (`locn`.`whse_id` = `pd`.`whse_id`))))
  where ((`pd`.`status` <> 99) and (`pd`.`locn_type` = 70) and (`pd`.`actl_qty` > 0));

