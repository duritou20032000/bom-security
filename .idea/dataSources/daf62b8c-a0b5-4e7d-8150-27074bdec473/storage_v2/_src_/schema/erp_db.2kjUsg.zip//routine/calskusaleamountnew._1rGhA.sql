create procedure calSkuSaleAmountNew(IN p_sale_date date)
  BEGIN
  DECLARE l_done INT DEFAULT 0;
  DECLARE v_sku_id VARCHAR(50);
  DECLARE v_sku_code VARCHAR(30);
  DECLARE v_sku_name VARCHAR(100);
  DECLARE v_whse_id VARCHAR(50);
  DECLARE v_whse_code VARCHAR(30);
  DECLARE v_channel_client_id VARCHAR(50);
  DECLARE v_channel_client_nbr VARCHAR(30);
  DECLARE v_distributor_id VARCHAR(50);
  DECLARE v_distributor_client_id VARCHAR(50);
  DECLARE v_distributor_client_nbr VARCHAR(30);

  DECLARE v_so_count INTEGER DEFAULT 0;
  DECLARE v_sale_amount DOUBLE DEFAULT 0.0;

  DECLARE v_start_sale_date DATE;
  DECLARE v_end_sale_date DATE;
  DECLARE v_3m_days INTEGER DEFAULT 0.0;

  DECLARE c_skucode CURSOR FOR
    SELECT dtl.sku_code AS sku_code, dtl.own_client_id AS channel_client_id, ifnull(dtl.distributor_id,'') AS distributor_id, hdr.whse_id AS whse_id
    FROM wms_do_dtl dtl
    INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
    INNER JOIN sys_mirror_talk_channel channel ON (channel.channel_id=hdr.sale_channel_id AND channel.status=10)
    WHERE hdr.do_type=10 AND hdr.status>=90 AND hdr.status<98 AND hdr.close_time>=p_sale_date and hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
    UNION
    SELECT sku_code, channel_client_id, ifnull(ds.distributor_id,'') AS distributor_id, whse_id
    FROM sku_daily_sales_volume ds
    WHERE ds.sale_date >= DATE_ADD(p_sale_date, INTERVAL -3 MONTH) AND ds.sale_date < p_sale_date;

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET l_done = 1;

  WHILE(p_sale_date < CURDATE()) DO

    UPDATE sku_daily_sales_volume SET STATUS=99 WHERE sale_date = p_sale_date;
    
    UPDATE purch_client_sku_master csku INNER JOIN sys_client_info_cfg cfg ON cfg.channel_client_id=csku.channel_client_id
    SET csku.safe_store_qty=0 WHERE cfg.cal_safe_store_flag=1;

    OPEN c_skucode;

    cc_loop: LOOP

      SET l_done = 0;

      FETCH c_skucode INTO v_sku_code, v_channel_client_id, v_distributor_id, v_whse_id;

      IF l_done = 1 THEN
        LEAVE cc_loop;
      END IF;

      SELECT l_done, v_sku_code,v_channel_client_id, v_distributor_id, v_whse_id;

      SET v_so_count=0;
      SET v_sale_amount=0.0;
      SET v_distributor_client_id='';
      SET v_distributor_client_nbr='';

      SELECT t0.so_count, t0.sale_amount INTO v_so_count, v_sale_amount
      FROM (SELECT COUNT(distinct hdr.so_id) AS so_count, SUM(pick_qty) AS sale_amount
        FROM wms_do_dtl dtl
          INNER JOIN wms_do_hdr hdr ON (dtl.do_id=hdr.do_id)
        WHERE hdr.do_type=10 AND hdr.status>=90 AND hdr.status<98 AND hdr.whse_id=v_whse_id
        AND dtl.sku_code=v_sku_code AND dtl.own_client_id=v_channel_client_id AND dtl.distributor_id=v_distributor_id
        AND hdr.close_time>=p_sale_date AND hdr.close_time < DATE_ADD(p_sale_date, INTERVAL 1 DAY)
        GROUP BY dtl.sku_code) t0 ;

      SELECT sku_id, sku_name, channel_client_nbr INTO v_sku_id, v_sku_name, v_channel_client_nbr
      FROM purch_client_sku_master WHERE sku_code=v_sku_code AND channel_client_id=v_channel_client_id AND STATUS<90;

      SELECT whse_code INTO v_whse_code FROM wms_whse_master WHERE whse_id=v_whse_id;

      IF(v_distributor_id<>'') THEN
        SELECT distributor_client_id, distributor_client_nbr INTO v_distributor_client_id, v_distributor_client_nbr
        FROM purch_distributor_master WHERE distributor_id=v_distributor_id AND STATUS=20;
      END IF;

      SELECT v_so_count,v_sale_amount;

      INSERT INTO sku_daily_sales_volume(sku_daily_sale_id,mem_id,mem_code,STATUS,creation_date,last_modify_date,creator,modified_by,
        sku_id,sku_code,sku_name,sale_date,so_count,sale_volume,last_3_sales_volume,last_7_sales_volume,last_10_sales_volume,last_14_sales_volume,
        last_15_sales_volume,last_30_sales_volume,last_2m_sales_volume,last_3m_sales_volume,whse_id, whse_code,
        channel_client_id,channel_client_nbr,distributor_id,distributor_client_id,distributor_client_nbr)
      VALUES(CONCAT('SKUDA-',UUID()),'main','main',10,NOW(),NOW(),'SYSTEM','SYSTEM',v_sku_id,v_sku_code,v_sku_name,p_sale_date,v_so_count,v_sale_amount,
        0,0,0,0,0,0,0,0,v_whse_id,v_whse_code,v_channel_client_id,v_channel_client_nbr,v_distributor_id,v_distributor_client_id,v_distributor_client_nbr);

    END LOOP cc_loop;

    SET l_done=0;

    CLOSE c_skucode;

    SET v_end_sale_date=DATE_ADD(p_sale_date, INTERVAL 1 DAY);
    SET v_start_sale_date=DATE_ADD(v_end_sale_date, INTERVAL -3 DAY);
    CALL sumSkuDaySaleAmount(p_sale_date, v_start_sale_date, '3D');

    SET v_start_sale_date=DATE_ADD(v_end_sale_date, INTERVAL -7 DAY);
    CALL sumSkuDaySaleAmount(p_sale_date, v_start_sale_date, '7D');

    SET v_start_sale_date=DATE_ADD(v_end_sale_date, INTERVAL -10 DAY);
    CALL sumSkuDaySaleAmount(p_sale_date, v_start_sale_date, '10D');

    SET v_start_sale_date=DATE_ADD(v_end_sale_date, INTERVAL -14 DAY);
    CALL sumSkuDaySaleAmount(p_sale_date, v_start_sale_date, '14D');

    SET v_start_sale_date=DATE_ADD(v_end_sale_date, INTERVAL -15 DAY);
    CALL sumSkuDaySaleAmount(p_sale_date, v_start_sale_date, '15D');

    SET v_start_sale_date=DATE_ADD(v_end_sale_date, INTERVAL -30 DAY);
    CALL sumSkuDaySaleAmount(p_sale_date, v_start_sale_date, '30D');

    SET v_start_sale_date=DATE_ADD(v_end_sale_date, INTERVAL -2 MONTH);
    CALL sumSkuDaySaleAmount(p_sale_date, v_start_sale_date, '2M');

    SET v_start_sale_date=DATE_ADD(v_end_sale_date, INTERVAL -3 MONTH);
    CALL sumSkuDaySaleAmount(p_sale_date, v_start_sale_date, '3M');

    SET v_3m_days = DATEDIFF(p_sale_date, DATE_ADD(p_sale_date, INTERVAL -3 MONTH));
    IF (v_3m_days<=0) THEN
       SET v_3m_days=90;
    END IF;

    UPDATE purch_client_sku_master csku INNER JOIN sys_client_info_cfg cfg ON cfg.channel_client_id=csku.channel_client_id
    SET csku.safe_store_qty=CEIL(csku.safe_store_qty/v_3m_days*7*3), last_modify_date = now(), modified_by = 'event' 
    WHERE cfg.cal_safe_store_flag=1 AND csku.status<90;
    
    SET p_sale_date = DATE_ADD(p_sale_date, INTERVAL 1 DAY);

  END WHILE;

  COMMIT;

END;

