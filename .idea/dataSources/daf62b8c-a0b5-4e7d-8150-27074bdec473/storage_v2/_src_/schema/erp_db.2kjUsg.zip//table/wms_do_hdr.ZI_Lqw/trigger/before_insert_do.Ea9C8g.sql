create trigger before_insert_do
  before INSERT
  on wms_do_hdr
  for each row
  BEGIN
    DECLARE externalTransactionId VARCHAR(1000);
    
    IF new.do_type = 10 AND new.status NOT IN (98, 99)
    THEN
      SET externalTransactionId = new.external_transactionId;
      IF externalTransactionId IS NULL OR externalTransactionId = ''
      THEN
        SET externalTransactionId = new.do_nbr;
      END IF;
      INSERT INTO wms_do_external_transactionId VALUE (new.channel_client_Id, externalTransactionId,now());
    END IF;
    SET new.status_lastModify_time = now();
END;

