create function jyq_get_rcv_date(p_pick_locn_dtl_id varchar(50))
  returns date
  BEGIN
  declare l_rcv_date date;
  declare l_whse_code varchar(30);
  declare l_sku_code varchar(30);
  declare l_xpire_date date;
   declare continue HANDLER  for not found set l_rcv_date='2018-03-01';
   select whse_code,sku_code,xpire_date  into l_whse_code,l_sku_code, l_xpire_date from wms_pick_locn_dtl
     where pick_locn_dtl_id=p_pick_locn_dtl_id;

  select max(comp_time) into l_xpire_date from wms_lpn_dtl lpnl
where  lpnl.whse_code=l_whse_code
and lpnl.sku_code=l_sku_code
and lpnl.status<99
and ifnull(lpnl.xpire_date,'')=ifnull(l_xpire_date,'');

  return l_xpire_date;
end;

