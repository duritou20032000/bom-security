create function get_receive_limit_nozone(client_id    varchar(100), carrier_id varchar(100), from_city varchar(100),
                                         shipto_state varchar(100), shipto_city varchar(100))
  returns int
  BEGIN
    DECLARE lim INT(11) DEFAULT 0;
    
    SET lim = (SELECT receive_limit
                    FROM
                      tms_receive_config
                    WHERE tms_receive_config.channel_client_id = client_id AND carr_id = carrier_id
                          AND start_city = from_city
                          AND arrive_province = shipto_state
                          AND arrive_city = shipto_city
                          AND (arrive_county = '' OR arrive_county IS NULL ) AND status<99);
    IF lim IS NULL OR lim = ''
    
    THEN SET lim = (SELECT receive_limit
                    FROM
                      tms_receive_config
                    WHERE tms_receive_config.channel_client_id = client_id AND carr_id = carrier_id AND start_city = from_city
                          AND arrive_province = shipto_state
                          AND (arrive_city = '' OR arrive_city IS NULL)
                          AND (arrive_county = '' OR arrive_county IS NULL )
                          AND status<99);
    	END IF ;
    IF lim IS NULL OR lim = ''
    
    THEN SET lim =  (SELECT receive_limit
                     FROM
                       tms_receive_config
                     WHERE
                       tms_receive_config.channel_client_id = client_id  AND start_city = from_city
                       AND (carr_id = '' OR carr_id is NULL )
                       AND arrive_province = shipto_state
                       AND arrive_city = shipto_city
                       AND (arrive_county = '' OR arrive_county IS NULL )
                       AND status<99);
		END IF ;
    IF lim IS NULL OR lim = ''
    
    THEN SET lim =  (SELECT receive_limit
                     FROM
                       tms_receive_config
                     WHERE
                       tms_receive_config.channel_client_id = client_id  AND start_city = from_city
                       AND (carr_id = '' OR carr_id is NULL )
                       AND arrive_province = shipto_state
                       AND (arrive_city = '' OR arrive_city IS NULL )
                       AND (arrive_county = '' OR arrive_county IS NULL )
                       AND status<99);
      	END IF ;
    IF lim IS NULL OR lim = ''
    
    THEN SET lim =  (SELECT receive_limit
                     FROM
                       tms_receive_config
                     WHERE
                        start_city = from_city
                       AND (tms_receive_config.channel_client_id = '' OR tms_receive_config.channel_client_id IS NULL )
                       AND (carr_id = '' OR carr_id is NULL )
                       AND arrive_province = shipto_state
                       AND (arrive_city = '' OR arrive_city IS NULL )
                       AND (arrive_county = '' OR arrive_county IS NULL )
                       AND status<99);
    	END IF ;
    IF lim IS NULL OR lim = ''
    
    THEN SET lim = 72;
    END IF;
    RETURN lim;
  END;

