create view wms_v_xpire_date_dtl as
  select
    `pd`.`pick_locn_dtl_id`                        AS `pick_locn_dtl_id`,
    `pd`.`mem_id`                                  AS `mem_id`,
    `pd`.`mem_code`                                AS `mem_code`,
    `pd`.`whse_id`                                 AS `whse_id`,
    `pd`.`whse_code`                               AS `whse_code`,
    `whse`.`whse_name`                             AS `whse_name`,
    `pd`.`locn_id`                                 AS `locn_id`,
    `pd`.`locn_code`                               AS `locn_code`,
    `pd`.`locn_type`                               AS `locn_type`,
    `pd`.`sku_code`                                AS `sku_code`,
    `pd`.`vdr_code`                                AS `vdr_code`,
    `pd`.`batch_nbr`                               AS `batch_nbr`,
    `pd`.`xpire_date`                              AS `xpire_date`,
    `sku`.`sku_name`                               AS `sku_name`,
    `sku`.`mfg_sku_code`                           AS `mfg_sku_code`,
    `sku`.`sale_standard`                          AS `sale_standard`,
    `sku`.`channel_client_Id`                      AS `channel_client_id`,
    `sku`.`channel_clinet_nbr`                     AS `channel_clinet_nbr`,
    `pd`.`creator`                                 AS `creator`,
    `pd`.`modified_by`                             AS `modified_by`,
    `pd`.`creation_date`                           AS `creation_date`,
    `pd`.`last_modify_date`                        AS `last_modify_date`,
    `pd`.`status`                                  AS `status`,
    timestampdiff(MONTH, now(), `pd`.`xpire_date`) AS `diff`
  from ((`erp_db`.`wms_pick_locn_dtl` `pd` left join `erp_db`.`wms_whse_master` `whse`
      on ((`pd`.`whse_id` = `whse`.`whse_id`))) join `erp_db`.`purch_sku_master` `sku`
      on (((`pd`.`sku_id` = `sku`.`sku_id`) and (`sku`.`xpire_flag` = '10') and (`sku`.`status` = '10') and
           (`pd`.`locn_type` in ('10', '30', '40')))))
  where (`pd`.`status` <> 99);

