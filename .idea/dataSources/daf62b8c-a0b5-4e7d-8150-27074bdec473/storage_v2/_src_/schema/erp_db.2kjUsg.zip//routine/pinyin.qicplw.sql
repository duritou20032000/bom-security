create function pinyin(P_NAME varchar(255))
  returns varchar(255)
  BEGIN
    DECLARE V_COMPARE VARCHAR(255);
    DECLARE V_RETURN VARCHAR(255);
    DECLARE V_PINYIN VARCHAR(255);
    DECLARE I INT;

    SET I = 1;
    SET V_RETURN = '';
    while I < LENGTH(P_NAME) do
        SET V_COMPARE = SUBSTR(P_NAME, I, 1);
        SET V_PINYIN = '';
        IF (V_COMPARE != '') THEN
            SET V_PINYIN = firstPinyin(V_COMPARE);
            IF (ISNULL(V_PINYIN) OR V_PINYIN = '') THEN
              SET V_RETURN = CONCAT(V_RETURN, V_COMPARE);
            ELSE
              SET V_RETURN = CONCAT(V_RETURN, V_PINYIN);
            END IF;
        END IF;
        SET I = I + 1;
    end while;

    IF (ISNULL(V_RETURN) or V_RETURN = '') THEN
        SET V_RETURN = P_NAME;
    END IF;

    RETURN V_RETURN;
END;

