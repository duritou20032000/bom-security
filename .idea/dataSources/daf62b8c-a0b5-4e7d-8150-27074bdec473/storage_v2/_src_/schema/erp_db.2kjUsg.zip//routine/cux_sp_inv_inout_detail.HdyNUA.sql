create procedure cux_sp_inv_inout_detail()
  BEGIN
      # 采购入库
insert into cux_inv_inout_detail
(channel_client_id,
channel_client_nbr,
whse_code,
inout_type,
external_transaction_id,
ref_nbr,
inout_nbr,
rtn_so_nbr,
status,
external_sku_id,
sku_code,
sku_name,
inout_qty,
close_time,
company_code,
company_name,
dept_code,
dept_name,
whse_name,
bar_code,
batch_no,
xpire_date)
SELECT
  poh.channel_client_Id "商家代码",
  poh.channel_clinet_nbr "商家名称",
  poh.whse_code               "仓库代码",
  CASE
  WHEN asnh.asn_type = 10
    THEN '采购订单'
  WHEN asnh.asn_type = 20
    THEN '退仓单'
  WHEN asnh.asn_type = 30
    THEN '调拨入库'
  WHEN asnh.asn_type = 40
    THEN '盘点入库'
  ELSE asnh.asn_type END      "单据类型",
  poh.external_transaction_id "外部单号",
  poh.po_nbr                  "关联单号",
  asnh.asn_nbr                "ASN单号",
  NULL                        "原SO单号",
  CASE
  WHEN asnh.status = 20
    THEN
      "已分配"
  WHEN asnh.status = 30
    THEN
      "正在收货"
  WHEN asnh.status = 40
    THEN
      "收货结束"
  WHEN asnh.status = 90
    THEN
      "收货完成确认"
  WHEN asnh.status = 98
    THEN
      "取消"
  ELSE
    asnh.status
  END                         "ASN单状态",
  sku.external_sku_id         "外部编码",
  asnl.sku_code               "商品编码",
  asnl.sku_name               "商品名称",
  asnl.rcv_unit_qty           "入库数量",
  asnh.close_time             "关单时间",
  substr(dict.dict_value,1,instr(dict.dict_value,'~')-1) "机构代码",
  null "机构名称",
  substr(dict.dict_value,instr(dict.dict_value,'~')+1) "部门代码",
  null "部门名称",
  whse.whse_name "仓库名称",
  bar.barcode "商品条码",
  null "批次号",
  null "过期日期"
FROM purch_po_hdr poh, wms_asn_hdr asnh, wms_asn_dtl asnl, purch_client_sku_master sku,wms_whse_master whse,purch_client_sku_barcode bar,sys_dict dict
WHERE asnh.po_id = poh.po_id
      AND asnh.asn_id = asnl.asn_id
      AND asnl.status < 99
      AND asnh.status IN (40, 90)
      AND asnh.asn_type = 10
      AND asnl.sku_code = sku.sku_code
      and sku.sku_code=bar.client_sku_code
      and poh.whse_code=whse.whse_code
      and poh.channel_client_id=dict.dict_id
      and dict.dict_type='channelclient'
      and ( dict.STATUS>=0 and dict.STATUS<99 )
      and datediff(curdate(),asnh.close_time)=1
union all
# 退货入库
SELECT
  soh.channel_client_Id "商家代码",
  soh.channel_clinet_nbr "商家名称",
  soh.whse_code              "仓库代码",
  CASE
  WHEN asnh.asn_type = 10
    THEN '采购入库'
  WHEN asnh.asn_type = 20
    THEN '退货入库'
  WHEN asnh.asn_type = 30
    THEN '调拨入库'
  WHEN asnh.asn_type = 40
    THEN '盘点入库'
  ELSE asnh.asn_type END     "单据类型",
  soh.external_transactionId "外部单号",
  soh.so_nbr                 "关联单号",
  asnh.asn_nbr               "ASN单号",
  soh.rtn_so_nbr             "原SO单号",
  CASE
  WHEN asnh.status = 20
    THEN
      "已分配"
  WHEN asnh.status = 30
    THEN
      "正在收货"
  WHEN asnh.status = 40
    THEN
      "收货结束"
  WHEN asnh.status = 90
    THEN
      "收货完成确认"
  WHEN asnh.status = 98
    THEN
      "取消"
  ELSE
    asnh.status
  END                        "ASN单状态",
  sku.external_sku_id        "外部编码",
  asnl.sku_code              "商品编码",
  asnl.sku_name              "商品名称",
  asnl.rcv_unit_qty          "入库数量",
  asnh.close_time            "关单时间",
    substr(dict.dict_value,1,instr(dict.dict_value,'~')-1) "机构代码",
  null "机构名称",
  substr(dict.dict_value,instr(dict.dict_value,'~')+1) "部门代码",
  null "部门名称",
  whse.whse_name "仓库名称",
  bar.barcode "商品条码",
  null "批次号",
  null "过期日期"
FROM oms_so_hdr soh, wms_asn_hdr asnh, wms_asn_dtl asnl, purch_client_sku_master sku,wms_whse_master whse,purch_client_sku_barcode bar,sys_dict dict
WHERE asnh.po_id = soh.so_id
      AND asnh.asn_id = asnl.asn_id
      AND asnl.status < 99
      AND asnh.status IN (40, 90)
      AND asnh.asn_type = 20
      AND asnl.sku_code = sku.sku_code
      and sku.sku_code=bar.client_sku_code
      and soh.whse_code=whse.whse_code
      and soh.channel_client_id=dict.dict_id
      and dict.dict_type='channelclient'
      and ( dict.STATUS>=0 and dict.STATUS<99 )
      and datediff(curdate(),asnh.close_time)=1
union all
# 调拨入库
SELECT
  poh.channel_client_Id "商家代码",
  poh.channel_clinet_nbr "商家名称",
  poh.to_whse                 "仓库代码",
  CASE
  WHEN asnh.asn_type = 10
    THEN '采购入库'
  WHEN asnh.asn_type = 20
    THEN '退货入库'
  WHEN asnh.asn_type = 30
    THEN '调拨入库'
  WHEN asnh.asn_type = 40
    THEN '盘点入库'
  ELSE asnh.asn_type END      "单据类型",
  poh.external_transaction_id "外部单号",
  poh.po_nbr                  "关联单号",
  asnh.asn_nbr                "ASN单号",
  NULL                        "原SO单号",
  CASE
  WHEN asnh.status = 20
    THEN
      "已分配"
  WHEN asnh.status = 30
    THEN
      "正在收货"
  WHEN asnh.status = 40
    THEN
      "收货结束"
  WHEN asnh.status = 90
    THEN
      "收货完成确认"
  WHEN asnh.status = 98
    THEN
      "取消"
  ELSE
    asnh.status
  END                         "ASN单状态",
  sku.external_sku_id         "外部编码",
  asnl.sku_code               "商品编码",
  asnl.sku_name               "商品名称",
  asnl.rcv_unit_qty           "入库数量",
  asnh.close_time             "关单时间",
    substr(dict.dict_value,1,instr(dict.dict_value,'~')-1) "机构代码",
  null "机构名称",
  substr(dict.dict_value,instr(dict.dict_value,'~')+1) "部门代码",
  null "部门名称",
  whse.whse_name "仓库名称",
  bar.barcode "商品条码",
  null "批次号",
  null "过期日期"
FROM purch_po_hdr poh, wms_asn_hdr asnh, wms_asn_dtl asnl, purch_client_sku_master sku,wms_whse_master whse,purch_client_sku_barcode bar,sys_dict dict
WHERE asnh.po_id = poh.po_id
      AND asnh.asn_id = asnl.asn_id
      AND asnl.status < 99
      AND asnh.status IN (40, 90)
      AND asnh.asn_type = 30
      AND asnl.sku_code = sku.sku_code
       and sku.sku_code=bar.client_sku_code
      and poh.to_whse=whse.whse_code
      and poh.channel_client_id=dict.dict_id
      and dict.dict_type='channelclient'
      and ( dict.STATUS>=0 and dict.STATUS<99 )
      and datediff(curdate(),asnh.close_time)=1
union all
#其他入库
SELECT
  asnh.channel_client_id "商家代码",
  asnh.channel_client_nbr "商家名称",
  asnh.whse_code         "仓库代码",
  CASE
  WHEN asnh.asn_type = 10
    THEN '采购入库'
  WHEN asnh.asn_type = 20
    THEN '退货入库'
  WHEN asnh.asn_type = 30
    THEN '调拨入库'
  WHEN asnh.asn_type = 40
    THEN '盘点入库'
  ELSE asnh.asn_type END "单据类型",
  NULL                   "外部单号",
  asnh.po_nbr            "入库单号",
  asnh.asn_nbr           "关联单号",
  NULL                   "原SO单号",
  CASE
  WHEN asnh.status = 20
    THEN
      "已分配"
  WHEN asnh.status = 30
    THEN
      "正在收货"
  WHEN asnh.status = 40
    THEN
      "收货结束"
  WHEN asnh.status = 90
    THEN
      "收货完成确认"
  WHEN asnh.status = 98
    THEN
      "取消"
  ELSE
    asnh.status
  END                    "ASN单状态",
  sku.external_sku_id    "外部编码",
  asnl.sku_code          "商品编码",
  asnl.sku_name          "商品名称",
  asnl.rcv_unit_qty      "入库数量",
  asnh.close_time        "关单时间",
  substr(dict.dict_value,1,instr(dict.dict_value,'~')-1) "机构代码",
  null "机构名称",
  substr(dict.dict_value,instr(dict.dict_value,'~')+1) "部门代码",
  null "部门名称",
  whse.whse_name "仓库名称",
  bar.barcode "商品条码",
  null "批次号",
  null "过期日期"
FROM wms_asn_hdr asnh, wms_asn_dtl asnl, purch_client_sku_master sku,wms_whse_master whse,purch_client_sku_barcode bar,sys_dict dict
WHERE asnh.asn_id = asnl.asn_id
      AND asnl.status < 99
      AND asnh.status IN (40, 90)
      AND asnh.asn_type NOT IN (10, 20, 30)
      AND asnl.sku_code = sku.sku_code
      and sku.sku_code=bar.client_sku_code
      and asnh.whse_code=whse.whse_code
      and asnh.channel_client_id=dict.dict_id
      and dict.dict_type='channelclient'
      and ( dict.STATUS>=0 and dict.STATUS<99 )
      and datediff(curdate(),asnh.close_time)=1
order by 10 desc;

/*出库明细*/
insert into cux_inv_inout_detail
(channel_client_id,
channel_client_nbr,
whse_code,
inout_type,
external_transaction_id,
ref_nbr,
inout_nbr,
rtn_so_nbr,
status,
external_sku_id,
sku_code,
sku_name,
inout_qty,
close_time,
company_code,
company_name,
dept_code,
dept_name,
whse_name,
bar_code,
batch_no,
xpire_date)
SELECT
  doh.channel_client_Id "商家代码",
  doh.channel_clinet_nbr "商家名称",
  doh.whse_code "仓库代码",
  CASE
  WHEN doh.do_type = 10
    THEN '销售订单'
  WHEN doh.do_type = 20
    THEN '退仓单'
  WHEN doh.do_type = 30
    THEN '调拨出库'
  WHEN doh.do_type = 40
    THEN '报损出库'
  ELSE doh.do_type END     "单据类型",
  doh.external_transactionId "外部单号",
  doh.so_nbr                 "关联单号",
  doh.do_nbr                 "DO单号",
  NULL                       "原SO单号",
  CASE
  WHEN doh.status = -1
    THEN
      '未知状态'
  WHEN doh.status = 0
    THEN
      '新建'
  WHEN doh.status = 10
    THEN
      '波次进行中'
  WHEN doh.status = 20
    THEN
      '波次完成'
  WHEN doh.status = 25
    THEN
      '拣货中'
  WHEN doh.status = 30
    THEN
      '拣货完成'
  WHEN doh.status = 35
    THEN
      '分拣进行中'
  WHEN doh.status = 40
    THEN
      '分拣完成'
  WHEN doh.status = 55
    THEN
      '包装中'
  WHEN doh.status = 60
    THEN
      '包装完成'
  WHEN doh.status = 61
    THEN
      '称重中'
  WHEN doh.status = 62
    THEN
      '称重完成'
  WHEN doh.status = 64
    THEN
      '提交报关'
  WHEN doh.status = 65
    THEN
      '报关失败'
  WHEN doh.status = 66
    THEN
      '报关成功'
  WHEN doh.status = 69
    THEN
      '装车中'
  WHEN doh.status = 70
    THEN
      '装车完成'
  WHEN doh.status = 80
    THEN
      '预出库'
  WHEN doh.status = 90
    THEN
      '已发货'
  WHEN doh.status = 95
    THEN
      '结算完成'
  WHEN doh.status = 98
    THEN
      '已取消'
  ELSE
    doh.status
  END                        "订单状态",
  sku.external_sku_id        "外部编码",
  sku.sku_code               "商品代码",
  sku.sku_name               "商品名称",
  dol.pick_qty*(-1)               "出库数量",
  doh.close_time             "关单时间",
  substr(dict.dict_value,1,instr(dict.dict_value,'~')-1) "机构代码",
  null "机构名称",
  substr(dict.dict_value,instr(dict.dict_value,'~')+1) "部门代码",
  null "部门名称",
  whse.whse_name "仓库名称",
  bar.barcode "商品条码",
  null "批次号",
  null "过期日期"
FROM wms_do_hdr doh,
  wms_do_dtl dol,
  purch_client_sku_master sku,
  wms_whse_master whse,purch_client_sku_barcode bar,sys_dict dict
WHERE doh.do_id = dol.do_id
      AND doh.status IN (90)
      AND dol.sku_code = sku.sku_code
      and sku.sku_code=bar.client_sku_code
      and doh.whse_code=whse.whse_code
      and doh.channel_client_id=dict.dict_id
      and dict.dict_type='channelclient'
      and ( dict.STATUS>=0 and dict.STATUS<99 )
      AND dol.status < 99
      and datediff(curdate(),doh.close_time)=1;
end;

