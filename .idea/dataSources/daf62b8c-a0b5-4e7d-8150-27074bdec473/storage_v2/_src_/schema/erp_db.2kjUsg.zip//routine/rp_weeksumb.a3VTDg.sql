create procedure rp_weeksumb()
  comment '日报表-前置仓商品库存明细'
  begin
delete from rp_report_week_sumb where createtime>=CURDATE();
insert into rp_report_week_sumb
(
  rpid,
  reporttime,
  createtime,   
  whse_code,
  whse_name,   
  store_code,
  store_name,    
  po_count,
  db_send_qty,
  db_send_amount,
  so_sale_count,
  so_sale_qty,
	so_sale_amount)
SELECT 
			 CONCAT("WEEKB",substring(DATE_FORMAT(DATE_SUB(curdate(),INTERVAL 1 DAY),'%Y%m%d'),3)),
			 DATE_SUB(curdate(),INTERVAL 1 DAY),
			 now(),
			 f.whse_code "前置仓代码",
       w.whse_name "前置仓名称",
       f.store_code "门店代码",
       m.store_name "门店名称",
       ifnull(f.po_count,
              0) "B端（向门店调拨）单量",
       ifnull(f.db_send_qty,
              0) "B端（向门店调拨）数量",
       ifnull(f.db_send_amount,
              0) "B端（向门店调拨）调拨金额",
       ifnull(f.so_sale_count,
              0) "C端订单数量",
       ifnull(f.so_sale_qty,
              0) "订单商品数量",
       ifnull(f.so_sale_amount,
              0) "订单销售金额"
  FROM (SELECT a.whse_code,
               a.store_code,
               a.po_count,
               a.db_send_qty,
               a.db_send_amount,
               b.so_sale_count,
               b.so_sale_qty,
               b.so_sale_amount
          FROM (SELECT poh.whse_code,
                       poh.to_whse store_code,
                       COUNT(DISTINCT poh.po_nbr) po_count,
                       SUM(dol.pick_qty) db_send_qty,
                       SUM(dol.pick_qty *
                           jyq_get_db_line_price(poh.po_id,
                                                 sku.external_sku_id)) db_send_amount
                  FROM purch_po_hdr            poh,
                       wms_do_hdr              doh,
                       wms_do_dtl              dol,
                       purch_client_sku_master sku
                 WHERE doh.do_type IN (30)
                   AND poh.po_id = doh.so_id
                   AND doh.do_id = dol.do_id
                   AND dol.sku_code = sku.sku_code
                   AND dol.status < 99
                   AND poh.whse_code LIKE 'BJA%'
                   AND poh.to_whse REGEXP '^[0-9]{6}$'
                   AND datediff(curdate(),
                                doh.close_time) <= 7
                   AND datediff(curdate(),
                                doh.close_time) >= 1
                   AND poh.status < 98
                   AND doh.status = 90
                 GROUP BY poh.whse_code,
                          poh.to_whse) a
          LEFT JOIN (SELECT oh.whse_code,
                           oh.store_nbr store_code,
                           COUNT(DISTINCT oh.so_nbr) so_sale_count,
                           SUM(ol.pick_qty) so_sale_qty,
                           SUM(ol.market_price * ol.pick_qty) so_sale_amount
                      FROM oms_so_hdr oh,
                           oms_so_dtl ol
                     WHERE oh.so_id = ol.so_id
                       AND datediff(curdate(),
                                    oh.close_time) <= 7
                       AND datediff(curdate(),
                                    oh.close_time) >= 1
                       AND oh.status IN (80,
                                         84,
                                         85)
                       AND oh.so_type = 10
                     GROUP BY oh.whse_code,
                              oh.store_nbr) b
            ON (a.whse_code = b.whse_code AND a.store_code = b.store_code)
        UNION
        SELECT b.whse_code,
               b.store_code,
               ifnull(a.po_count,
                      0),
               ifnull(a.db_send_qty,
                      0),
               ifnull(a.db_send_amount,
                      0),
               ifnull(b.so_sale_count,
                      0),
               ifnull(b.so_sale_qty,
                      0),
               ifnull(b.so_sale_amount,
                      0)
          FROM (SELECT poh.whse_code,
                       poh.to_whse store_code,
                       COUNT(DISTINCT poh.po_nbr) po_count,
                       SUM(dol.pick_qty) db_send_qty,
                       SUM(dol.pick_qty *
                           jyq_get_db_line_price(poh.po_id,
                                                 sku.external_sku_id)) db_send_amount
                  FROM purch_po_hdr            poh,
                       wms_do_hdr              doh,
                       wms_do_dtl              dol,
                       purch_client_sku_master sku
                 WHERE doh.do_type IN (30)
                   AND poh.po_id = doh.so_id
                   AND doh.do_id = dol.do_id
                   AND dol.sku_code = sku.sku_code
                   AND dol.status < 99
                   AND poh.whse_code LIKE 'BJA%'
                   AND poh.to_whse REGEXP '^[0-9]{6}$'
                   AND datediff(curdate(),
                                doh.close_time) <= 7
                   AND datediff(curdate(),
                                doh.close_time) >= 1
                   AND poh.status < 98
                   AND doh.status = 90
                 GROUP BY poh.whse_code,
                          poh.to_whse) a
         RIGHT JOIN (SELECT oh.whse_code,
                           oh.store_nbr store_code,
                           COUNT(DISTINCT oh.so_nbr) so_sale_count,
                           SUM(ol.pick_qty) so_sale_qty,
                           SUM(ol.market_price * ol.pick_qty) so_sale_amount
                      FROM oms_so_hdr oh,
                           oms_so_dtl ol
                     WHERE oh.so_id = ol.so_id
                       AND datediff(curdate(),
                                    oh.close_time) <= 7
                       AND datediff(curdate(),
                                    oh.close_time) >= 1
                       AND oh.status IN (80,
                                         84,
                                         85)
                       AND oh.so_type = 10
                     GROUP BY oh.whse_code,
                              oh.store_nbr) b
            ON (a.whse_code = b.whse_code AND a.store_code = b.store_code)) f,
       wms_store_info m,
       wms_whse_master w
 WHERE f.whse_code = w.whse_code
   AND f.store_code = m.store_code
 ORDER BY 5 DESC;

   
end;

