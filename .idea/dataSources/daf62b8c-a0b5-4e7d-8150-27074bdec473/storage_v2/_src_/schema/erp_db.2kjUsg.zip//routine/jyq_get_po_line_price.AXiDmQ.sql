create function jyq_get_po_line_price(p_po_id varchar(50), p_sku_code varchar(50))
  returns double(13, 4)
  BEGIN
   declare l_order_po_price  DOUBLE(13, 4);
   declare continue HANDLER  for not found set l_order_po_price=0;
   select max(actl_price)  into l_order_po_price from purch_po_dtl
     where po_id=p_po_id
     and sku_code=p_sku_code;
  return l_order_po_price;
  end;

