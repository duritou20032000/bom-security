create procedure rp_weeksuma()
  comment '日报表-前置仓商品库存明细'
  begin
delete from rp_report_week_suma where createtime>=CURDATE();
insert into rp_report_week_suma
(
  rpid,
  reporttime,
  createtime,   
  whse_code,
  whse_name,    
  nor_qty,
  bro_qty,
  so_rtn_qty,
  in_rcv_qty,
  rtv_send_qty,
	city)
SELECT 
			 CONCAT("WEEKA",substring(DATE_FORMAT(DATE_SUB(curdate(),INTERVAL 1 DAY),'%Y%m%d'),3)),
			 DATE_SUB(curdate(),INTERVAL 1 DAY),
			 now(),
			 a.whse_code "前置仓代码",
       a.whse_name "前置仓名称",
       ifnull(b.nor_qty,
              0) "当前库存数量",
       ifnull(c.bro_qty,
              0) "当前残次库存数量",
       ifnull(d.so_rtn_qty,
              0) "本周累计销售退货数量",
       ifnull(m.in_rcv_qty,
              0) "本周采购收货和调拨入库数量",
       ifnull(g.rtv_send_qty,
              0) "本周采购退货（退供商）数量",
       a.city "仓库所属城市"
  FROM wms_whse_master a
  LEFT JOIN (SELECT inv.whse_code,
                    SUM(inv.actl_qty) nor_qty
               FROM wms_pick_locn_dtl inv
              WHERE inv.status < 99
                AND inv.whse_code LIKE 'BJA%'
                AND inv.locn_type NOT IN (50,
                                          60,
                                          77)
              GROUP BY inv.whse_code) b
    ON (a.whse_code = b.whse_code)
  LEFT JOIN (SELECT inv.whse_code,
                    SUM(inv.actl_qty) bro_qty
               FROM wms_pick_locn_dtl inv
              WHERE inv.status < 99
                AND inv.whse_code LIKE 'BJA%'
                AND inv.locn_type IN (50,
                                      60,
                                      77)
              GROUP BY inv.whse_code) c
    ON (a.whse_code = c.whse_code)
  LEFT JOIN (SELECT soh.whse_code,
                    SUM(sol.pick_qty) so_rtn_qty
               FROM wms_db.oms_so_hdr soh,
                    wms_db.oms_so_dtl sol
              WHERE soh.so_id = sol.so_id
                AND sol.status < 99
                AND soh.status IN (80)
                AND soh.so_type = 40
                AND datediff(curdate(),
                             soh.close_time) <= 7
                AND datediff(curdate(),
                             soh.close_time) >= 1
              GROUP BY soh.whse_code) d
    ON (a.whse_code = d.whse_code)
  LEFT JOIN (SELECT whse_code,
                    SUM(db_in_rcv_qty) in_rcv_qty
               FROM (SELECT poh.to_whse whse_code,
                            SUM(asnl.rcv_unit_qty) db_in_rcv_qty
                       FROM purch_po_hdr            poh,
                            wms_asn_hdr             asnh,
                            wms_asn_dtl             asnl,
                            purch_client_sku_master sku
                      WHERE asnh.po_id = poh.po_id
                        AND asnh.asn_id = asnl.asn_id
                        AND asnl.status < 99
                        AND asnh.status IN (40,
                                            90)
                        AND asnh.asn_type = 30
                        AND asnl.sku_code = sku.sku_code
                        AND (poh.whse_code = '380' AND
                            poh.to_whse LIKE 'BJA%')
                        AND datediff(curdate(),
                                     asnh.close_time) <= 7
                        AND datediff(curdate(),
                                     asnh.close_time) >= 1
                      GROUP BY poh.to_whse
                     UNION ALL
                     SELECT poh.to_whse whse_code,
                            SUM(asnl.rcv_unit_qty) db_in_store_rcv_qty
                       FROM purch_po_hdr            poh,
                            wms_asn_hdr             asnh,
                            wms_asn_dtl             asnl,
                            purch_client_sku_master sku
                      WHERE asnh.po_id = poh.po_id
                        AND asnh.asn_id = asnl.asn_id
                        AND asnl.status < 99
                        AND asnh.status IN (40,
                                            90)
                        AND asnh.asn_type = 30
                        AND asnl.sku_code = sku.sku_code
                        AND datediff(curdate(),
                                     asnh.close_time) <= 7
                        AND datediff(curdate(),
                                     asnh.close_time) >= 1
                        AND poh.to_whse LIKE 'BJA%'
                        AND poh.whse_code REGEXP '^[0-9]{6}$'
                      GROUP BY poh.to_whse
                     UNION ALL
                     SELECT poh.whse_code whse_code,
                            SUM(asnl.rcv_unit_qty) db_in_store_rcv_qty
                       FROM purch_po_hdr            poh,
                            wms_asn_hdr             asnh,
                            wms_asn_dtl             asnl,
                            purch_client_sku_master sku
                      WHERE asnh.po_id = poh.po_id
                        AND asnh.asn_id = asnl.asn_id
                        AND asnl.status < 99
                        AND asnh.asn_type = '10'
                        AND asnh.status IN (40,
                                            90)
                        AND asnl.sku_code = sku.sku_code
                        AND datediff(curdate(),
                                     asnh.close_time) <= 7
                        AND datediff(curdate(),
                                     asnh.close_time) >= 1
                      GROUP BY poh.whse_code) f
              GROUP BY f.whse_code) m
    ON (a.whse_code = m.whse_code)
  LEFT JOIN (SELECT poh.whse_code,
                    SUM(doh.send_unit_qty) rtv_send_qty
               FROM purch_po_hdr poh,
                    wms_do_hdr   doh
              WHERE doh.do_type IN (20)
                AND poh.po_id = doh.so_id
                AND doh.status IN (90)
                AND datediff(curdate(),
                             doh.close_time) <= 7
                AND datediff(curdate(),
                             doh.close_time) >= 1
                AND poh.status < 98
              GROUP BY poh.whse_code) g
    ON (a.whse_code = g.whse_code)
 WHERE a.whse_code LIKE 'BJA%'
 ORDER BY a.whse_code;   
end;

